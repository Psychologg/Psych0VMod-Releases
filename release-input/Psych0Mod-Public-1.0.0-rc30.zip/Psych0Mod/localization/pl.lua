return {
    language = "JĘZYK", language_title = "JĘZYK MODA",
    language_description = "Wybierz język. Ustawienie zostanie zapamiętane.", language_saved = "Język Psych0Mod: POLSKI",
    tools_title = "NARZĘDZIA I INFORMACJE", choose_option = "Wybierz opcję:", combined_perks = "POŁĄCZONE PERKI",
    character_editor = "EDYTOR PARAMETRÓW POSTACI", loadout_editor = "EDYTOR EKWIPUNKU W MISJI",
    profile_editor = "EDYTOR PROFILU (TYLKO MENU GŁÓWNE)", function_info = "INFORMACJE O FUNKCJACH",
    back_main = "WRÓĆ DO MENU GŁÓWNEGO", close_menu = "ZAMKNIJ MENU", main_title = "PSYCHO MODE - PANEL KONTROLNY",
    classic_description = "Układ klasyczny — wybierz kategorię:", alternative_description = "Układ alternatywny — wybierz kategorię:",
    switch_alternative = "ZMIEŃ UKŁAD: ALTERNATYWNY", switch_classic = "ZMIEŃ UKŁAD: KLASYCZNY",
    functions_f = "FUNKCJE F2–F11", functions_num = "FUNKCJE NUM I DODATKOWE KLAWISZE", special_actions = "AKCJE SPECJALNE",
    tools_info = "NARZĘDZIA / INFO", stealth_control = "SKRADANIE I KONTROLA", combat_survival = "WALKA I PRZETRWANIE",
    loot_equipment = "ŁUP I EKWIPUNEK MISJI", mission_team = "MISJA I DRUŻYNA", tools_info_close = "NARZĘDZIA / INFO / ZAMKNIJ",
    back = "WRÓĆ"
}
