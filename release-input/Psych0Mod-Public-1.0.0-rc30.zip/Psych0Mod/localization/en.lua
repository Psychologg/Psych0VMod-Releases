return {
    language = "LANGUAGE", language_title = "MOD LANGUAGE",
    language_description = "Select a language. The setting will be remembered.", language_saved = "Psych0Mod language: ENGLISH",
    tools_title = "TOOLS AND INFORMATION", choose_option = "Select an option:", combined_perks = "COMBINED PERKS",
    character_editor = "CHARACTER PARAMETERS EDITOR", loadout_editor = "IN-MISSION LOADOUT EDITOR",
    profile_editor = "PROFILE EDITOR (MAIN MENU ONLY)", function_info = "FUNCTION INFORMATION",
    back_main = "BACK TO MAIN MENU", close_menu = "CLOSE MENU", main_title = "PSYCHO MODE - CONTROL PANEL",
    classic_description = "Classic layout — select a category:", alternative_description = "Alternative layout — select a category:",
    switch_alternative = "CHANGE LAYOUT: ALTERNATIVE", switch_classic = "CHANGE LAYOUT: CLASSIC",
    functions_f = "F2–F11 FUNCTIONS", functions_num = "NUMPAD AND EXTRA KEY FUNCTIONS", special_actions = "SPECIAL ACTIONS",
    tools_info = "TOOLS / INFO", stealth_control = "STEALTH AND CONTROL", combat_survival = "COMBAT AND SURVIVAL",
    loot_equipment = "LOOT AND MISSION EQUIPMENT", mission_team = "MISSION AND TEAM", tools_info_close = "TOOLS / INFO / CLOSE",
    back = "BACK"
}
