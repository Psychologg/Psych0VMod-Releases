return {
    language = "SPRACHE", language_title = "MOD-SPRACHE",
    language_description = "Wähle eine Sprache. Die Einstellung wird gespeichert.", language_saved = "Psych0Mod-Sprache: DEUTSCH",
    tools_title = "WERKZEUGE UND INFORMATIONEN", choose_option = "Option auswählen:", combined_perks = "KOMBINIERTE PERKS",
    character_editor = "CHARAKTERWERTE-EDITOR", loadout_editor = "AUSRÜSTUNGS-EDITOR IN DER MISSION",
    profile_editor = "PROFIL-EDITOR (NUR HAUPTMENÜ)", function_info = "INFORMATIONEN ZU DEN FUNKTIONEN",
    back_main = "ZURÜCK ZUM HAUPTMENÜ", close_menu = "MENÜ SCHLIESSEN", main_title = "PSYCHO MODE - STEUERUNG",
    classic_description = "Klassisches Layout — Kategorie auswählen:", alternative_description = "Alternatives Layout — Kategorie auswählen:",
    switch_alternative = "LAYOUT WECHSELN: ALTERNATIV", switch_classic = "LAYOUT WECHSELN: KLASSISCH",
    functions_f = "F2–F11-FUNKTIONEN", functions_num = "NUMPAD- UND ZUSATZTASTEN-FUNKTIONEN", special_actions = "SPEZIALAKTIONEN",
    tools_info = "WERKZEUGE / INFO", stealth_control = "SCHLEICHEN UND KONTROLLE", combat_survival = "KAMPF UND ÜBERLEBEN",
    loot_equipment = "BEUTE UND MISSIONS-AUSRÜSTUNG", mission_team = "MISSION UND TEAM", tools_info_close = "WERKZEUGE / INFO / SCHLIESSEN",
    back = "ZURÜCK"
}
