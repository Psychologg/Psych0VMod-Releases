return {
    language = "ЯЗЫК", language_title = "ЯЗЫК МОДА",
    language_description = "Выберите язык. Настройка будет сохранена.", language_saved = "Язык Psych0Mod: РУССКИЙ",
    tools_title = "ИНСТРУМЕНТЫ И ИНФОРМАЦИЯ", choose_option = "Выберите вариант:", combined_perks = "ОБЪЕДИНЁННЫЕ ПЕРКИ",
    character_editor = "РЕДАКТОР ПАРАМЕТРОВ ПЕРСОНАЖА", loadout_editor = "РЕДАКТОР СНАРЯЖЕНИЯ В МИССИИ",
    profile_editor = "РЕДАКТОР ПРОФИЛЯ (ТОЛЬКО ГЛАВНОЕ МЕНЮ)", function_info = "ИНФОРМАЦИЯ О ФУНКЦИЯХ",
    back_main = "ВЕРНУТЬСЯ В ГЛАВНОЕ МЕНЮ", close_menu = "ЗАКРЫТЬ МЕНЮ", main_title = "PSYCHO MODE - ПАНЕЛЬ УПРАВЛЕНИЯ",
    classic_description = "Классическая раскладка — выберите категорию:", alternative_description = "Альтернативная раскладка — выберите категорию:",
    switch_alternative = "СМЕНИТЬ РАСКЛАДКУ: АЛЬТЕРНАТИВНАЯ", switch_classic = "СМЕНИТЬ РАСКЛАДКУ: КЛАССИЧЕСКАЯ",
    functions_f = "ФУНКЦИИ F2–F11", functions_num = "ФУНКЦИИ NUMPAD И ДОПОЛНИТЕЛЬНЫХ КЛАВИШ", special_actions = "СПЕЦИАЛЬНЫЕ ДЕЙСТВИЯ",
    tools_info = "ИНСТРУМЕНТЫ / ИНФО", stealth_control = "СКРЫТНОСТЬ И КОНТРОЛЬ", combat_survival = "БОЙ И ВЫЖИВАНИЕ",
    loot_equipment = "ДОБЫЧА И СНАРЯЖЕНИЕ МИССИИ", mission_team = "МИССИЯ И КОМАНДА", tools_info_close = "ИНСТРУМЕНТЫ / ИНФО / ЗАКРЫТЬ",
    back = "НАЗАД"
}
