# Lokalizacja Psych0Mod

## Zasada główna

Żaden nowy tekst widoczny dla gracza nie powinien być wpisywany bezpośrednio
w module. Menu, przyciski, opisy, ostrzeżenia i komunikaty HUD muszą korzystać
ze wspólnego tłumacza `PsychoT` z pliku `jezyk.lua`.

## Dodawanie tekstu do modułu

1. Utwórz jednoznaczny klucz, najlepiej z prefiksem modułu, np.
   `equipment_editor_title`.
2. Dodaj ten sam klucz do każdego pliku w katalogu `localization`:
   `pl.lua`, `en.lua`, `de.lua` i `ru.lua`.
3. W module wczytaj tekst przez `t("equipment_editor_title")`.
4. Nie składaj przetłumaczonych zdań z przypadkowych fragmentów. Liczby i nazwy
   dynamiczne wstawiaj dopiero po pobraniu pełnego zdania lub etykiety.
5. Polski słownik jest awaryjnym językiem zastępczym, ale brak klucza w innym
   języku nadal jest błędem do poprawienia.

## Dodawanie nowego języka

1. Skopiuj `localization/en.lua` do pliku o kodzie języka, np. `fr.lua`.
2. Zmień rejestrację tablicy na `_G.PsychoLocalization.fr`.
3. Przetłumacz każdą wartość bez zmieniania nazw kluczy.
4. Dodaj kod języka do tabeli `supported` w `jezyk.lua`.
5. Dodaj język jako opcję w menu wyboru języka w `pomoc.lua`.
6. Porównaj zestaw kluczy nowego pliku z `pl.lua`. Zestawy muszą być identyczne.

## Starsze teksty modułów

Pliki `localization/auto_en.lua`, `auto_de.lua` i `auto_ru.lua` zawierają mapy
tekstów pochodzących ze starszych modułów. Są generowane przez
`tools/generate_translations.py`, a następnie wymagają kontroli terminologii
PAYDAY 2. Generator wysyła do Tłumacza Google wyłącznie znalezione teksty —
nie wysyła kodu, konfiguracji ani danych gry. Uruchamiaj go tylko po uzyskaniu
wyraźnej zgody właściciela projektu.

Nowe funkcje powinny używać nazwanych kluczy `PsychoT`. Mapy automatyczne są
warstwą zgodności dla istniejącego kodu, a nie zamiennikiem czytelnych kluczy.

## Kontrola przed wydaniem

- Uruchom każdy ekran menu w każdym języku.
- Sprawdź osobno komunikaty HUD każdej funkcji.
- Wyszukaj w modułach teksty przekazywane bezpośrednio do `QuickMenu:new`,
  `show_hint` oraz pól `text`.
- Sprawdź, czy żaden ekran nie pokazuje nazwy klucza zamiast tłumaczenia.
- Zmiana języka nie może zmieniać mechaniki, konfiguracji perków ani zapisów.
