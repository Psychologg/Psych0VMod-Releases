﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$script:featurePending=$null
$script:featureDraft=@{}
$script:featureParameters=@{}
$script:featureSnapshot=$null
$script:featureStoreError=$null
$script:featureClientToken=[guid]::NewGuid().ToString('N')
function FText($PL,$EN){PText $PL}
function Write-FeatureJson([string]$Path,$Value){
    $parent=Split-Path -Parent $Path;if(!(Test-Path -LiteralPath $parent)){[void](New-Item -ItemType Directory -Path $parent -Force)}
    $tmp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{
        [IO.File]::WriteAllText($tmp,($Value|ConvertTo-Json -Depth 16),(New-Object Text.UTF8Encoding($false)))
        if(Test-Path -LiteralPath $Path){[IO.File]::Replace($tmp,$Path,$Path+'.bak')}else{[IO.File]::Move($tmp,$Path)}
    }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
function ConvertTo-FeatureMap($Value){
    $map=@{};if($Value -is [Collections.IDictionary]){foreach($key in $Value.Keys){$map[[string]$key]=$Value[$key]}}
    elseif($null -ne $Value){foreach($p in $Value.PSObject.Properties){$map[$p.Name]=$p.Value}}
    return $map
}
function Assert-FeatureSet($Set){
    $features=ConvertTo-FeatureMap $Set.features;$parameters=ConvertTo-FeatureMap $Set.parameters
    foreach($key in $features.Keys){if($features[$key] -isnot [bool]){throw (PText 'text_395')}}
    if($features.stealth -and $features.undetectable){throw (FText 'Duch i Całkowita niewykrywalność wykluczają się. Wybierz jedną funkcję.' 'Ghost and Complete undetectability are mutually exclusive. Select one.')}
    $known=@{}
    foreach($a in $script:featureCatalog){if($a.parameter){
        $p=$a.parameter;$known[[string]$p.key]=$true
        if(!$parameters.ContainsKey([string]$p.key)){$parameters[[string]$p.key]=[double]$p.default}
        $v=$parameters[[string]$p.key]
        if($v -is [bool] -or $v -is [string] -or $v -isnot [ValueType] -or [double]::IsNaN([double]$v) -or [double]$v -lt $p.min -or [double]$v -gt $p.max){throw ((PText 'text_396')+$p.key)}
    }}
    foreach($key in $parameters.Keys){if(!$known.ContainsKey($key)){throw ((PText 'text_397')+$key)}}
    return [pscustomobject]@{features=$features;parameters=$parameters}
}
function Read-FeatureStore {
    if(!(Test-Path -LiteralPath $script:featureStorePath)){return [pscustomobject]@{version=1;presets=@()}}
    $s=Get-Content -LiteralPath $script:featureStorePath -Raw -Encoding UTF8|ConvertFrom-Json
    if($s.version -ne 1 -or $null -eq $s.presets){throw (PText 'text_398')}
    $ids=@{}
    foreach($p in @($s.presets)){
        if([string]$p.id -notmatch '^[a-f0-9]{32}$' -or $ids.ContainsKey([string]$p.id) -or [string]::IsNullOrWhiteSpace([string]$p.name) -or $p.auto_start -isnot [bool]){throw (PText 'text_399')}
        $ids[[string]$p.id]=$true;[void](Assert-FeatureSet $p)
    }
    return $s
}
function Save-FeaturePreset([string]$Id,[string]$Name,$Set,[bool]$Auto,[bool]$RequireApp=$true){
    if($script:featureStoreError){throw $script:featureStoreError}
    if([string]::IsNullOrWhiteSpace($Name)){throw (FText 'Wpisz nazwę presetu.' 'Enter a preset name.')}
    $clean=Assert-FeatureSet $Set
    if(!$Id){$Id=[guid]::NewGuid().ToString('N')}
    $store=Read-FeatureStore
    if(@($store.presets|Where-Object {$_.id -ne $Id -and $_.name -eq $Name.Trim()}).Count){throw (FText 'Taka nazwa już istnieje.' 'This name already exists.')}
    $preset=[pscustomobject]@{id=$Id;name=$Name.Trim();features=$clean.features;parameters=$clean.parameters;auto_start=$Auto;requires_app=$true}
    $next=[pscustomobject]@{version=1;presets=@($store.presets|Where-Object {$_.id -ne $Id})+@($preset)}
    Write-FeatureJson $script:featureStorePath $next
    $script:featureStore=$next
    return $Id
}
function Remove-FeaturePreset([string]$Id){
    if($script:featureStoreError){throw $script:featureStoreError}
    $store=Read-FeatureStore
    Write-FeatureJson $script:featureStorePath ([pscustomobject]@{version=1;presets=@($store.presets|Where-Object {$_.id -ne $Id})})
    $script:featureStore=Read-FeatureStore
}
function Get-FeatureRoot {
    $root=Mod-Path
    if(!$root -or !(Test-Path -LiteralPath (Join-Path $root 'psych0vmod_features.lua'))){throw (FText 'Zaktualizuj aplikację i mod. Sprawdź folder PAYDAY 2.' 'Update the app and mod. Check the PAYDAY 2 folder.')}
    return $root
}
function Get-FeatureEpoch {return [long][Math]::Floor(([DateTime]::UtcNow-[DateTime]'1970-01-01').TotalSeconds)}
function Get-LiveFeatureSnapshot {
    $root=Mod-Path;if(!$root){return $null}
    $path=Join-Path $root 'psych0vmod_features_status.json'
    if(!(Test-Path -LiteralPath $path)){return $null}
    try{
        $s=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
        $age=(Get-FeatureEpoch)-[long]$s.time
        if($s.version -eq 1 -and $age -ge -2 -and $age -le 4){return $s}
    }catch{}
    return $null
}
function Start-FeatureRequest([string]$Operation,$Set=$null,[string]$Id='', [bool]$Enabled=$false){
    if($script:featurePending){throw (FText 'Poprzednia operacja jeszcze trwa.' 'An operation is already pending.')}
    $root=Get-FeatureRoot;$live=Get-LiveFeatureSnapshot
    if(!$live -or !$live.ready){throw (FText 'Brak gotowej misji. Preset możesz zapisać teraz; zastosuj go po wejściu do misji.' 'No ready mission. You can save the preset now; apply it after entering a mission.')}
    $nonce=[guid]::NewGuid().ToString('N')
    $r=@{version=1;nonce=$nonce;expires=((Get-FeatureEpoch)+15);operation=$Operation}
    if($Operation -eq 'apply'){$v=Assert-FeatureSet $Set;$r.features=$v.features;$r.parameters=$v.parameters;$r.name=$(if($script:featureName){[string]$script:featureName.Text}else{''})}
    elseif($Operation -eq 'set'){
        if(!@($script:featureCatalog|Where-Object {$_.id -eq $Id -and $_.kind -in @('toggle','group')}).Count){throw (PText 'text_400')}
        $r.id=$Id;$r.enabled=$Enabled
        $action=@($script:featureCatalog|Where-Object {$_.id -eq $Id})[0]
        if($Enabled -and $Set -and $action.parameter){$v=Assert-FeatureSet $Set;$r.parameters=@{};$r.parameters[[string]$action.parameter.key]=$v.parameters[[string]$action.parameter.key]}
    }else{throw (PText 'text_401')}
    Write-FeatureJson (Join-Path $root 'psych0vmod_features_request.json') $r
    $script:featurePending=[pscustomobject]@{nonce=$nonce;root=$root;expires=$r.expires}
}
function Save-FeatureAutostart($Set,[bool]$Enabled,[bool]$RequireApp=$true){
    $root=Get-FeatureRoot;$v=Assert-FeatureSet $Set
    $r=[pscustomobject]@{version=1;revision=[guid]::NewGuid().ToString('N');enabled=$Enabled;requires_app=$true;features=$v.features;parameters=$v.parameters;name=$(if($script:featureName){[string]$script:featureName.Text}else{''})}
    Write-FeatureJson (Join-Path $root 'psych0_presets.json') $r
}
function Read-FeatureAutostartConfiguration {
    $path=Join-Path (Get-FeatureRoot) 'psych0_presets.json'
    if(!(Test-Path -LiteralPath $path)){return $null}
    $auto=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    if($auto.version -ne 1 -or $auto.enabled -isnot [bool] -or !$auto.revision){throw (FText 'Niepoprawna konfiguracja auto-startu. Plik pozostawiono bez zmian.' 'Invalid auto-start configuration. File unchanged.')}
    [void](Assert-FeatureSet $auto)
    return $auto
}
function Get-FeatureAutostartChoices {
    $store=Read-FeatureStore;$auto=Read-FeatureAutostartConfiguration
    $choices=@([pscustomobject]@{id='';name=(FText 'Wyłączony' 'Disabled')})
    foreach($p in @($store.presets)){$choices+=@([pscustomobject]@{id=[string]$p.id;name=[string]$p.name})}
    if($auto -and $auto.enabled -and (!$auto.preset_id -or !@($store.presets|Where-Object {$_.id -eq $auto.preset_id}).Count)){
        $choices+=@([pscustomobject]@{id='__current__';name=((FText 'Zapisany zestaw: ' 'Saved set: ')+[string]$auto.name)})
    }
    return $choices
}
function Save-FeatureAutostartChoice([string]$PresetId) {
    $root=Get-FeatureRoot;$existing=Read-FeatureAutostartConfiguration
    if($PresetId -eq '__current__'){
        if(!$existing -or !$existing.enabled){throw (FText 'Zapisany zestaw nie jest już aktywny. Odśwież listę.' 'Saved set is no longer active. Refresh the list.')}
        return
    }
    $name='';$set=[pscustomobject]@{features=@{};parameters=@{}}
    if($PresetId){
        $preset=@((Read-FeatureStore).presets|Where-Object {$_.id -ceq $PresetId})
        if($preset.Count -ne 1){throw (FText 'Preset nie istnieje. Wybierz inny.' 'Preset no longer exists. Select another.')}
        $set=Assert-FeatureSet $preset[0];$name=[string]$preset[0].name
    }
    $clean=Assert-FeatureSet $set
    Write-FeatureJson (Join-Path $root 'psych0_presets.json') ([pscustomobject]@{version=1;revision=[guid]::NewGuid().ToString('N');enabled=[bool]$PresetId;requires_app=$true;preset_id=$PresetId;name=$name;features=$clean.features;parameters=$clean.parameters})
}
function Stop-FeatureRequest {
    if($script:featureTimer){$script:featureTimer.Stop()}
    $root=Mod-Path
    if($root){$clientPath=Join-Path $root 'psych0vmod_features_client.json';if(Test-Path -LiteralPath $clientPath){try{$client=Get-Content -LiteralPath $clientPath -Raw|ConvertFrom-Json;if($client.token -eq $script:featureClientToken){Remove-Item -LiteralPath $clientPath -Force}}catch{}}}
    if(!$script:featurePending){return}
    $path=Join-Path $script:featurePending.root 'psych0vmod_features_request.json'
    if(Test-Path -LiteralPath $path){try{$r=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json;if($r.nonce -eq $script:featurePending.nonce){Remove-Item -LiteralPath $path -Force}}catch{}}
    $script:featurePending=$null
}
function Get-FeatureErrorText([string]$Code){
    switch -Regex ($Code){
        'carry_stack_not_empty' {return (FText 'Nie można wyłączyć Tragarza: najpierw odłóż dodatkowe torby. Mnożnik możesz zmienić przyciskiem ON bez wyłączania.' 'Cannot turn the carrier OFF: drop extra stacked bags first. Apply the multiplier with ON without disabling.')}
        'carry_refresh_requires_restart' {return (FText 'Uruchom grę ponownie po aktualizacji modułu rzutu.' 'Restart the game after updating the throw module.')}
        'cannot_disable_or_refresh' {return (FText 'Nie można teraz wyłączyć lub zmienić funkcji. Dla tragarza opróżnij stos dodatkowych toreb.' 'Cannot disable or change the function now. For the carrier, empty extra stacked bags.')}
        'not_confirmed|some_switches|classes_not_ready' {return (FText 'Gra nie potwierdziła części zmian. Sprawdź oznaczone pozycje i warunki w opisach (gotowość gracza, tryb offline/host).' 'The game did not confirm some changes. Check marked rows and description requirements (player readiness, offline/host mode).')}
        'mission_not_ready' {return (FText 'Misja lub gracz nie jest gotowy.' 'The mission or player is not ready.')}
        'expired' {return (FText 'Polecenie wygasło. Sprawdź połączenie z grą.' 'Request expired. Check the game connection.')}
        'write_failed' {return (FText 'Nie udało się zapisać ustawień auto-startu. Sprawdź dostęp do folderu moda.' 'Could not save auto-start settings. Check access to the mod folder.')}
        'config|invalid_parameter|conflict' {return (FText 'Niepoprawne ustawienia zestawu lub auto-startu. Popraw wybór i zapisz ponownie.' 'Invalid set or auto-start settings. Review the selection and save again.')}
        default {return (FText 'Gra odmówiła wykonania zmiany. Sprawdź opis funkcji oraz log gry.' 'The game refused the change. Check the function description and game log.')}
    }
}
function Get-FeatureDraftChecked($Action){
    if($Action.kind -eq 'group'){return @($Action.members).Count -gt 0 -and @($Action.members|Where-Object {$script:featureDraft[[string]$_] -ne $true}).Count -eq 0}
    return $Action.kind -eq 'toggle' -and $script:featureDraft[[string]$Action.id] -eq $true
}
function Set-FeatureDraftChecked($Action,[bool]$Enabled){
    if($Action.kind -eq 'group'){foreach($id in $Action.members){$script:featureDraft[[string]$id]=$Enabled}}
    elseif($Action.kind -eq 'toggle'){
        $script:featureDraft[[string]$Action.id]=$Enabled
        if($Enabled -and $Action.id -in @('stealth','undetectable')){$other=if($Action.id -eq 'stealth'){'undetectable'}else{'stealth'};$script:featureDraft[$other]=$false}
    }
}
function Update-FeatureButtons {
    $a=if($script:featureGrid -and $script:featureGrid.SelectedItems.Count){$script:featureGrid.SelectedItems[0].Tag}else{$null}
    $ready=$null -ne $script:featureSnapshot -and $script:featureSnapshot.ready -eq $true
    $switch=$null -ne $a -and $a.kind -in @('toggle','group')
    if($script:featureOn){$script:featureOn.Enabled=$ready -and $switch}
    if($script:featureOff){$script:featureOff.Enabled=$ready -and $switch}
    if($script:featureRun){$script:featureRun.Enabled=$ready -and $null -ne $a -and $a.kind -eq 'action'}
    if($script:featureApply){$script:featureApply.Enabled=$ready}
    if($script:featureRefresh){
        $active=$false
        if($a -and $a.parameter -and $ready){$active=@($script:featureSnapshot.states|Where-Object {$_.id -eq $a.id -and $_.active}).Count -gt 0}
        $script:featureRefresh.Enabled=$active
    }
}
$script:featureSortColumn=-1
$script:featureSortDescending=$false
function Get-SortedFeatureRows($Items){
    $primary=@{Expression={
        $row=$_
        switch($script:featureSortColumn){
            1 { [string]$row.SubItems[1].Text }
            2 { [string]$row.SubItems[2].Text }
            default { [string]$row.Text }
        }
    }}
    return @($Items|Sort-Object -Property $primary,@{Expression={[string]$_.Tag.id}} -Descending:$script:featureSortDescending)
}
function Sort-FeatureRows {
    if($script:featureSortColumn -lt 0){return}
    $selected=if($script:featureGrid.SelectedItems.Count){[string]$script:featureGrid.SelectedItems[0].Tag.id}else{''}
    $rows=Get-SortedFeatureRows @($script:featureGrid.Items)
    $script:featureLoading=$true;$script:featureGrid.BeginUpdate()
    try{
        $script:featureGrid.Items.Clear()
        foreach($row in $rows){[void]$script:featureGrid.Items.Add($row);if($row.Tag.id -eq $selected){$row.Selected=$true}}
    }finally{$script:featureGrid.EndUpdate();$script:featureLoading=$false}
}
function Update-FeatureSortHeaders {
    $labels=@((FText 'Funkcja' 'Function'),(FText 'Typ' 'Type'),(FText 'Stan gry' 'Game state'))
    for($i=0;$i -lt 3;$i++){$script:featureGrid.Columns[$i].Text=$labels[$i]+$(if($i -eq $script:featureSortColumn){if($script:featureSortDescending){' ▼'}else{' ▲'}}else{''})}
}
function Initialize-Features($Tab){
    $script:featureCatalog=@((Get-Content -LiteralPath (Join-Path $AppDir 'features.json') -Raw -Encoding UTF8|ConvertFrom-Json).actions)
    $script:featureStorePath=Join-Path $DataDir 'presets.json'
    try{$script:featureStore=Read-FeatureStore}catch{$script:featureStoreError=PText $_.Exception.GetBaseException().Message;$script:featureStore=[pscustomobject]@{version=1;presets=@()}}
    foreach($a in $script:featureCatalog){if($a.parameter){$script:featureParameters[[string]$a.parameter.key]=[double]$a.parameter.default}}
    foreach($c in @($Tab.Controls)){$Tab.Controls.Remove($c);$c.Dispose()}
    $Tab.AutoScroll=$false
    $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=8;$layout.Padding=New-Object Windows.Forms.Padding(8);$Tab.Controls.Add($layout)
    foreach($h in @(76,38,0,112,42,38,76,66)){if($h -eq 0){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))}else{[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$h)))}}
    $presets=New-Object Windows.Forms.FlowLayoutPanel;$presets.Dock='Fill';$layout.Controls.Add($presets,0,0)
    $script:featurePresetBox=New-Object Windows.Forms.ComboBox;$script:featurePresetBox.DropDownStyle='DropDownList';$script:featurePresetBox.DisplayMember='name';$script:featurePresetBox.Width=220;$presets.Controls.Add($script:featurePresetBox)
    $script:featureName=New-Object Windows.Forms.TextBox;$script:featureName.Width=180;$presets.Controls.Add($script:featureName)
    function New-FeatureButton($Panel,$PL,$EN,$Handler){$b=New-Object Windows.Forms.Button;$b.Text=FText $PL $EN;$b.AutoSize=$true;$b.Height=30;$b.Add_Click($Handler);$Panel.Controls.Add($b);return $b}
    function script:Refresh-FeaturePresets([string]$SelectId=''){
        $script:featureLoading=$true
        try{$script:featurePresetBox.Items.Clear();foreach($p in @($script:featureStore.presets)){[void]$script:featurePresetBox.Items.Add($p);if($p.id -eq $SelectId){$script:featurePresetBox.SelectedItem=$p}}}finally{$script:featureLoading=$false}
        if($script:featureAutostartBox){try{Refresh-FeatureAutostartPicker}catch{$script:featureAutostartLabel.Text=FText 'Auto-start: ustaw folder gry lub sprawdź konfigurację.' 'Auto-start: set game folder or check configuration.';Feature-UiError (PText $_.Exception.GetBaseException().Message)}}
    }
    function script:Update-FeatureChecks([int]$SkipIndex=-1) {
        $script:featureLoading=$true
        try{foreach($item in $script:featureGrid.Items){if($item.Index -ne $SkipIndex){$item.Checked=Get-FeatureDraftChecked $item.Tag}}}finally{$script:featureLoading=$false}
    }
    function script:Get-FeatureDraft {return [pscustomobject]@{features=$script:featureDraft;parameters=$script:featureParameters}}
    function script:Feature-UiError($ErrorValue){$script:featureStatus.Text=[string]$ErrorValue}
    [void](New-FeatureButton $presets 'Nowy' 'New' {$script:featurePresetBox.SelectedIndex=-1;$script:featureName.Text='';$script:featureDraft=@{};$script:featureParameters=@{};foreach($a in $script:featureCatalog){if($a.parameter){$script:featureParameters[[string]$a.parameter.key]=[double]$a.parameter.default}};Update-FeatureChecks;Update-FeatureParameter})
    [void](New-FeatureButton $presets 'Zapisz preset' 'Save preset' {
        try{$id=if($script:featurePresetBox.SelectedItem){[string]$script:featurePresetBox.SelectedItem.id}else{''};$id=Save-FeaturePreset $id $script:featureName.Text (Get-FeatureDraft) $false;Refresh-FeaturePresets $id;$script:featureStatus.Text=FText 'Preset zapisany. Zmiany w grze nie nadpisują tej kopii.' 'Preset saved. Game changes do not overwrite this copy.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    [void](New-FeatureButton $presets 'Duplikuj' 'Duplicate' {
        try{$id=Save-FeaturePreset '' ($script:featureName.Text+' — '+(FText 'kopia' 'copy')) (Get-FeatureDraft) $false;Refresh-FeaturePresets $id;$script:featureName.Text=[string]$script:featurePresetBox.SelectedItem.name}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    [void](New-FeatureButton $presets 'Usuń preset' 'Delete preset' {
        try{if(!$script:featurePresetBox.SelectedItem){throw (FText 'Wybierz preset.' 'Select a preset.')};Remove-FeaturePreset ([string]$script:featurePresetBox.SelectedItem.id);Refresh-FeaturePresets;$script:featureName.Text='';$script:featureStatus.Text=FText 'Preset usunięty; aktywne funkcje i auto-start pozostają bez zmian.' 'Preset deleted; active switches and auto-start are unchanged.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    $script:featurePresetBox.Add_SelectedIndexChanged({
        if($script:featureLoading -or !$script:featurePresetBox.SelectedItem){return}
        $p=$script:featurePresetBox.SelectedItem;$script:featureName.Text=[string]$p.name;$script:featureDraft=ConvertTo-FeatureMap $p.features;$clean=Assert-FeatureSet $p;$script:featureParameters=$clean.parameters
        Update-FeatureChecks;Update-FeatureParameter
        $unknown=@($script:featureDraft.Keys|Where-Object {$id=$_;!@($script:featureCatalog|Where-Object {$_.id -eq $id -and $_.kind -eq 'toggle'}).Count})
        $script:featureStatus.Text=if($unknown.Count){(FText 'Niedostępne funkcje w presecie: ' 'Unavailable preset functions: ')+($unknown -join ', ')}else{FText 'Preset wczytany do edycji. Kliknij Zastosuj zaznaczenia, aby zmienić stan gry.' 'Preset loaded for editing. Click Apply selection to change game state.'}
    })
    $script:featureHint=New-Object Windows.Forms.Label;$script:featureHint.Dock='Fill';$script:featureHint.Text=FText 'Zaznaczenie = wybrany zestaw. Kolumna Stan gry = potwierdzone ON/OFF. Opis zaznaczonej pozycji poniżej.' 'Checkboxes = selected set. Game state = confirmed ON/OFF. Select a row to read its description below.';$layout.Controls.Add($script:featureHint,0,1)
    $script:featureGrid=New-Object Windows.Forms.ListView;$script:featureGrid.Dock='Fill';$script:featureGrid.View='Details';$script:featureGrid.CheckBoxes=$true;$script:featureGrid.FullRowSelect=$true;$script:featureGrid.MultiSelect=$false;$script:featureGrid.HideSelection=$false
    [void]$script:featureGrid.Columns.Add((FText 'Funkcja' 'Function'),400);[void]$script:featureGrid.Columns.Add((FText 'Typ' 'Type'),120);[void]$script:featureGrid.Columns.Add((FText 'Stan gry' 'Game state'),220);$layout.Controls.Add($script:featureGrid,0,2)
    foreach($a in $script:featureCatalog){$item=New-Object Windows.Forms.ListViewItem((Action-Name $a));$item.Tag=$a;[void]$item.SubItems.Add($(switch($a.kind){toggle{FText 'Przełącznik' 'Switch'};group{FText 'Grupa' 'Group'};default{FText 'Jednorazowa' 'One-shot'}}));[void]$item.SubItems.Add('—');[void]$script:featureGrid.Items.Add($item)}
    $script:featureGrid.Add_ColumnClick({param($sender,$eventArgs)
        if($eventArgs.Column -eq $script:featureSortColumn){$script:featureSortDescending=!$script:featureSortDescending}else{$script:featureSortColumn=$eventArgs.Column;$script:featureSortDescending=$false}
        Update-FeatureSortHeaders;Sort-FeatureRows
    })
    $script:featureGrid.Add_ItemCheck({param($sender,$e)
        if($script:featureLoading){return};$a=$sender.Items[$e.Index].Tag
        if($a.kind -eq 'action'){$e.NewValue=$e.CurrentValue;return}
        Set-FeatureDraftChecked $a ($e.NewValue -eq [Windows.Forms.CheckState]::Checked)
        Update-FeatureChecks $e.Index
    })
    $script:featureDescription=New-Object Windows.Forms.TextBox;$script:featureDescription.Multiline=$true;$script:featureDescription.ReadOnly=$true;$script:featureDescription.ScrollBars='Vertical';$script:featureDescription.Dock='Fill';$layout.Controls.Add($script:featureDescription,0,3)
    $parameterBar=New-Object Windows.Forms.FlowLayoutPanel;$parameterBar.Dock='Fill';$layout.Controls.Add($parameterBar,0,4)
    $script:featureParameterLabel=New-Object Windows.Forms.Label;$script:featureParameterLabel.AutoSize=$true;$parameterBar.Controls.Add($script:featureParameterLabel)
    $script:featureParameterBox=New-Object Windows.Forms.NumericUpDown;$script:featureParameterBox.Width=80;$script:featureParameterBox.DecimalPlaces=1;$script:featureParameterBox.Increment=0.5;$parameterBar.Controls.Add($script:featureParameterBox)
    $script:featureRefresh=New-FeatureButton $parameterBar 'Odśwież wartość' 'Refresh value' {
        try{
            if(!$script:featureGrid.SelectedItems.Count){return}
            $a=$script:featureGrid.SelectedItems[0].Tag
            if(!$a.parameter -or !@($script:featureSnapshot.states|Where-Object {$_.id -eq $a.id -and $_.active}).Count){throw (FText 'Najpierw włącz wybraną funkcję.' 'Turn the selected switch ON first.')}
            Start-FeatureRequest 'set' (Get-FeatureDraft) ([string]$a.id) $true
            $script:featureStatus.Text=FText 'Odświeżam parametr wybranej funkcji; czekam na potwierdzenie gry.' 'Refreshing the selected parameter; waiting for game confirmation.'
        }catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    }
    $script:featureRefresh.Enabled=$false
    function script:Update-FeatureParameter {
        $script:featureParameterLoading=$true
        try{
            $a=if($script:featureGrid.SelectedItems.Count){$script:featureGrid.SelectedItems[0].Tag}else{$null}
            $script:featureParameterBox.Visible=$null -ne $a -and $null -ne $a.parameter;$script:featureRefresh.Visible=$script:featureParameterBox.Visible;$script:featureParameterLabel.Text=''
            if($a -and $a.parameter){$p=$a.parameter;$script:featureParameterLabel.Text=[string]$p.PSObject.Properties[[string]$config.language].Value;$script:featureParameterBox.Minimum=0;$script:featureParameterBox.Maximum=[decimal]$p.max;$script:featureParameterBox.Minimum=[decimal]$p.min;$value=if($script:featureParameters.ContainsKey([string]$p.key)){$script:featureParameters[[string]$p.key]}else{$p.default};$script:featureParameterBox.Value=[decimal]$value}
        }finally{$script:featureParameterLoading=$false}
    }
    $script:featureParameterBox.Add_ValueChanged({if(!$script:featureParameterLoading -and $script:featureGrid.SelectedItems.Count){$p=$script:featureGrid.SelectedItems[0].Tag.parameter;if($p){$script:featureParameters[[string]$p.key]=[double]$script:featureParameterBox.Value}}})
    $script:featureGrid.Add_SelectedIndexChanged({
        if(!$script:featureGrid.SelectedItems.Count){return};$a=$script:featureGrid.SelectedItems[0].Tag;$lang=[string]$config.language
        $desc=$a.descriptions.PSObject.Properties[$lang];if(!$desc){$desc=$a.descriptions.PSObject.Properties['en']}
        $script:featureDescription.Text=Format-ActionDescription ([string]$desc.Value)
        if($a.kind -eq 'group'){$script:featureDescription.Text+="`r`n`r`n"+(FText 'Pole wyboru zaznacza wszystkie funkcje grupy do presetu. ON/OFF ustawia grupę w grze, zachowując inne funkcje.' 'Checkbox selects all group switches for a preset. ON/OFF sets the group in-game, preserving other functions.')}
        elseif($a.kind -eq 'action'){$script:featureDescription.Text+="`r`n`r`n"+(FText 'Akcja na żądanie. Nie wchodzi do auto-startu ani zestawu przełączników.' 'On-demand action. Excluded from auto-start and switch presets.')}
        Update-FeatureParameter;Update-FeatureButtons
        try{Update-Psych0KeybindSelection}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    $keyBar=New-Object Windows.Forms.FlowLayoutPanel;$keyBar.Dock='Fill';$layout.Controls.Add($keyBar,0,5)
    $keyLabel=New-Object Windows.Forms.Label;$keyLabel.AutoSize=$true;$keyLabel.Text=FText 'Klawisz funkcji:' 'Function key:';$keyBar.Controls.Add($keyLabel)
    $script:keybindBox=New-Object Windows.Forms.ComboBox;$script:keybindBox.DropDownStyle='DropDownList';$script:keybindBox.DisplayMember='label';$script:keybindBox.Width=155
    foreach($choice in Get-KeybindChoices){[void]$script:keybindBox.Items.Add($choice)}
    $keyBar.Controls.Add($script:keybindBox)
    function script:Update-Psych0KeybindSelection {
        if(!$script:featureGrid.SelectedItems.Count){return}
        $id=[string]$script:featureGrid.SelectedItems[0].Tag.keybind_id
        $key=Get-Psych0AssignedKey $id
        if($script:featureDescription){$keyText=if($key){$key.ToUpperInvariant()}else{FText 'nieprzypisany' 'unassigned'};$script:featureDescription.Text=$script:featureDescription.Text -replace '(?m)^KLAWISZ:[^\r\n]*',('KLAWISZ: '+$keyText)}
        $script:keybindBox.SelectedIndex=-1
        foreach($choice in $script:keybindBox.Items){if($choice.key -ceq $key){$script:keybindBox.SelectedItem=$choice;break}}
        if($script:keybindBox.SelectedIndex -lt 0){$unknown=[pscustomobject]@{key=$key;label=('Current: '+$key)};[void]$script:keybindBox.Items.Add($unknown);$script:keybindBox.SelectedItem=$unknown}
    }
    [void](New-FeatureButton $keyBar 'Zapisz klawisz' 'Save key' {
        try{if(!$script:featureGrid.SelectedItems.Count -or !$script:keybindBox.SelectedItem){throw (FText 'Wybierz funkcję i klawisz.' 'Select a function and key.')}
            $script:featureStatus.Text=Save-Psych0KeybindWithConfirmation ([string]$script:featureGrid.SelectedItems[0].Tag.keybind_id) ([string]$script:keybindBox.SelectedItem.key)
        }catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    [void](New-FeatureButton $keyBar 'Usuń przypisanie' 'Unbind' {
        try{if(!$script:featureGrid.SelectedItems.Count){return};$script:featureStatus.Text=Save-Psych0Keybind ([string]$script:featureGrid.SelectedItems[0].Tag.keybind_id) '';Update-Psych0KeybindSelection}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    [void](New-FeatureButton $keyBar 'Odśwież klawisz' 'Refresh key' {try{Update-Psych0KeybindSelection}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}})
    $bottom=New-Object Windows.Forms.TableLayoutPanel;$bottom.Dock='Fill';$bottom.ColumnCount=1;$bottom.RowCount=2;$layout.Controls.Add($bottom,0,7)
    $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$buttons.Height=34;$bottom.Controls.Add($buttons,0,0)
$script:featureOn=New-FeatureButton $buttons 'ON' 'ON' {try{if(!$script:featureGrid.SelectedItems.Count){throw (FText 'Wybierz funkcję.' 'Select a function.')};Start-FeatureRequest 'set' (Get-FeatureDraft) ([string]$script:featureGrid.SelectedItems[0].Tag.id) $true;$script:featureStatus.Text=FText 'Czekam na potwierdzenie ON z gry.' 'Waiting for ON confirmation from the game.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}}
$script:featureOff=New-FeatureButton $buttons 'OFF' 'OFF' {try{if(!$script:featureGrid.SelectedItems.Count){throw (FText 'Wybierz funkcję.' 'Select a function.')};Start-FeatureRequest 'set' $null ([string]$script:featureGrid.SelectedItems[0].Tag.id) $false;$script:featureStatus.Text=FText 'Czekam na potwierdzenie OFF z gry.' 'Waiting for OFF confirmation from the game.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}}
$script:featureApply=New-FeatureButton $buttons 'Zastosuj zaznaczenia' 'Apply selection' {try{Start-FeatureRequest 'apply' (Get-FeatureDraft);$script:featureStatus.Text=FText 'Czekam na potwierdzenie zestawu z gry.' 'Waiting for set confirmation from the game.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}}
    $script:featureRun=New-FeatureButton $buttons 'Wykonaj akcję' 'Run action' {
        try{if(!$script:featureGrid.SelectedItems.Count){return};$a=$script:featureGrid.SelectedItems[0].Tag
            if($a.kind -ne 'action'){throw (FText 'Dla funkcji i grup użyj ON/OFF lub pól wyboru.' 'Use ON/OFF or checkboxes for switches and groups.')}
            if(!$script:featureSnapshot -or !$script:featureSnapshot.ready){throw (FText 'Wejdź do misji.' 'Enter a mission.')}
            Invoke-Psych0Action ([string]$a.id);$script:featureStatus.Text=FText 'Wysłano akcję do gry; sprawdź komunikat gry.' 'Action sent; check the game message.'
        }catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    }
    $script:featureButtonTips=New-Object Windows.Forms.ToolTip
    $script:featureButtonTips.SetToolTip($script:featureApply,(FText 'Włącza zaznaczone przełączniki i wyłącza pozostałe. Wiersz wybrany do opisu nie jest zaznaczeniem zestawu.' 'Turns checked switches ON and other switches OFF. Selecting a description row does not check it.'))
    $script:featureButtonTips.SetToolTip($script:featureRefresh,(FText 'Zatwierdza parametr tylko wybranej, włączonej funkcji. Tragarz zachowuje stos toreb; zapisany preset nie jest nadpisywany.' 'Applies only the selected active switch parameter. The carrier preserves stacked bags; saved presets are not overwritten.'))
    $script:featureButtonTips.SetToolTip($script:featureOn,(FText 'Włącza wybraną funkcję lub grupę. Dla funkcji z mnożnikiem zatwierdza również wpisaną wartość. Pozostałe funkcje pozostają bez zmian.' 'Turns the selected switch/group ON; also applies its displayed multiplier. Other switches are preserved.'))
    $script:featureButtonTips.SetToolTip($script:featureRun,(FText 'Wykonuje wybraną akcję jednorazową, np. uzupełnienie amunicji.' 'Runs the selected one-shot action, such as refilling ammunition.'))
    $autoPanel=New-Object Windows.Forms.TableLayoutPanel;$autoPanel.Dock='Fill';$autoPanel.RowCount=2;$autoPanel.ColumnCount=1;$layout.Controls.Add($autoPanel,0,6)
    [void]$autoPanel.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',38)));[void]$autoPanel.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
    $autoBar=New-Object Windows.Forms.FlowLayoutPanel;$autoBar.Dock='Fill';$autoPanel.Controls.Add($autoBar,0,0)
    $autoTitle=New-Object Windows.Forms.Label;$autoTitle.Text=FText 'Preset uruchamiany automatycznie:' 'Automatically started preset:';$autoTitle.AutoSize=$true;$autoTitle.Margin=New-Object Windows.Forms.Padding(3,8,3,3);$autoBar.Controls.Add($autoTitle)
    $script:featureAutostartBox=New-Object Windows.Forms.ComboBox;$script:featureAutostartBox.DropDownStyle='DropDownList';$script:featureAutostartBox.DisplayMember='name';$script:featureAutostartBox.Width=210;$autoBar.Controls.Add($script:featureAutostartBox)
    [void](New-FeatureButton $autoBar 'Zatwierdź auto-start' 'Confirm auto-start' {
        try{if(!$script:featureAutostartBox.SelectedItem){throw (FText 'Wybierz preset lub Wyłączony.' 'Select a preset or Disabled.')};Save-FeatureAutostartChoice ([string]$script:featureAutostartBox.SelectedItem.id);Refresh-FeatureAutostartPicker;$script:featureStatus.Text=FText 'Zapisano auto-start. Uruchomi zapisany zestaw przy starcie misji z otwartą aplikacją.' 'Auto-start saved. Starts the saved set at mission start with the app open.'}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    })
    $script:featureAutostartLabel=New-Object Windows.Forms.Label;$script:featureAutostartLabel.Dock='Fill';$script:featureAutostartLabel.AutoEllipsis=$true;$autoPanel.Controls.Add($script:featureAutostartLabel,0,1)
    function script:Refresh-FeatureAutostartPicker {
        $previous=if($script:featureAutostartBox.SelectedItem){[string]$script:featureAutostartBox.SelectedItem.id}else{$null}
        $auto=Read-FeatureAutostartConfiguration
        $active=if($auto -and $auto.enabled){if($auto.preset_id){[string]$auto.preset_id}else{'__current__'}}else{''}
        $choices=@(Get-FeatureAutostartChoices)
        if(!@($choices|Where-Object {$_.id -eq $active}).Count){$active='__current__'}
        $selected=if($null -ne $previous -and @($choices|Where-Object {$_.id -eq $previous}).Count){$previous}else{$active}
        $script:featureAutostartBox.Items.Clear()
        foreach($choice in $choices){[void]$script:featureAutostartBox.Items.Add($choice);if($choice.id -eq $selected){$script:featureAutostartBox.SelectedItem=$choice}}
        $script:featureAutostartLabel.Text=(FText 'Zapisany auto-start: ' 'Saved auto-start: ')+$(if($auto -and $auto.enabled){[string]$auto.name}else{FText 'Wyłączony' 'Disabled'})+(FText ' • Wymaga otwartej aplikacji. Zmiany zatwierdź przyciskiem.' ' • Requires the app open. Confirm changes with the button.')
    }
    $script:featureStatus=New-Object Windows.Forms.Label;$script:featureStatus.Dock='Fill';$script:featureStatus.AutoEllipsis=$true;$bottom.Controls.Add($script:featureStatus,0,1)
    $script:featureStatus.Text=if($script:featureStoreError){$script:featureStoreError}else{FText 'Wybierz funkcję, aby przeczytać opis. Zestawy zapisuj przyciskiem Zapisz preset.' 'Select a function to read its description. Save sets with Save preset.'}
    function script:Poll-Features {
        Poll-Psych0KeybindResult
        $root=Mod-Path
        if($root -and (Test-Path -LiteralPath (Join-Path $root 'psych0vmod_features.lua'))){Write-FeatureJson (Join-Path $root 'psych0vmod_features_client.json') @{version=1;token=$script:featureClientToken;until=((Get-FeatureEpoch)+4)}}
        $live=Get-LiveFeatureSnapshot;$script:featureSnapshot=$live;Update-FeatureButtons;$states=@{}
        $script:featureHint.Text=(FText 'Zastosuj zaznaczenia: zaznaczone ON, pozostałe OFF. Wybór wiersza pokazuje opis. ' 'Apply selection: checked ON, others OFF. Selecting a row shows its description. ')+(FText 'Auto-start w grze: ' 'Game auto-start: ')+$(if(!$live){FText 'brak połączenia' 'disconnected'}elseif($live.auto_enabled){'ON '+[string]$live.auto_name+' '+(FText '(wymaga aplikacji)' '(requires app)')}else{(PText 'text_156')})
        if($live -and $live.ready){foreach($s in $live.states){$states[[string]$s.id]=$s}}
        foreach($row in $script:featureGrid.Items){$a=$row.Tag
            if($a.kind -eq 'action'){$row.SubItems[2].Text='—';continue}
            if($a.kind -eq 'group'){
                $members=@($a.members|ForEach-Object {$states[[string]$_]})
                $row.SubItems[2].Text=if($members.Count -ne @($a.members).Count -or @($members|Where-Object {$null -eq $_}).Count){FText 'Brak gotowej misji' 'No ready mission'}elseif(@($members|Where-Object {$_.error}).Count){FText 'Niepotwierdzona zmiana' 'Unconfirmed change'}elseif(@($members|Where-Object {$_.active}).Count -eq $members.Count){(PText 'text_153')}elseif(@($members|Where-Object {$_.active}).Count -eq 0){(PText 'text_156')}else{FText 'Częściowo ON' 'Partially ON'}
                continue
            }
            $s=$states[[string]$a.id]
            $row.SubItems[2].Text=if(!$s){FText 'Brak gotowej misji' 'No ready mission'}elseif($s.error){$(if($s.active){(PText 'text_153')}else{(PText 'text_156')})+' / '+(FText 'niepotwierdzona zmiana' 'unconfirmed change')}elseif($s.active){(PText 'text_153')}else{(PText 'text_156')}
        }
        if($script:featureSortColumn -eq 2){Sort-FeatureRows}
        if($script:featurePending){
            $p=$script:featurePending;$path=Join-Path $p.root 'psych0vmod_features_result.json'
            if(Test-Path -LiteralPath $path){try{
                $r=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
                if($r.version -eq 1 -and $r.nonce -eq $p.nonce){
                    $script:featurePending=$null
                    $script:featureStatus.Text=if($r.status -eq 'done'){FText 'Stan zestawu potwierdzony przez grę.' 'Switch state confirmed by the game.'}else{Get-FeatureErrorText ([string]$r.detail)}
                    $unavailable=@($r.data.unavailable|Where-Object {! [string]::IsNullOrWhiteSpace([string]$_)});if($unavailable.Count){$script:featureStatus.Text+=' '+(FText 'Niedostępne: ' 'Unavailable: ')+($unavailable -join ', ')}
                }
            }catch{}}
            if($script:featurePending -and (Get-FeatureEpoch) -ge $p.expires){Stop-FeatureRequest;$script:featureTimer.Start();$script:featureStatus.Text=FText 'Brak potwierdzenia. Operacja wygasła; sprawdź grę i mostek.' 'No confirmation. Request expired; check the game and bridge.'}
        }
        if($live -and ($live.storage_error -or $live.config_error)){$script:featureStatus.Text=Get-FeatureErrorText ([string]$live.storage_error+' '+[string]$live.config_error)}
    }
    Refresh-FeaturePresets;Update-FeatureParameter;Update-FeatureButtons
        try{Update-Psych0KeybindSelection}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    try{
        $root=Mod-Path
        if($root -and (Test-Path -LiteralPath (Join-Path $root 'psych0_presets.json'))){
            $auto=Get-Content -LiteralPath (Join-Path $root 'psych0_presets.json') -Raw -Encoding UTF8|ConvertFrom-Json
            if($auto.version -eq 1){
                $savedPath=Join-Path $root 'psych0_autostart_state.json'
                if(Test-Path -LiteralPath $savedPath){try{$saved=Get-Content -LiteralPath $savedPath -Raw -Encoding UTF8|ConvertFrom-Json;if($saved.version -eq 1 -and $saved.revision -eq $auto.revision){$auto.features=$saved.features;$auto.parameters=$saved.parameters;if($saved.name){$auto.name=$saved.name}}}catch{}}
                $clean=Assert-FeatureSet $auto;$script:featureDraft=$clean.features;$script:featureParameters=$clean.parameters
                $script:featureName.Text=[string]$auto.name
                $script:featureLoading=$true
                try{foreach($p in $script:featurePresetBox.Items){if($p.name -eq $auto.name){$script:featurePresetBox.SelectedItem=$p;break}}}finally{$script:featureLoading=$false}
                Update-FeatureChecks;Update-FeatureParameter
                $script:featureStatus.Text=FText 'Wczytano bieżący zestaw auto-startu. Zapisany preset zmieni się tylko po Zapisz preset.' 'Current auto-start set loaded. The saved preset changes only with Save preset.'
            }
        }
    }catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    try{Refresh-FeatureAutostartPicker}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}
    $script:featureTimer=New-Object Windows.Forms.Timer;$script:featureTimer.Interval=1000;$script:featureTimer.Add_Tick({try{Poll-Features}catch{Feature-UiError (PText $_.Exception.GetBaseException().Message)}});$script:featureTimer.Start()
}
