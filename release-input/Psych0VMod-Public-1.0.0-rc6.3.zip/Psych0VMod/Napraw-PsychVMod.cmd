@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Napraw-PsychVMod.ps1"
