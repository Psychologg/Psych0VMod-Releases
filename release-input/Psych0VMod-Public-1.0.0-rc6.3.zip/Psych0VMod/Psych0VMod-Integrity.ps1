﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
function Test-Psych0GameFolder([string]$Path) {
    if(!$Path){return $false}
    foreach($name in @('PAYDAY2.exe','payday2_win32_release.exe','payday2_win64_release.exe')){
        if(Test-Path -LiteralPath (Join-Path $Path $name) -PathType Leaf){return $true}
    }
    return $false
}
function Get-Psych0IntegrityIssues($Inventory,[string]$Target,[bool]$KeepModConfig=$false) {
    foreach($file in $Inventory.files){
        $name=[string]$file.path;Assert-Psych0RelativePath $name
        if($KeepModConfig -and $name -eq 'psych0_config.txt'){continue}
        $path=Join-Path $Target $name
        if(!(Test-Path -LiteralPath $path -PathType Leaf)){"Brak: $name";continue}
        try{if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256){"Uszkodzony: $name"}}catch{(PText 'text_334' @($name))}
    }
}
function Get-Psych0RepairPackage($Component,[string]$Root,[string]$Folder) {
    if($Component.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw (PText 'text_266')}
    [void]@(Get-Psych0ComponentUrls $Component)
    $zip=Join-Path $Root ($Folder+'.zip');$out=Join-Path $Root $Folder
    Save-Psych0ComponentArchive $Component $zip
    Assert-UpdateArchive $zip ([string]$Component.sha256)
    Expand-Archive -LiteralPath $zip -DestinationPath $out -Force
    return $out
}
function New-Psych0RepairPlan($Manifest,[string]$AppTarget,[string]$ModTarget,[string]$Root) {
    New-Item -ItemType Directory -Force $Root|Out-Null
    $app=Join-Path (Get-Psych0RepairPackage $Manifest.components.psych0vmod $Root 'app') 'Psych0VMod'
    $mod=Join-Path (Get-Psych0RepairPackage $Manifest.components.psych0mod $Root 'mod') 'Psych0Mod'
    $ar=Assert-Psych0Release $app;$mr=Assert-Psych0Release $mod
    if($ar.component -ne 'psych0vmod' -or $ar.version -ne $Manifest.components.psych0vmod.version -or $mr.component -ne 'psych0mod' -or $mr.version -ne $Manifest.components.psych0mod.version){throw (PText 'text_435')}
    $issues=@(Get-Psych0IntegrityIssues $ar $AppTarget)
    foreach($pair in @(@($app,$AppTarget),@($mod,$ModTarget))){
        $local=Join-Path $pair[1] '.psych0-release.json'
        try{$ledger=Get-Content -LiteralPath $local -Raw -Encoding UTF8|ConvertFrom-Json;if($ledger.version -ne (Get-Content (Join-Path $pair[0] '.psych0-release.json') -Raw|ConvertFrom-Json).version){throw (PText 'text_436')}}catch{$issues+=(PText 'text_578')+$pair[1]}
    }
    $issues+=@(Get-Psych0IntegrityIssues $mr $ModTarget $true)
    $speech=Get-Content -LiteralPath (Join-Path $app 'speech-assets.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $speechIssues=@(Get-Psych0IntegrityIssues $speech $AppTarget)
    $issues+=$speechIssues
    return [pscustomobject]@{root=$Root;app=$app;mod=$mod;appTarget=$AppTarget;modTarget=$ModTarget;issues=$issues;speech=$speech;speechNeeded=($speechIssues.Count -gt 0);manifest=$Manifest}
}
function Complete-Psych0RepairSource($Plan) {
    if($Plan.speechNeeded){
        $assets=Join-Path $Plan.root 'voice-merged'
        New-Item -ItemType Directory -Force $assets|Out-Null
        $i=0
        foreach($pack in $Plan.manifest.components.psych0speech.packs){
            $part=Join-Path (Get-Psych0RepairPackage $pack $Plan.root ('speech'+$i)) 'Psych0VMod'
            Get-ChildItem -LiteralPath $part -Force|Copy-Item -Destination $assets -Recurse -Force
            $i++
        }
        $bad=@(Get-Psych0IntegrityIssues $Plan.speech $assets)
        if($bad.Count){throw ((PText 'text_267')+($bad -join ', '))}
        # Only trusted inventory files enter the repair source.
        foreach($file in $Plan.speech.files){
            $dest=Join-Path $Plan.app $file.path
            New-Item -ItemType Directory -Force (Split-Path -Parent $dest)|Out-Null
            Copy-Item -LiteralPath (Join-Path $assets $file.path) -Destination $dest -Force
        }
        $path=Join-Path $Plan.app '.psych0-release.json'
        $release=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
        $release.files=@($release.files)+@($Plan.speech.files)
        $release|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $path -Encoding UTF8
    }
    [void](Assert-Psych0Release $Plan.app)
}
function Invoke-Psych0RepairCommit($Plan) {
    Assert-Psych0GameClosed
    foreach($target in @($Plan.modTarget,$Plan.appTarget)){
        if(Test-Path -LiteralPath $target){
            $backup=Join-Path (Get-Psych0DataDirectory) ('repair-backups/'+[guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Force $backup|Out-Null
            Get-ChildItem -LiteralPath $target -Force|Copy-Item -Destination $backup -Recurse -Force
        }
    }
    Set-TransactionalDirectory $Plan.mod $Plan.modTarget $false
    Set-TransactionalDirectory $Plan.app $Plan.appTarget $true
    $bad=@(Get-Psych0IntegrityIssues (Assert-Psych0Release $Plan.app) $Plan.appTarget)
    $bad+=@(Get-Psych0IntegrityIssues (Assert-Psych0Release $Plan.mod) $Plan.modTarget $true)
    if($bad.Count){throw ($bad -join "`r`n")}
}
