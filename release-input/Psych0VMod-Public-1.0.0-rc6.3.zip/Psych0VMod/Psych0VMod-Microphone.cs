﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

// Windows WinMM capture, independent of System.Speech and language packs.
public static class Psych0VModMicrophone {
    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    private struct WaveFormat {
        public ushort format, channels;
        public uint rate, bytesPerSecond;
        public ushort blockAlign, bits, extra;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct WaveHeader {
        public IntPtr data;
        public uint length, recorded;
        public UIntPtr user;
        public uint flags, loops;
        public IntPtr next;
        public UIntPtr reserved;
    }
    [DllImport("winmm.dll")]
    private static extern uint waveInOpen(out IntPtr handle, uint device, ref WaveFormat format, UIntPtr callback, UIntPtr instance, uint flags);
    [DllImport("winmm.dll")]
    private static extern uint waveInPrepareHeader(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")]
    private static extern uint waveInAddBuffer(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")]
    private static extern uint waveInStart(IntPtr handle);
    [DllImport("winmm.dll")]
    private static extern uint waveInReset(IntPtr handle);
    [DllImport("winmm.dll")]
    private static extern uint waveInUnprepareHeader(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")]
    private static extern uint waveInClose(IntPtr handle);
    [DllImport("winmm.dll")]
    public static extern uint waveInGetNumDevs();

    private static void Check(uint code, string operation) {
        if (code != 0) throw new InvalidOperationException(operation + " (WinMM " + code + "). Sprawdź mikrofon i uprawnienia / Check microphone and permissions.");
    }

    public static void Record(string path,int seconds){RecordInternal(path,seconds,delegate{Thread.Sleep(400);});}
    public static void RecordWithCountdown(string path,int seconds,Action countdown){
        if(countdown==null)throw new ArgumentNullException("countdown");RecordInternal(path,seconds,countdown);
    }
    private static void RecordInternal(string path, int seconds, Action prepare) {
        if (seconds < 1 || seconds > 15) throw new ArgumentOutOfRangeException("seconds");
        const uint rate = 16000;
        int capacity = (seconds+5) * (int)rate * 2;
        uint headerSize = (uint)Marshal.SizeOf(typeof(WaveHeader));
        IntPtr handle = IntPtr.Zero, data = IntPtr.Zero, header = IntPtr.Zero;
        bool prepared = false, queued = false;
        try {
            WaveFormat format = new WaveFormat { format = 1, channels = 1, rate = rate,
                bytesPerSecond = rate * 2, blockAlign = 2, bits = 16, extra = 0 };
            Check(waveInOpen(out handle, 0xFFFFFFFF, ref format, UIntPtr.Zero, UIntPtr.Zero, 0), "waveInOpen");
            data = Marshal.AllocHGlobal(capacity);
            header = Marshal.AllocHGlobal((int)headerSize);
            WaveHeader value = new WaveHeader { data = data, length = (uint)capacity };
            Marshal.StructureToPtr(value, header, false);
            Check(waveInPrepareHeader(handle, header, headerSize), "waveInPrepareHeader");
            prepared = true;
            Check(waveInAddBuffer(handle, header, headerSize), "waveInAddBuffer");
            queued = true;
            Check(waveInStart(handle), "waveInStart");
            var clock=System.Diagnostics.Stopwatch.StartNew();
            prepare();
            int offset=(int)Math.Round(clock.Elapsed.TotalSeconds*rate)*2;
            if(offset>capacity-seconds*(int)rate*2)throw new InvalidOperationException("Countdown exceeded capture buffer");
            Thread.Sleep(seconds * 1000);
            Check(waveInReset(handle), "waveInReset");
            value = (WaveHeader)Marshal.PtrToStructure(header, typeof(WaveHeader));
            if ((value.flags & 1) == 0) throw new InvalidOperationException("Audio buffer is still in use.");
            queued = false;
            int length = (int)value.recorded;
            length -= length % 2;
            if (length <= 0 || length > capacity) throw new InvalidOperationException("Brak nagrania / No audio captured.");
            length=Math.Min(seconds*(int)rate*2,length-offset);length-=length%2;
            if(length<seconds*(int)rate*2*.8)throw new InvalidOperationException("Incomplete audio after warmup");
            byte[] audio = new byte[length];
            Marshal.Copy(IntPtr.Add(data,offset), audio, 0, length);
            using (BinaryWriter writer = new BinaryWriter(File.Create(path))) {
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF")); writer.Write(36 + length);
                writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt ")); writer.Write(16);
                writer.Write((ushort)1); writer.Write((ushort)1); writer.Write(rate); writer.Write(rate * 2);
                writer.Write((ushort)2); writer.Write((ushort)16);
                writer.Write(System.Text.Encoding.ASCII.GetBytes("data")); writer.Write(length); writer.Write(audio);
            }
        } finally {
            // Never free a buffer while a device driver owns it.
            bool released = !queued;
            if (handle != IntPtr.Zero && queued) {
                if (waveInReset(handle) == 0) {
                    WaveHeader value = (WaveHeader)Marshal.PtrToStructure(header, typeof(WaveHeader));
                    released = (value.flags & 1) != 0;
                }
            }
            if (prepared && released) released = waveInUnprepareHeader(handle, header, headerSize) == 0;
            if (handle != IntPtr.Zero && released) waveInClose(handle);
            if (released) {
                if (header != IntPtr.Zero) Marshal.FreeHGlobal(header);
                if (data != IntPtr.Zero) Marshal.FreeHGlobal(data);
            }
        }
    }
}
