﻿. (Join-Path $PSScriptRoot 'Psych0VMod-Channel.ps1')
# One catalog for all interface strings. Persisted IDs and user text are never translated.
$script:Psych0UiCatalog=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'localization.json') -Raw -Encoding UTF8|ConvertFrom-Json
$script:Psych0UiAliases=New-Object 'Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
foreach($alias in $script:Psych0UiCatalog.aliases){$script:Psych0UiAliases[[string]$alias.source]=[string]$alias.key}
$script:Psych0UiLanguage='pl'
try{
 $settings=Join-Path (Get-Psych0DataDirectory) 'config.json'
 if(Test-Path -LiteralPath $settings){$code=[string](Get-Content -LiteralPath $settings -Raw -Encoding UTF8|ConvertFrom-Json).language;if($code -in @('pl','en','de','ru')){$script:Psych0UiLanguage=$code}}
}catch{}
function PText([string]$Key,[object[]]$Values=@()) {
 $language=$script:Psych0UiLanguage
 if($config -and [string]$config.language -in @('pl','en','de','ru')){$language=[string]$config.language}
 $entry=$script:Psych0UiCatalog.entries.PSObject.Properties[$Key]
 if(!$entry){if($script:Psych0UiAliases.ContainsKey($Key)){$entry=$script:Psych0UiCatalog.entries.PSObject.Properties[$script:Psych0UiAliases[$Key]]}}
 if(!$entry){
  foreach($alias in $script:Psych0UiCatalog.aliases){
   $source=[string]$alias.source
   if($source.EndsWith(': ') -and $Key.StartsWith($source,[StringComparison]::Ordinal)){
    $prefix=[string]$script:Psych0UiCatalog.entries.PSObject.Properties[[string]$alias.key].Value.PSObject.Properties[$language].Value
    return $prefix+$Key.Substring($source.Length)
   }
  }
  return $Key
 }
 $text=[string]$entry.Value.PSObject.Properties[$language].Value
 if($Values.Count){return [string]::Format([Globalization.CultureInfo]::GetCultureInfo(@{pl='pl-PL';en='en-US';de='de-DE';ru='ru-RU'}[$language]),$text,$Values)}
 return $text
}
function Get-Psych0MessageButtons([string]$Buttons='OK') {
 $sets=@{OK=@('OK');OKCancel=@('OK','Cancel');YesNo=@('Yes','No');YesNoCancel=@('Yes','No','Cancel');RetryCancel=@('Retry','Cancel');AbortRetryIgnore=@('Abort','Retry','Ignore')}
 $language=$script:Psych0UiLanguage;if($config -and $config.language -in @('pl','en','de','ru')){$language=[string]$config.language}
 $labels=@{pl=@{OK='OK';Yes='Tak';No='Nie';Cancel='Anuluj';Retry='Ponów';Abort='Przerwij';Ignore='Ignoruj'};en=@{OK='OK';Yes='Yes';No='No';Cancel='Cancel';Retry='Retry';Abort='Abort';Ignore='Ignore'};de=@{OK='OK';Yes='Ja';No='Nein';Cancel='Abbrechen';Retry='Wiederholen';Abort='Abbrechen';Ignore='Ignorieren'};ru=@{OK='OK';Yes='Да';No='Нет';Cancel='Отмена';Retry='Повторить';Abort='Прервать';Ignore='Игнорировать'}}
 if(!$sets.ContainsKey($Buttons)){$Buttons='OK'}
 foreach($result in $sets[$Buttons]){[pscustomobject]@{result=$result;text=$labels[$language][$result]}}
}
function Show-Psych0Message([string]$Text,[string]$Caption='Psych0VMod',[string]$Buttons='OK',[string]$Icon='None',[string]$DefaultButton='Button1') {
 $dialog=New-Object Windows.Forms.Form;$dialog.Text=PText $Caption;$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.ShowInTaskbar=$false
 $height=[Math]::Min(500,[Math]::Max(140,80+[int]($Text.Length/80)*20));$dialog.ClientSize=New-Object Drawing.Size(620,$height)
 $body=New-Object Windows.Forms.TextBox;$body.Multiline=$true;$body.ReadOnly=$true;$body.ScrollBars='Vertical';$body.BorderStyle='None';$body.BackColor=[Drawing.SystemColors]::Control;$body.Text=PText $Text;$body.Location=New-Object Drawing.Point(16,16);$body.Size=New-Object Drawing.Size(588,($height-82));$dialog.Controls.Add($body)
 $bar=New-Object Windows.Forms.FlowLayoutPanel;$bar.Dock='Bottom';$bar.Height=55;$bar.Padding=New-Object Windows.Forms.Padding(8);$bar.FlowDirection='RightToLeft';$dialog.Controls.Add($bar)
 $controls=@();$choices=@(Get-Psych0MessageButtons $Buttons)
 foreach($choice in $choices){$button=New-Object Windows.Forms.Button;$button.Text=$choice.text;$button.AutoSize=$true;$button.MinimumSize=New-Object Drawing.Size(100,32);$button.DialogResult=[Windows.Forms.DialogResult]([Enum]::Parse([Windows.Forms.DialogResult],$choice.result));$controls+=$button}
 for($i=$controls.Count-1;$i -ge 0;$i--){$bar.Controls.Add($controls[$i])}
 $index=switch($DefaultButton){Button2{1};Button3{2};default{0}};if($index -ge $controls.Count){$index=0};$dialog.AcceptButton=$controls[$index]
 for($i=0;$i -lt $choices.Count;$i++){if($choices[$i].result -in @('Cancel','No')){$dialog.CancelButton=$controls[$i]}}
 switch($Icon){Warning{$dialog.Icon=[Drawing.SystemIcons]::Warning};Error{$dialog.Icon=[Drawing.SystemIcons]::Error};Information{$dialog.Icon=[Drawing.SystemIcons]::Information};Question{$dialog.Icon=[Drawing.SystemIcons]::Question}}
 try{if($form -and !$form.IsDisposed -and $form.Visible){return $dialog.ShowDialog($form)}else{return $dialog.ShowDialog()}}finally{$dialog.Dispose()}
}
function Get-Psych0ModeLabel([string]$Mode) {
 $language=$script:Psych0UiLanguage;if($config -and $config.language -in @('pl','en','de','ru')){$language=[string]$config.language}
 $words=@{pl=@{offline='Offline';online='Online';hybrid='Hybrydowy'};en=@{offline='Offline';online='Online';hybrid='Hybrid'};de=@{offline='Offline';online='Online';hybrid='Hybrid'};ru=@{offline='Офлайн';online='Онлайн';hybrid='Гибридный'}}
 if($words[$language].ContainsKey($Mode)){return $words[$language][$Mode]};return $Mode
}

function Get-Psych0ProjectNoticeText {
 $newline=[Environment]::NewLine
 $parts=@((PText 'notice_responsibility_title'),(PText 'notice_responsibility_body'),(PText 'notice_support_title'),(PText 'notice_support_body' @((Get-Psych0SupportUri))),(PText 'contact_title'),(PText 'contact_body' @((Get-Psych0ProjectEmail))))
 return (($parts -join ($newline+$newline)) -replace '\r?\n',$newline)
}

function Get-Psych0ProjectEmail { return 'psych0vmod@gmail.com' }
function Get-Psych0ContactUri([switch]$ReportBug,[string]$Version='') {
 $subject=if($ReportBug){PText 'contact_bug_subject'}else{PText 'contact_subject'}
 $uri='mailto:'+(Get-Psych0ProjectEmail)+'?subject='+[Uri]::EscapeDataString($subject)
 if($ReportBug){$body=PText 'contact_bug_body' @($Version);$uri+='&body='+[Uri]::EscapeDataString(($body -replace '\r?\n',[Environment]::NewLine))}
 return $uri
}

function Get-Psych0SupportUri { return 'https://buycoffee.to/psych0vmod' }
