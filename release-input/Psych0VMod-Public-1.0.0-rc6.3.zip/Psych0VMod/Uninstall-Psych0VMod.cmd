@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Uninstall-Psych0VMod.ps1" -AppTarget "%~dp0."
