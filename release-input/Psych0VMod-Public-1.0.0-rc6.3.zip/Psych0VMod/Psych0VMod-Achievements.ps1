﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$script:achievementPending=$null
$script:achievementCatalog=@()
$script:achievementSelected=@{}
$script:achievementSortColumn=1
$script:achievementSortDescending=$false
function Get-AchievementNaturalId([string]$Id) {
    return [regex]::Replace($Id,'\d+',[Text.RegularExpressions.MatchEvaluator]{param($match) $match.Value.PadLeft(12,[char]'0')})
}
function Get-SortedAchievements {
    $primary=@{Expression={
        $entry=$_
        switch($script:achievementSortColumn){
            0 { [int][bool]$entry.awarded }
            2 { Get-AchievementNaturalId ([string]$entry.id) }
            default { [string]$entry.name }
        }
    }}
    return @($script:achievementCatalog | Sort-Object -Property $primary,@{Expression={Get-AchievementNaturalId ([string]$_.id)}} -Descending:$script:achievementSortDescending)
}
function Get-AchievementActionSelection([string]$Operation) {
    $checked=@($script:achievementCatalog | Where-Object {$script:achievementSelected.ContainsKey([string]$_.id)})
    if(!$checked.Count){throw (AText 'Zaznacz osiągnięcia polami wyboru.' 'Check achievement boxes first.')}
    $eligible=@($checked | Where-Object {if($Operation -eq 'clear'){$_.awarded}else{!$_.awarded}})
    if(!$eligible.Count){
        if($Operation -eq 'clear'){throw (AText 'Wybrane osiągnięcia są już niezdobyte. Aby usunąć zdobyte osiągnięcie, wybierz filtr Zdobyte i zaznacz jego pole wyboru.' 'Checked achievements are already locked. To clear an unlocked achievement, select the Unlocked filter and check its box.')}
        throw (AText 'Wybrane osiągnięcia są już zdobyte. Wybierz filtr Niezdobyte i zaznacz osiągnięcie do zdobycia.' 'Checked achievements are already unlocked. Select the Locked filter and check an achievement to unlock.')
    }
    return [string[]]@($eligible | ForEach-Object {[string]$_.id})
}
function Get-AchievementEpoch {return [long][Math]::Floor(([DateTime]::UtcNow-[DateTime]'1970-01-01').TotalSeconds)}
function Write-AchievementJson([string]$Path,$Value) {
    $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{
        $json=$Value|ConvertTo-Json -Depth 8 -Compress
        [IO.File]::WriteAllText($temp,$json,(New-Object Text.UTF8Encoding($false)))
        if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temp,$Path,[NullString]::Value)}else{[IO.File]::Move($temp,$Path)}
    }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Start-AchievementRequest([string]$Operation,[string[]]$Ids=@()) {
    if($null -eq $Ids){$Ids=[string[]]@()}
    if($script:achievementPending){throw (PText 'text_249')}
    if($Operation -notin @('list','unlock','clear','unlock_all','clear_all')){throw (PText 'text_434')}
    $root=Mod-Path
    if(!$root -or !(Test-Path -LiteralPath (Join-Path $root 'psych0vmod_achievements.lua') -PathType Leaf)){
        throw (PText 'text_250')
    }
    if($Operation -in @('unlock','clear')){
        if(!$Ids.Count -or $Ids.Count -gt 5000){throw (PText 'text_251')}
        $known=@{};foreach($item in $script:achievementCatalog){$known[[string]$item.id]=$true}
        $seen=@{}
        foreach($id in $Ids){if(!$known.ContainsKey($id) -or $seen.ContainsKey($id)){throw (PText 'text_252')};$seen[$id]=$true}
    }elseif($Operation -ne 'list' -and !$script:achievementCatalog.Count){throw (PText 'text_253')}
    $nonce=[guid]::NewGuid().ToString('N');$now=Get-AchievementEpoch
    $request=[pscustomobject]@{version=1;appid=218620;nonce=$nonce;operation=$Operation;expires=($now+$(if($Operation -eq 'list'){30}else{180}));ids=@($Ids)}
    $lease=Join-Path $root 'psych0vmod_achievement_lease.json'
    Write-AchievementJson $lease @{nonce=$nonce;until=($now+6)}
    try{Write-AchievementJson (Join-Path $root 'psych0vmod_achievement_request.json') $request}
    catch{Remove-Item -LiteralPath $lease -Force -ErrorAction SilentlyContinue;throw}
    $script:achievementPending=[pscustomobject]@{nonce=$nonce;root=$root;operation=$Operation;expires=$request.expires;lastLease=$now}
    Write-AppLog 'INFO' ('ACHIEVEMENT_REQUEST operation='+$Operation+' selected='+$Ids.Count)
}
function Stop-AchievementRequest {
    $pending=$script:achievementPending;if(!$pending){return}
    try{
        Write-AchievementJson (Join-Path $pending.root ('psych0vmod_achievement_cancel_'+$pending.nonce+'.json')) @{nonce=$pending.nonce}
    }finally{
        Remove-Item -LiteralPath (Join-Path $pending.root 'psych0vmod_achievement_lease.json') -Force -ErrorAction SilentlyContinue
        $script:achievementPending=$null
    }
}
function Read-AchievementReply {
    $pending=$script:achievementPending;if(!$pending){return $null}
    $path=Join-Path $pending.root 'psych0vmod_achievement_result.json'
    $reply=$null
    if(Test-Path -LiteralPath $path -PathType Leaf){
        $tooLarge=$false
        # Lua replaces the result file; a short remove/rename gap is not a failed operation.
        try{
            if((New-Object IO.FileInfo($path)).Length -gt 16777216){$tooLarge=$true}
            else{$reply=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json}
        }catch{$reply=$null}
        if($tooLarge){throw (PText 'text_254')}
    }
    if($reply -and $reply.nonce -eq $pending.nonce){
        if($reply.version -ne 1 -or $reply.status -notin @('pending','done','submitted','error','expired','cancelled')){throw (PText 'text_255')}
        if($reply.status -ne 'pending'){
            # A matching final reply wins over a UI timeout race.
            Remove-Item -LiteralPath (Join-Path $pending.root 'psych0vmod_achievement_lease.json') -Force -ErrorAction SilentlyContinue
            $script:achievementPending=$null
            return $reply
        }
    }
    $now=Get-AchievementEpoch
    if($now -ge $pending.expires){Stop-AchievementRequest;throw (PText 'text_256')}
    if($now-$pending.lastLease -ge 1){
        Write-AchievementJson (Join-Path $pending.root 'psych0vmod_achievement_lease.json') @{nonce=$pending.nonce;until=($now+6)}
        $pending.lastLease=$now
    }
    if($reply -and $reply.nonce -eq $pending.nonce){return $reply}
    return $null
}
function Set-AchievementCatalog($Data) {
    if(!$Data -or $Data.appid -ne 218620 -or $Data.total -lt 1 -or $Data.total -gt 5000 -or @($Data.items).Count -ne $Data.total){throw (PText 'text_257')}
    $seen=@{};$steam=@{}
    foreach($item in @($Data.items)){
        if(!$item.id -or ([string]$item.id).Length -gt 128 -or !$item.steam_id -or $item.awarded -isnot [bool] -or $seen.ContainsKey([string]$item.id) -or $steam.ContainsKey([string]$item.steam_id)){throw (PText 'text_258')}
        $seen[[string]$item.id]=$true;$steam[[string]$item.steam_id]=$true
    }
    $script:achievementCatalog=@($Data.items)
    foreach($id in @($script:achievementSelected.Keys)){if(!$seen.ContainsKey($id)){$script:achievementSelected.Remove($id)}}
}
function Initialize-Achievements($Tabs) {
    $script:achievementEnglish=($config.language -ne 'pl')
    function script:AText($PL,$EN){PText $PL}
    $tab=New-Object Windows.Forms.TabPage;$tab.Name='achievements';$tab.Text=AText 'Osiągnięcia Steam' 'Steam achievements';[void]$Tabs.TabPages.Add($tab)
    $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=5;$layout.Padding=New-Object Windows.Forms.Padding(8);$tab.Controls.Add($layout)
    foreach($height in @(92,42,0,85,66)){
        $style=if($height){New-Object Windows.Forms.RowStyle('Absolute',$height)}else{New-Object Windows.Forms.RowStyle('Percent',100)}
        [void]$layout.RowStyles.Add($style)
    }
    $info=New-Object Windows.Forms.Label;$info.Dock='Fill';$info.Text=AText 'Uruchom PAYDAY 2 przez Steam i pozostaw menu główne. Lista pochodzi z gry i bieżącego konta Steam. Kliknij nagłówek kolumny, aby sortować; ponownie, aby odwrócić kolejność. Zaznacz osiągnięcia polami wyboru; wybór pozostaje po zmianie filtra. „Wszystkie” dotyczy całej listy, także poza filtrem. Usunięcie nie resetuje statystyk postępu; gra może ponownie przyznać osiągnięcia po spełnieniu warunków.' 'Start PAYDAY 2 through Steam and remain in the main menu. The list uses the game and its current Steam account. Click a column header to sort; click again to reverse. Check boxes to select achievements; choices survive filter changes. “All” means the entire catalog, including filtered-out rows. Clearing does not reset progress statistics; the game may award achievements again.';$layout.Controls.Add($info,0,0)
    $filter=New-Object Windows.Forms.FlowLayoutPanel;$filter.Dock='Fill';$layout.Controls.Add($filter,0,1)
    $script:achievementSearch=New-Object Windows.Forms.TextBox;$script:achievementSearch.Width=290;$filter.Controls.Add($script:achievementSearch)
    $script:achievementFilter=New-Object Windows.Forms.ComboBox;$script:achievementFilter.DropDownStyle='DropDownList';$script:achievementFilter.Width=170
    foreach($label in @((AText 'Wszystkie' 'All'),(AText 'Zdobyte' 'Unlocked'),(AText 'Niezdobyte' 'Locked'))){[void]$script:achievementFilter.Items.Add($label)}
    $script:achievementFilter.SelectedIndex=0;$filter.Controls.Add($script:achievementFilter)
    $selectVisible=New-Object Windows.Forms.Button;$selectVisible.Width=155;$selectVisible.Text=AText 'Zaznacz z filtra' 'Check filtered';$filter.Controls.Add($selectVisible)
    $clearSelection=New-Object Windows.Forms.Button;$clearSelection.Width=145;$clearSelection.Text=AText 'Odznacz wybór' 'Uncheck all';$filter.Controls.Add($clearSelection)
    $script:achievementGrid=New-Object Windows.Forms.ListView;$script:achievementGrid.Dock='Fill';$script:achievementGrid.View='Details';$script:achievementGrid.CheckBoxes=$true;$script:achievementGrid.FullRowSelect=$true;$script:achievementGrid.ShowItemToolTips=$true
    foreach($column in @(@((AText 'Stan' 'State'),130),@((AText 'Osiągnięcie' 'Achievement'),380),@('ID',180))){[void]$script:achievementGrid.Columns.Add([string]$column[0],[int]$column[1])}
    $layout.Controls.Add($script:achievementGrid,0,2)
    $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$layout.Controls.Add($buttons,0,3)
    $script:achievementButtons=@()
    foreach($spec in @(@('list',(PText 'text_259'),(PText 'text_259')),@('unlock',(PText 'text_260'),'Unlock checked'),@('clear',(PText 'text_261'),'Clear checked'),@('unlock_all',(PText 'text_262'),(PText 'text_262')),@('clear_all',(PText 'text_263'),(PText 'text_263')))){
        $button=New-Object Windows.Forms.Button;$button.Width=185;$button.Height=30;$button.Text=AText $spec[1] $spec[2];$button.Tag=$spec[0];$buttons.Controls.Add($button);$script:achievementButtons+=@($button)
        $button.Add_Click({param($sender,$eventArgs)
            try{
                $operation=[string]$sender.Tag
                if($operation -eq 'clear_all'){
                    $message=AText ((PText 'text_264')+$script:achievementCatalog.Count+(PText 'text_265')) ((PText 'text_264')+$script:achievementCatalog.Count+' achievements for the current Steam account? Progress stats will remain.')
                    if((Show-Psych0Message -Text ($message) -Caption ('Psych0VMod') -Buttons ('YesNo') -Icon ('Question')) -ne 'Yes'){return}
                }
                $ids=[string[]]@()
                if($operation -in @('unlock','clear')){$ids=[string[]]@(Get-AchievementActionSelection $operation)}
                Start-AchievementRequest $operation $ids
                Set-AchievementBusy $true
                $script:achievementStatus.Text=AText 'Oczekiwanie na grę…' 'Waiting for the game…'
            }catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod — Steam'))}
        })
    }
    $script:achievementCancel=New-Object Windows.Forms.Button;$script:achievementCancel.Width=185;$script:achievementCancel.Height=30;$script:achievementCancel.Text=AText 'Przerwij oczekiwanie' 'Stop waiting';$script:achievementCancel.Enabled=$false;$buttons.Controls.Add($script:achievementCancel)
    $script:achievementStatus=New-Object Windows.Forms.Label;$script:achievementStatus.Dock='Fill';$script:achievementStatus.Text=AText 'Wczytaj listę. Opis osiągnięcia: najedź na wiersz.' 'Load the list. Hover over a row to read its description.';$layout.Controls.Add($script:achievementStatus,0,4)
    function script:Set-AchievementBusy([bool]$Busy){
        foreach($button in $script:achievementButtons){$button.Enabled=(!$Busy -and ($button.Tag -eq 'list' -or $script:achievementCatalog.Count -gt 0))}
        $script:achievementGrid.Enabled=!$Busy;$script:achievementCancel.Enabled=$Busy
    }
    function script:Refresh-AchievementGrid {
        $script:achievementRendering=$true;$script:achievementGrid.BeginUpdate()
        try{
            $script:achievementGrid.Items.Clear();$query=$script:achievementSearch.Text.Trim();$state=$script:achievementFilter.SelectedIndex
            foreach($entry in @(Get-SortedAchievements)){
                if(($state -eq 1 -and !$entry.awarded) -or ($state -eq 2 -and $entry.awarded)){continue}
                if($query -and ([string]($entry.name+' '+$entry.id+' '+$entry.description)).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -lt 0){continue}
                $label=if($entry.awarded){AText 'Zdobyte' 'Unlocked'}else{AText 'Niezdobyte' 'Locked'}
                $item=New-Object Windows.Forms.ListViewItem($label);$item.Tag=$entry;$item.ToolTipText=[string]$entry.description;$item.Checked=$script:achievementSelected.ContainsKey([string]$entry.id)
                [void]$item.SubItems.Add([string]$entry.name);[void]$item.SubItems.Add([string]$entry.id);[void]$script:achievementGrid.Items.Add($item)
            }
        }finally{$script:achievementGrid.EndUpdate();$script:achievementRendering=$false}
    }
    $script:achievementGrid.Add_ItemChecked({param($sender,$eventArgs)
        if($script:achievementRendering -or !$eventArgs.Item.Tag){return};$id=[string]$eventArgs.Item.Tag.id
        if($eventArgs.Item.Checked){$script:achievementSelected[$id]=$true}else{$script:achievementSelected.Remove($id)}
    })
    function script:Update-AchievementSortHeaders {
        $headers=@((AText 'Stan' 'State'),(AText 'Osiągnięcie' 'Achievement'),'ID')
        for($column=0;$column -lt $headers.Count;$column++){
            $label=$headers[$column]
            if($column -eq $script:achievementSortColumn){$label+=if($script:achievementSortDescending){' ▼'}else{' ▲'}}
            $script:achievementGrid.Columns[$column].Text=$label
        }
    }
    $script:achievementGrid.Add_ColumnClick({param($sender,$eventArgs)
        if($eventArgs.Column -eq $script:achievementSortColumn){$script:achievementSortDescending=!$script:achievementSortDescending}
        else{$script:achievementSortColumn=$eventArgs.Column;$script:achievementSortDescending=$false}
        Update-AchievementSortHeaders;Refresh-AchievementGrid
    })
    Update-AchievementSortHeaders
    $script:achievementSearch.Add_TextChanged({Refresh-AchievementGrid});$script:achievementFilter.Add_SelectedIndexChanged({Refresh-AchievementGrid})
    $selectVisible.Add_Click({if(!$script:achievementPending){foreach($item in $script:achievementGrid.Items){$item.Checked=$true}}})
    $clearSelection.Add_Click({if(!$script:achievementPending){$script:achievementSelected=@{};Refresh-AchievementGrid}})
    $script:achievementCancel.Add_Click({try{Stop-AchievementRequest;$script:achievementStatus.Text=AText 'Przerwano oczekiwanie. Sprawdź stan w Steam i odśwież listę.' 'Stopped waiting. Verify Steam state and refresh the list.'}catch{$script:achievementStatus.Text=PText $_.Exception.GetBaseException().Message}finally{Set-AchievementBusy $false}})
    $script:achievementTimer=New-Object Windows.Forms.Timer;$script:achievementTimer.Interval=500
    $script:achievementTimer.Add_Tick({
        if(!$script:achievementPending){return}
        try{
            $reply=Read-AchievementReply;if(!$reply){return}
            if($reply.status -eq 'pending'){$script:achievementStatus.Text=(AText 'Przetwarzanie: ' 'Processing: ')+$reply.data.processed+'/'+$reply.data.total;return}
            Set-AchievementBusy $false
            if($reply.status -in @('done','submitted')){
                Set-AchievementCatalog $reply.data;Refresh-AchievementGrid;Set-AchievementBusy $false
                $unlocked=@($script:achievementCatalog|Where-Object {$_.awarded}).Count
                $summary=(AText 'Zdobyte: ' 'Unlocked: ')+$unlocked+'/'+$script:achievementCatalog.Count
                if($reply.status -eq 'submitted'){$summary+=' — '+(AText 'Zlecono zapis Steam. Odczyt lokalny zgodny; potwierdź zmianę w Steam.' 'Steam save requested. Local state matches; verify the change in Steam.')}
                elseif($reply.detail -eq 'already_in_requested_state'){$summary+=' — '+(AText 'Brak zmian: stan już zgodny.' 'No changes: already in the requested state.')}
                $script:achievementStatus.Text=$summary
            }else{
                $details=@{main_menu_only=(AText 'Pozostaw grę w menu głównym.' 'Remain in the game main menu.');steam_not_ready=(AText 'Uruchom grę przez Steam i poczekaj na inicjalizację konta.' 'Start the game through Steam and wait for account initialization.');catalog_unavailable=(AText 'Lista niedostępna — poczekaj i odśwież.' 'Catalog unavailable — wait and refresh.');invalid_selection=(AText 'Odśwież listę i zaznacz prawidłowe osiągnięcia.' 'Refresh and check valid achievements.');request_revoked=(AText 'Operacja przerwana; zlecono przywrócenie wcześniejszego stanu.' 'Operation cancelled; previous state restoration requested.');rollback_failed=(AText 'Nie potwierdzono przywrócenia. Sprawdź Steam i odśwież listę.' 'Restoration not confirmed. Check Steam and refresh the list.')}
                $script:achievementStatus.Text=if($details.ContainsKey([string]$reply.detail)){$details[[string]$reply.detail]}else{(AText 'Operacja nie została potwierdzona: ' 'Operation not confirmed: ')+$reply.detail}
            }
        }catch{
            try{Stop-AchievementRequest}catch{}
            Set-AchievementBusy $false;$script:achievementStatus.Text=PText $_.Exception.GetBaseException().Message
            Write-AppLog 'WARN' 'ACHIEVEMENT_REPLY_FAILED'
        }
    })
    $script:achievementTimer.Start();Set-AchievementBusy $false
}
