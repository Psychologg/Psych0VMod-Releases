using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class Psych0VModVosk {
    private static readonly Dictionary<string, IntPtr> Models = new Dictionary<string, IntPtr>();
    private static IntPtr library = IntPtr.Zero;
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern void vosk_set_log_level(int level);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern IntPtr vosk_model_new(byte[] path);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern void vosk_model_free(IntPtr model);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern IntPtr vosk_recognizer_new(IntPtr model, float rate);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern void vosk_recognizer_set_words(IntPtr recognizer, int words);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern int vosk_recognizer_accept_waveform(IntPtr recognizer, byte[] data, int length);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern IntPtr vosk_recognizer_result(IntPtr recognizer);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern IntPtr vosk_recognizer_final_result(IntPtr recognizer);
    [DllImport("libvosk.dll", CallingConvention=CallingConvention.Cdecl)]
    private static extern void vosk_recognizer_free(IntPtr recognizer);

    private static string Utf8(IntPtr pointer) {
        if(pointer == IntPtr.Zero) throw new InvalidOperationException("Vosk returned no JSON.");
        int size=0;
        while(Marshal.ReadByte(pointer,size)!=0) {
            if(++size>1024*1024) throw new InvalidOperationException("Vosk JSON is too large.");
        }
        byte[] bytes=new byte[size];Marshal.Copy(pointer,bytes,0,size);
        return Encoding.UTF8.GetString(bytes);
    }
    public static string Recognize(string nativeDirectory,string modelPath,string wavPath) {
        if(!Environment.Is64BitProcess) throw new InvalidOperationException("Vosk requires 64-bit PowerShell.");
        if(library==IntPtr.Zero) {
            library=LoadLibraryEx(Path.GetFullPath(Path.Combine(nativeDirectory,"libvosk.dll")),IntPtr.Zero,0x00000100|0x00001000);
            if(library==IntPtr.Zero) throw new InvalidOperationException("Cannot load Vosk (Windows "+Marshal.GetLastWin32Error()+"). Copy the complete engines folder.");
            vosk_set_log_level(-1);
        }
        modelPath=Path.GetFullPath(modelPath);
        IntPtr model;
        if(!Models.TryGetValue(modelPath,out model)) {
            model=vosk_model_new(Encoding.UTF8.GetBytes(modelPath+"\0"));
            if(model==IntPtr.Zero) throw new InvalidOperationException("Cannot load Vosk language model.");
            Models.Add(modelPath,model);
        }
        byte[] audio=null;
        using(BinaryReader reader=new BinaryReader(File.OpenRead(wavPath))) {
            if(Encoding.ASCII.GetString(reader.ReadBytes(4))!="RIFF") throw new InvalidDataException("Not a WAV.");
            reader.ReadUInt32();
            if(Encoding.ASCII.GetString(reader.ReadBytes(4))!="WAVE") throw new InvalidDataException("Not a WAV.");
            bool valid=false;
            while(reader.BaseStream.Position+8<=reader.BaseStream.Length) {
                string chunk=Encoding.ASCII.GetString(reader.ReadBytes(4));uint length=reader.ReadUInt32();
                long next=reader.BaseStream.Position+length+(length%2);
                if(next>reader.BaseStream.Length) throw new InvalidDataException("Invalid WAV chunk.");
                if(chunk=="fmt ") {
                    if(length<16) throw new InvalidDataException("Invalid WAV format.");
                    ushort format=reader.ReadUInt16(),channels=reader.ReadUInt16();uint rate=reader.ReadUInt32();
                    reader.ReadUInt32();reader.ReadUInt16();ushort bits=reader.ReadUInt16();
                    valid=format==1&&channels==1&&rate==16000&&bits==16;
                } else if(chunk=="data") {
                    if(!valid||length>16000*2*15) throw new InvalidDataException("Expected PCM16 mono 16kHz, at most 15 seconds.");
                    audio=reader.ReadBytes((int)length);break;
                }
                reader.BaseStream.Position=next;
            }
        }
        if(audio==null||audio.Length==0) throw new InvalidDataException("No WAV audio.");
        IntPtr recognizer=vosk_recognizer_new(model,16000);
        if(recognizer==IntPtr.Zero) throw new InvalidOperationException("Cannot create recognizer.");
        try {
            vosk_recognizer_set_words(recognizer,1);
            List<string> results=new List<string>();
            for(int offset=0;offset<audio.Length;offset+=8000) {
                int count=Math.Min(8000,audio.Length-offset);byte[] part=new byte[count];
                Array.Copy(audio,offset,part,0,count);
                int accepted=vosk_recognizer_accept_waveform(recognizer,part,count);
                if(accepted<0) throw new InvalidOperationException("Vosk failed to process audio.");
                if(accepted==1) results.Add(Utf8(vosk_recognizer_result(recognizer)));
            }
            results.Add(Utf8(vosk_recognizer_final_result(recognizer)));
            return "["+string.Join(",",results.ToArray())+"]";
        } finally {vosk_recognizer_free(recognizer);}
    }
    public static void CloseModels() {
        foreach(IntPtr model in Models.Values) vosk_model_free(model);
        Models.Clear();
    }
}
