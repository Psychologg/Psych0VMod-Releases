using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
namespace Psych0Offline {
 public sealed class Node {public int Start,End;public byte Type;public string Text;public bool Encoded;public Dictionary<string,Node> Children;}
 public sealed class Save {
 static readonly byte[] Key={0x74,0x3e,0x3f,0xa4,0x32,0x43,0x26,0x2e,0x23,0x36,0x37,0x6a,0x6d,0x3a,0x48,0x47,0x3d,0x53,0x2d,0x63,0x41,0x6b,0x29,0x38,0x6a,0x68,0x5f,0x4d,0x4a,0x68,0x3c,0x6e,0x66,0xf6};
 static readonly byte[] Pad={0xdf,0xc1,0xa3,0x85,0x67,0x49,0x2b,0x0d,0xed,0xcf,0xb1,0x93};
 static readonly string[] Paths={"MoneyManager/total","MoneyManager/offshore","SkillTreeManager/points","SkillTreeManager/specializations/points","ExperienceManager/level","ExperienceManager/total"};
 byte[] original,plain,body;int bodyStart,bodyEnd;Node root;public string OriginalHash;
 static byte[] Slice(byte[] b,int p,int n){if(p<0||n<0||p>b.Length-n)throw new InvalidDataException("Truncated save");byte[] v=new byte[n];Buffer.BlockCopy(b,p,v,0,n);return v;}
 static byte[] MD(byte[] b){using(var m=MD5.Create())return m.ComputeHash(b);}
 static bool Equal(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 public static string Hash(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","");}
 static byte[] Transform(byte[] b){byte[] v=(byte[])b.Clone();for(int i=0;i<v.Length;i++)v[i]^=unchecked((byte)(Key[((b.Length+i)*7)%34]*(b.Length-i)));return v;}
 static byte[] FinalHash(byte[] b){byte[] v=(byte[])b.Clone();byte[] k={26,31,50,44};for(int i=0;i<v.Length;i++)if(((v[i]+k[i%4])%2)!=0)v[i]=(byte)(i%7);return MD(v);}
 public Save(byte[] bytes){
  if(bytes.Length<100||bytes.Length>16*1024*1024)throw new InvalidDataException("Invalid save size");
  original=(byte[])bytes.Clone();OriginalHash=Hash(bytes);plain=Transform(bytes);
  if(BitConverter.ToInt32(plain,0)!=10)throw new InvalidDataException("Unsupported save version");
  int p=4;
  for(int i=0;i<3;i++){
   int size=BitConverter.ToInt32(Slice(plain,p,4),0);int ver=BitConverter.ToInt32(Slice(plain,p+4,4),0);
   if(size<20||ver!=10)throw new InvalidDataException("Invalid block");
   byte[] data=Slice(plain,p+8,size-20);
   if(!Equal(MD(data),Slice(plain,p+size-12,16)))throw new InvalidDataException("Block checksum mismatch");
   if(i==1){body=data;bodyStart=p;bodyEnd=p+4+size;}p+=4+size;
  }
  if(p+32!=plain.Length||!Equal(FinalHash(Slice(plain,0,plain.Length-16)),Slice(plain,plain.Length-16,16)))throw new InvalidDataException("Save checksum mismatch");
  int cursor=0;root=Read(ref cursor,0);if(cursor!=body.Length||root.Type!=7)throw new InvalidDataException("Unsupported serialized data");
 }
 Node Read(ref int p,int depth){
  if(depth>128||p>=body.Length)throw new InvalidDataException("Invalid tree");
  Node n=new Node();n.Start=p;n.Type=body[p++];int length;
  switch(n.Type){
   case 1:
    int start=p;while(p<body.Length&&body[p]!=0)p++;if(p==body.Length)throw new InvalidDataException("Unterminated string");
    byte[] s=Slice(body,start,p-start);p++;n.Encoded=s.Length>0&&s.Length%2==0&&s.Length/2<=Pad.Length;
    for(int i=1;n.Encoded&&i<s.Length;i+=2)if(s[i]!=Pad[i/2])n.Encoded=false;
    if(n.Encoded){byte[] t=new byte[s.Length/2];for(int i=0;i<t.Length;i++)t[i]=(byte)(254-s[2*i]);n.Text=Encoding.ASCII.GetString(t);}else n.Text=Encoding.UTF8.GetString(s);break;
   case 2:n.Text=BitConverter.ToSingle(Slice(body,p,4),0).ToString("R",CultureInfo.InvariantCulture);p+=4;break;
   case 3:break;
   case 4:n.Text=Slice(body,p,1)[0].ToString();p++;break;
   case 5:n.Text=BitConverter.ToInt16(Slice(body,p,2),0).ToString();p+=2;break;
   case 6:Slice(body,p,1);p++;break;
   case 7:
    int count=BitConverter.ToInt32(Slice(body,p,4),0);p+=4;if(count<0||count>1000000)throw new InvalidDataException("Invalid dictionary count");
    n.Children=new Dictionary<string,Node>();
    for(int i=0;i<count;i++){Node k=Read(ref p,depth+1);Node v=Read(ref p,depth+1);if(k.Text==null||n.Children.ContainsKey(k.Text))throw new InvalidDataException("Unsupported dictionary key");n.Children.Add(k.Text,v);}break;
   case 8:case 9:length=12;Slice(body,p,length);p+=length;break;
   default:throw new InvalidDataException("Unsupported data type: "+n.Type);
  }n.End=p;return n;
 }
 Node Find(string path){Node n=root;foreach(string part in path.Split('/')){if(n.Children==null||!n.Children.TryGetValue(part,out n))throw new InvalidDataException("Missing field: "+path);}return n;}
 public string Get(string path){return Find(path).Text;}
 public string Owner {get{return Get("user_id");}}
 public long PerkMaximum(){
  long max=Number(Get("SkillTreeManager/specializations/max_points")),spent=0;
  foreach(var pair in Find("SkillTreeManager/specializations").Children){long id;if(Int64.TryParse(pair.Key,out id)&&pair.Value.Children!=null&&pair.Value.Children.ContainsKey("points_spent"))spent=checked(spent+Number(pair.Value.Children["points_spent"].Text));}
  if(spent>max)throw new InvalidDataException("Perk accounting is inconsistent");return max-spent;
 }
 static long Number(string text){decimal v;if(!Decimal.TryParse(text,NumberStyles.Float,CultureInfo.InvariantCulture,out v)||v<0||v!=Decimal.Truncate(v)||v>Int64.MaxValue)throw new InvalidDataException("Invalid accounting value");return (long)v;}
 public byte[] Build(string path,string value){
  if(Array.IndexOf(Paths,path)<0)throw new InvalidOperationException("Field not editable");
  long number;if(!Int64.TryParse(value,NumberStyles.None,CultureInfo.InvariantCulture,out number)||number<0)throw new ArgumentException("Invalid value");
  if(path==Paths[4]||path==Paths[5])return BuildExperience(path,number);
  if(path==Paths[3]){
   long available=PerkMaximum();if(number>available)throw new ArgumentException("Maximum available perk points for this save: "+available);
   long oldFree=Number(Get(Paths[3]));long oldTotal=Number(Get("SkillTreeManager/specializations/total_points"));long spent=Number(Get("SkillTreeManager/specializations/max_points"))-available;
   if(oldTotal!=spent+oldFree)throw new InvalidDataException("Perk accounting is inconsistent");
   byte[] next=BuildRaw(path,value);Save work=new Save(next);return work.BuildRaw("SkillTreeManager/specializations/total_points",(spent+number).ToString(CultureInfo.InvariantCulture));
  }
  byte[] result=BuildRaw(path,value);
  if(path==Paths[2]){
   string active=Number(Get("SkillTreeManager/selected_skill_switch")).ToString(CultureInfo.InvariantCulture);
   Save work=new Save(result);work=new Save(work.BuildRaw("SkillTreeManager/skill_switches/"+active+"/points",value));
   string marker="v1;";Node existing;
   if(work.Find("SkillTreeManager").Children.TryGetValue("psych0_skill_points",out existing)){
    if(existing.Type!=1||existing.Text==null||!existing.Text.StartsWith("v1;"))throw new InvalidDataException("Unsupported Psych0 skill metadata");
    var seen=new HashSet<string>();foreach(string entry in existing.Text.Substring(3).Split(';')){if(entry.Length==0)continue;string[] parts=entry.Split('=');long id,pv;if(parts.Length!=2||!Int64.TryParse(parts[0],out id)||id<1||id>100||!Int64.TryParse(parts[1],out pv)||pv<0||pv>1000000||!seen.Add(parts[0]))throw new InvalidDataException("Invalid Psych0 skill metadata");if(parts[0]!=active)marker+=entry+";";}
   }
   return work.UpsertSkillMarker(marker+active+"="+value+";");
  }
  return result;
 }
 public static long LevelCost(int level){
  if(level<1||level>100)throw new ArgumentOutOfRangeException("level");
  long[] first={900,1250,1550,1850,2200,2600,3000,3500,4000};if(level<=9)return first[level-1];
  return (long)Math.Floor(995400*Math.Pow((level-10)/90.0,3)+4600+0.5);
 }
 public static long LevelThreshold(int level){if(level<0||level>100)throw new ArgumentOutOfRangeException("level");long total=0;for(int i=1;i<=level;i++)total+=LevelCost(i);return total;}
 byte[] BuildExperience(string path,long value){
  if(path==Paths[4]&&value>100)throw new ArgumentException("Level must be 0-100");
  if(path==Paths[5]&&value>2000000000)throw new ArgumentException("XP must be 0-2000000000");
  long total=path==Paths[4]?LevelThreshold((int)value):value;int level=0;
  while(level<100&&total>=LevelThreshold(level+1))level++;
  long cost=LevelCost(level==100?100:level+1),progress=level==100?cost:total-LevelThreshold(level);
  Save work=this;
  string[] paths={"ExperienceManager/total","ExperienceManager/xp_gained","ExperienceManager/level","ExperienceManager/next_level_data/points","ExperienceManager/next_level_data/current_points"};
  long[] values={total,total,level,cost,progress};
  for(int i=0;i<paths.Length;i++)work=new Save(work.BuildRaw(paths[i],values[i].ToString(CultureInfo.InvariantCulture)));
  return work.UpsertMarker("ExperienceManager","psych0_xp_edit","v1;"+level+";"+total);
 }
 byte[] BuildRaw(string path,string value){
  long number;if(!Int64.TryParse(value,NumberStyles.None,CultureInfo.InvariantCulture,out number)||number<0||number>(path==Paths[2]?999:999999999999L))throw new ArgumentException("Invalid value");
  Node n=Find(path);byte[] replacement;
  using(var ms=new MemoryStream()){using(var w=new BinaryWriter(ms,Encoding.UTF8,true)){
   w.Write(n.Type);
   if(n.Type==1){byte[] s=Encoding.ASCII.GetBytes(value);if(n.Encoded){if(s.Length>Pad.Length)throw new ArgumentException("Encoded value too long");for(int i=0;i<s.Length;i++){w.Write((byte)(254-s[i]));w.Write(Pad[i]);}}else w.Write(s);w.Write((byte)0);}
   else if(n.Type==4){if(number>255)throw new ArgumentException("This field is limited to 255 in this save");w.Write((byte)number);}
   else if(n.Type==5){if(number>32767)throw new ArgumentException("Value exceeds storage type");w.Write((short)number);}
   else if(n.Type==2){float f=number;if((double)f!=number)throw new ArgumentException("Value cannot be stored exactly");w.Write(f);}
   else throw new InvalidDataException("Unsupported numeric field");
  }replacement=ms.ToArray();}
  byte[] nextBody;
  using(var ms=new MemoryStream()){ms.Write(body,0,n.Start);ms.Write(replacement,0,replacement.Length);ms.Write(body,n.End,body.Length-n.End);nextBody=ms.ToArray();}
  byte[] rebuilt=Rebuild(nextBody);
  Save checkedSave=new Save(rebuilt);if(checkedSave.Get(path)!=value)throw new InvalidDataException("Value verification failed");return rebuilt;
 }
 byte[] Rebuild(byte[] nextBody){
  using(var ms=new MemoryStream()){using(var w=new BinaryWriter(ms,Encoding.UTF8,true)){w.Write(plain,0,bodyStart);w.Write(nextBody.Length+20);w.Write(10);w.Write(nextBody);w.Write(MD(nextBody));w.Write(plain,bodyEnd,plain.Length-bodyEnd-16);}byte[] prefix=ms.ToArray();ms.Write(FinalHash(prefix),0,16);return Transform(ms.ToArray());}
 }
 byte[] UpsertSkillMarker(string text){return UpsertMarker("SkillTreeManager","psych0_skill_points",text);}
 byte[] UpsertMarker(string parentPath,string keyName,string text){
  Node parent=Find(parentPath),old;byte[] insert;
  using(var ms=new MemoryStream()){using(var w=new BinaryWriter(ms,Encoding.UTF8,true)){
   if(!parent.Children.ContainsKey(keyName)){w.Write((byte)1);w.Write(Encoding.UTF8.GetBytes(keyName));w.Write((byte)0);}
   w.Write((byte)1);w.Write(Encoding.UTF8.GetBytes(text));w.Write((byte)0);
  }insert=ms.ToArray();}
  bool exists=parent.Children.TryGetValue(keyName,out old);
  int from=exists?old.Start:parent.End,to=exists?old.End:parent.End;byte[] next;
  using(var ms=new MemoryStream()){ms.Write(body,0,from);ms.Write(insert,0,insert.Length);ms.Write(body,to,body.Length-to);next=ms.ToArray();}
  if(!exists)Buffer.BlockCopy(BitConverter.GetBytes(parent.Children.Count+1),0,next,parent.Start+1,4);
  byte[] result=Rebuild(next);Save verified=new Save(result);if(verified.Get(parentPath+"/"+keyName)!=text)throw new InvalidDataException("Skill marker verification failed");return result;
 }
 public byte[] Unchanged(){return (byte[])original.Clone();}
 }
}
