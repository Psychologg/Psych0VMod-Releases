﻿using System;
using System.IO;
using System.Collections.Generic;

// Local acoustic template, not a transcription engine or calibrated probability.
public static class Psych0VoiceProfile {
    public class Features { public double[][] Frames; public double Seconds; public double Rms; }
    public class Profile { public int Version=2; public double[][] Frames; public double Radius; public double TrainingDistance; }
    public class Match { public double Distance; public double Limit; public bool Accepted; }
    const int N=512, Hop=160, Window=400, Bands=26, Cepstra=12, Dimensions=24;
    static double Mel(double hz) { return 2595*Math.Log10(1+hz/700); }
    static double Hz(double mel) { return 700*(Math.Pow(10,mel/2595)-1); }
    static void Spectrum(double[] real, double[] imag) {
        for(int i=1,j=0;i<N;i++) { int bit=N>>1; for(; (j&bit)!=0;bit>>=1) j^=bit; j^=bit; if(i<j){double t=real[i];real[i]=real[j];real[j]=t;} }
        for(int len=2;len<=N;len<<=1) { double angle=-2*Math.PI/len;
            for(int i=0;i<N;i+=len){double wr=1,wi=0;for(int j=0;j<len/2;j++){int a=i+j,b=a+len/2;double vr=real[b]*wr-imag[b]*wi,vi=real[b]*wi+imag[b]*wr;real[b]=real[a]-vr;imag[b]=imag[a]-vi;real[a]+=vr;imag[a]+=vi;double next=wr*Math.Cos(angle)-wi*Math.Sin(angle);wi=wr*Math.Sin(angle)+wi*Math.Cos(angle);wr=next;}}
        }
    }
    public static Features Extract(string path) { return Extract(path,0); }
    public static Features Extract(string path,int skipMilliseconds) {
        byte[] data=null; int format=0,channels=0,rate=0,bits=0;
        using(var r=new BinaryReader(File.OpenRead(path))) {
            if(new string(r.ReadChars(4))!="RIFF") throw new Exception("Nieprawidłowy WAV / Invalid WAV");r.ReadUInt32();if(new string(r.ReadChars(4))!="WAVE")throw new Exception("Invalid WAVE");
            while(r.BaseStream.Position+8<=r.BaseStream.Length){string id=new string(r.ReadChars(4));uint size=r.ReadUInt32();long end=r.BaseStream.Position+size;if(end>r.BaseStream.Length)throw new Exception("Truncated WAV");
                if(id=="fmt "){if(size<16)throw new Exception("Invalid format");format=r.ReadUInt16();channels=r.ReadUInt16();rate=r.ReadInt32();r.ReadUInt32();r.ReadUInt16();bits=r.ReadUInt16();}
                if(id=="data"){if(size>480000)throw new Exception("Recording exceeds 15 seconds");data=r.ReadBytes((int)size);}
                r.BaseStream.Position=end+(size%2);
            }
        }
        if(format!=1||channels!=1||rate!=16000||bits!=16||data==null)throw new Exception("Wymagany WAV PCM16 mono 16000 Hz / PCM16 mono 16000 Hz required");
        if(skipMilliseconds<0||skipMilliseconds>1000)throw new Exception("Invalid audio offset");
        int skip=skipMilliseconds*32;if(skip>data.Length)throw new Exception("Recording too short");
        if(skip>0){byte[] trimmed=new byte[data.Length-skip];Buffer.BlockCopy(data,skip,trimmed,0,trimmed.Length);data=trimmed;}
        double[] x=new double[data.Length/2];double peak=0,sum=0;int clipped=0;
        for(int i=0;i<x.Length;i++){x[i]=BitConverter.ToInt16(data,i*2)/32768.0;peak=Math.Max(peak,Math.Abs(x[i]));sum+=x[i]*x[i];if(Math.Abs(x[i])>.995)clipped++;}
        if(x.Length<Window||peak<.015||Math.Sqrt(sum/Math.Max(1,x.Length))<.002)throw new Exception("Za cicho lub cisza — nagraj ponownie / Too quiet or silent — record again");
        if(clipped>x.Length*.005)throw new Exception("Przesterowanie — zmniejsz głośność mikrofonu / Clipping — lower microphone gain");
        int count=(x.Length-Window)/Hop+1;double[] energies=new double[count];double max=0;
        for(int f=0;f<count;f++){double e=0;for(int k=0;k<Window;k++)e+=x[f*Hop+k]*x[f*Hop+k];energies[f]=Math.Sqrt(e/Window);max=Math.Max(max,energies[f]);}
        double[] sorted=(double[])energies.Clone();Array.Sort(sorted);double noise=sorted[Math.Max(0,count/10)];if(max<Math.Max(.012,noise*5))throw new Exception("Brak wyraźnej mowy ponad tłem / No clear speech above background");double gate=Math.Max(.004,Math.Max(max*.12,noise*2.5));
        int first=-1,last=-1,active=0,run=0;
        var runs=new List<int[]>();
        for(int f=0;f<=count;f++){
            if(f<count && energies[f]>=gate){run++;continue;}
            if(run>=4)runs.Add(new int[]{f-run,f-1});run=0;
        }
        // Keep the strongest speech region; isolated distant clicks/noise are not words.
        double bestEnergy=-1;int regionStart=-1,regionEnd=-1,regionActive=0;double regionEnergy=0;
        foreach(var segment in runs){
            if(regionEnd>=0 && segment[0]-regionEnd>60){
                if(regionEnergy>bestEnergy){bestEnergy=regionEnergy;first=regionStart;last=regionEnd;active=regionActive;}
                regionStart=-1;regionActive=0;regionEnergy=0;
            }
            if(regionStart<0)regionStart=segment[0];regionEnd=segment[1];regionActive+=segment[1]-segment[0]+1;
            for(int f=segment[0];f<=segment[1];f++)regionEnergy+=energies[f]*energies[f];
        }
        if(regionEnergy>bestEnergy){first=regionStart;last=regionEnd;active=regionActive;}
        if(first<0||active<25)throw new Exception("Za mało mowy lub nadmierny hałas / Too little speech or excessive noise");
        first=Math.Max(0,first-3);last=Math.Min(count-1,last+3);double duration=(last-first)*Hop/16000.0;
        if(duration<.25||duration>5)throw new Exception("Komenda powinna trwać 0,25–5 s / Command should last 0.25–5 s");
        int[] bins=new int[Bands+2];double lo=Mel(80),hi=Mel(7600);for(int i=0;i<bins.Length;i++)bins[i]=(int)Math.Floor((N+1)*Hz(lo+(hi-lo)*i/(Bands+1))/16000);
        var frames=new List<double[]>();
        for(int f=first;f<=last;f++) {double[] real=new double[N],imag=new double[N];int start=f*Hop;
            for(int k=0;k<Window;k++){double previous=start+k>0?x[start+k-1]:0;real[k]=(x[start+k]-.97*previous)*(.54-.46*Math.Cos(2*Math.PI*k/(Window-1)));}Spectrum(real,imag);
            double[] logs=new double[Bands];for(int b=0;b<Bands;b++){double energy=0;for(int k=bins[b];k<bins[b+1];k++)energy+=(real[k]*real[k]+imag[k]*imag[k])*(k-bins[b])/(double)Math.Max(1,bins[b+1]-bins[b]);for(int k=bins[b+1];k<bins[b+2];k++)energy+=(real[k]*real[k]+imag[k]*imag[k])*(bins[b+2]-k)/(double)Math.Max(1,bins[b+2]-bins[b+1]);logs[b]=Math.Log(Math.Max(energy,1e-10));}
            double[] c=new double[Dimensions];for(int d=0;d<Cepstra;d++){for(int b=0;b<Bands;b++)c[d]+=logs[b]*Math.Cos(Math.PI*(d+1)*(b+.5)/Bands);c[d]*=Math.Sqrt(2.0/Bands)/20.0;}frames.Add(c);
        }
        // Retain mean spectral shape: short command vowels/consonants need it.
        // Standard two-frame deltas retain phonetic transitions; no energy coefficient.
        for(int f=0;f<frames.Count;f++)for(int d=0;d<Cepstra;d++){
            double delta=0;for(int n=1;n<=2;n++)delta+=n*(frames[Math.Min(frames.Count-1,f+n)][d]-frames[Math.Max(0,f-n)][d]);
            frames[f][Cepstra+d]=delta/10.0*2.0;
        }
        return new Features{Frames=frames.ToArray(),Seconds=duration,Rms=Math.Sqrt(sum/x.Length)};
    }
    static double Cost(double[] a,double[] b){double s=0;for(int d=0;d<Dimensions;d++){double v=a[d]-b[d];s+=v*v;}return Math.Sqrt(s/Dimensions);}
    static double Align(double[][] a,double[][] b,out List<int[]> path){
        if(a==null||b==null||a.Length<1||b.Length<1||a.Length>550||b.Length>550)throw new Exception("Invalid profile frames");
        foreach(var row in a)if(row==null||row.Length!=Dimensions)throw new Exception("Invalid profile dimensions");foreach(var row in b)if(row==null||row.Length!=Dimensions)throw new Exception("Invalid profile dimensions");
        double[,] scores=new double[a.Length+1,b.Length+1];byte[,] prev=new byte[a.Length+1,b.Length+1];
        for(int i=0;i<=a.Length;i++)for(int j=0;j<=b.Length;j++)scores[i,j]=double.PositiveInfinity;scores[0,0]=0;
        for(int i=1;i<=a.Length;i++)for(int j=1;j<=b.Length;j++){if(Math.Abs(i/(double)a.Length-j/(double)b.Length)>.25)continue;double best=scores[i-1,j-1];byte p=0;if(scores[i-1,j]<best){best=scores[i-1,j];p=1;}if(scores[i,j-1]<best){best=scores[i,j-1];p=2;}scores[i,j]=best+Cost(a[i-1],b[j-1]);prev[i,j]=p;}
        path=new List<int[]>();int ai=a.Length,bj=b.Length;if(double.IsInfinity(scores[ai,bj]))return double.PositiveInfinity;
        while(ai>0&&bj>0){path.Add(new int[]{ai-1,bj-1});byte p=prev[ai,bj];if(p==0){ai--;bj--;}else if(p==1)ai--;else bj--;}
        return scores[a.Length,b.Length]/path.Count;
    }
    public static double Distance(double[][] a,double[][] b){List<int[]> p;return Align(a,b,out p);}
    public static Profile Build(string[] files){return Build(files,new int[]{0,0,0});}
    public static Profile Build(string[] files,int[] skips){
        if(files==null||files.Length!=3||skips==null||skips.Length!=3)throw new Exception("Potrzebne dokładnie 3 próbki / Exactly 3 samples required");
        Features[] samples=new Features[3];for(int i=0;i<3;i++)samples[i]=Extract(files[i],skips[i]);
        double[,] distances=new double[3,3];double worst=0;int medoid=0;double bestSum=double.PositiveInfinity;
        for(int i=0;i<3;i++)for(int j=i+1;j<3;j++){distances[i,j]=distances[j,i]=Distance(samples[i].Frames,samples[j].Frames);worst=Math.Max(worst,distances[i,j]);}
        for(int i=0;i<3;i++){double s=0;for(int j=0;j<3;j++)s+=distances[i,j];if(s<bestSum){bestSum=s;medoid=i;}}
        if(worst>.18)throw new Exception("Próbki zbyt różne — odsłuchaj i powtórz odstającą / Samples differ too much — replay and replace the outlier");
        double[][] reference=samples[medoid].Frames,average=new double[reference.Length][];for(int i=0;i<average.Length;i++)average[i]=new double[Dimensions];
        // One equal contribution per recording, regardless of DTW repetition count.
        for(int s=0;s<3;s++){List<int[]> path;Align(reference,samples[s].Frames,out path);double[][] sums=new double[reference.Length][];int[] n=new int[reference.Length];for(int i=0;i<n.Length;i++)sums[i]=new double[Dimensions];foreach(var pair in path){n[pair[0]]++;for(int d=0;d<Dimensions;d++)sums[pair[0]][d]+=samples[s].Frames[pair[1]][d];}for(int i=0;i<n.Length;i++)for(int d=0;d<Dimensions;d++)average[i][d]+=sums[i][d]/Math.Max(1,n[i])/3;}
        double radius=0;foreach(var s in samples)radius=Math.Max(radius,Distance(average,s.Frames));
        return new Profile{Frames=average,TrainingDistance=worst,Radius=Math.Min(.18,Math.Max(.10,radius*1.5+.035))};
    }
    public static Match Compare(Profile profile,Features input){if(profile==null||profile.Version!=2||profile.Radius<.10||profile.Radius>.18)throw new Exception("Invalid profile version or radius");double duration=(profile.Frames.Length-1)*Hop/16000.0;if(input.Seconds<duration*.4||input.Seconds>duration*2.5)return new Match{Distance=double.PositiveInfinity,Limit=profile.Radius,Accepted=false};double distance=Distance(profile.Frames,input.Frames);return new Match{Distance=distance,Limit=profile.Radius,Accepted=distance<=profile.Radius};}
}
