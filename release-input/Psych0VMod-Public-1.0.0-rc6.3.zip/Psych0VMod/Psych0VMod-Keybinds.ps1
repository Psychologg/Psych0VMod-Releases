﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$script:keybindPending=$null
function Get-KeybindChoices {return @((Get-Content -LiteralPath (Join-Path $AppDir 'keybind_keys.json') -Raw -Encoding UTF8|ConvertFrom-Json).keys)}
function Get-BltKeybindPath {
    if(!$config.payday2_path){throw (FText 'Najpierw ustaw folder PAYDAY 2.' 'Set the PAYDAY 2 folder first.')}
    return Join-Path ([string]$config.payday2_path) 'mods\saves\blt_data.txt'
}
function Read-BltKeybindData {
    $path=Get-BltKeybindPath
    if(!(Test-Path -LiteralPath $path)){throw (FText 'Brak ustawień BLT. Uruchom grę z modem i zamknij ją raz.' 'BLT settings missing. Start and close the modded game once.')}
    $raw=[IO.File]::ReadAllText($path)
    try{$data=$raw|ConvertFrom-Json}catch{throw (FText 'Plik BLT jest uszkodzony. Nie został zmieniony.' 'BLT file is invalid and was not changed.')}
    if($data -isnot [pscustomobject] -or !$data.PSObject.Properties['keybinds'] -or $data.keybinds -isnot [array]){throw (FText 'Nieobsługiwany format pliku BLT. Nie został zmieniony.' 'Unsupported BLT format. File unchanged.')}
    $ids=@{}
    foreach($b in $data.keybinds){if($b -isnot [pscustomobject] -or !$b.id -or $ids.ContainsKey([string]$b.id)){throw (FText 'Nieprawidłowe wpisy skrótów BLT.' 'Invalid BLT keybind entries.')};$ids[[string]$b.id]=$true}
    return [pscustomobject]@{path=$path;raw=$raw;data=$data}
}
function Assert-Psych0Keybind([string]$Id,[string]$Key) {
    $root=Mod-Path
    if(!$root){throw (FText 'Ustaw folder gry.' 'Set the game folder.')}
    $defs=Get-Content -LiteralPath (Join-Path $root 'mod.txt') -Raw -Encoding UTF8|ConvertFrom-Json
    if(!@($defs.keybinds|Where-Object {$_.keybind_id -ceq $Id}).Count){throw (FText 'Brak skrótu w zainstalowanym modzie. Zaktualizuj mod.' 'Binding missing in the installed mod. Update the mod.')}
    if($Key -ne '' -and !@((Get-KeybindChoices)|Where-Object {$_.key -ceq $Key}).Count){throw (FText 'Nieobsługiwany klawisz.' 'Unsupported key.')}
}
function Test-PaydayKeybindGameRunning {
    return @((Get-Process -Name 'payday2_win32_release','payday2_win32_release_vr' -ErrorAction SilentlyContinue)).Count -gt 0
}
function Get-KeybindLiveStatus {
    $root=Mod-Path;if(!$root){return $null}
    $path=Join-Path $root 'psych0vmod_keybind_status.json'
    if(!(Test-Path -LiteralPath $path)){return $null}
    try{$s=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json;if($s.version -eq 1 -and $s.time -le (Get-FeatureEpoch)+2 -and $s.time -ge (Get-FeatureEpoch)-5){return $s}}catch{}
    return $null
}
function Get-Psych0AssignedKey([string]$Id) {
    $live=Get-KeybindLiveStatus
    if($live){$b=@($live.bindings|Where-Object {$_.id -ceq $Id});if($b.Count){return [string]$b[0].pc}}
    $doc=Read-BltKeybindData;$b=@($doc.data.keybinds|Where-Object {$_.id -ceq $Id})
    if($b.Count){return [string]$b[0].pc};return ''
}
function Get-Psych0KeybindConflicts([string]$Id,[string]$Key) {
    if(!$Key){return @()}
    $entries=@{}
    foreach($b in (Read-BltKeybindData).data.keybinds){$entries[[string]$b.id]=$b}
    $live=Get-KeybindLiveStatus
    if($live){foreach($b in $live.bindings){$entries[[string]$b.id]=$b}}
    return @($entries.Values|Where-Object {$_.id -cne $Id -and $_.pc -ceq $Key}|Sort-Object id)
}
function Confirm-Psych0KeybindTransfer([string]$Id,[string]$Key,$Conflicts) {
    $names=@($Conflicts|ForEach-Object {$b=$_;$a=@($script:featureCatalog|Where-Object {$_.keybind_id -ceq $b.id});if($a.Count){FText $a[0].pl $a[0].en}elseif($b.name){[string]$b.name}else{[string]$b.id}})
    $target=@($script:featureCatalog|Where-Object {$_.keybind_id -ceq $Id});$targetName=$Id;if($target.Count){$targetName=FText $target[0].pl $target[0].en}
    $message=(FText 'Klawisz ' 'Key ')+$Key.ToUpperInvariant()+(FText ' jest przypisany do:' ' is assigned to:')+"`r`n"+($names -join "`r`n")+"`r`n`r`n"+(FText 'Czy usunąć te przypisania i przenieść klawisz do: ' 'Remove these assignments and transfer the key to: ')+$targetName+'?'
    return (Show-Psych0Message -Text ($message) -Caption ((FText 'Przenieść klawisz?' 'Transfer key?')) -Buttons ([Windows.Forms.MessageBoxButtons]::YesNo) -Icon ([Windows.Forms.MessageBoxIcon]::Warning) -DefaultButton ([Windows.Forms.MessageBoxDefaultButton]::Button2)) -eq [Windows.Forms.DialogResult]::Yes
}
function Save-Psych0KeybindWithConfirmation([string]$Id,[string]$Key) {
    Assert-Psych0Keybind $Id $Key
    $conflicts=@(Get-Psych0KeybindConflicts $Id $Key)
    if($conflicts.Count -and !(Confirm-Psych0KeybindTransfer $Id $Key $conflicts)){return (FText 'Anulowano. Przypisania bez zmian.' 'Cancelled. Assignments unchanged.')}
    return Save-Psych0Keybind $Id $Key @($conflicts|ForEach-Object {[string]$_.id})
}
function Save-Psych0Keybind([string]$Id,[string]$Key,[string[]]$ReplaceIds=@()) {
    if($script:keybindPending){throw (FText 'Poczekaj na potwierdzenie poprzedniego zapisu.' 'Wait for the previous keybind result.')}
    Assert-Psych0Keybind $Id $Key
    $live=Get-KeybindLiveStatus
    if($live -or (Test-PaydayKeybindGameRunning)){
        if(!$live -or !$live.ready){throw (FText 'Gra działa, ale mostek skrótów nie jest gotowy. Zaktualizuj mod lub zamknij grę.' 'Game running, but keybind bridge unavailable. Update the mod or close the game.')}
        $nonce=[guid]::NewGuid().ToString('N');$expires=(Get-FeatureEpoch)+15
        Write-FeatureJson (Join-Path (Mod-Path) 'psych0vmod_keybind_request.json') @{version=1;nonce=$nonce;expires=$expires;id=$Id;key=$Key;replace_ids=@($ReplaceIds)}
        $script:keybindPending=[pscustomobject]@{nonce=$nonce;expires=$expires}
        return (FText 'Wysłano przypisanie do gry; czekam na zapis BLT.' 'Sent binding to game; waiting for BLT save.')
    }
    $doc=Read-BltKeybindData
    if($Key -ne ''){foreach($b in @($doc.data.keybinds|Where-Object {$_.id -cne $Id -and $_.pc -ceq $Key})){if($ReplaceIds -cnotcontains [string]$b.id){throw ((FText 'Klawisz zajęty przez: ' 'Key already assigned to: ')+$b.id)};$b.pc=''}}
    $found=@($doc.data.keybinds|Where-Object {$_.id -ceq $Id})
    if($found.Count){$found[0]|Add-Member -NotePropertyName pc -NotePropertyValue $Key -Force}
    else{$doc.data.keybinds=@($doc.data.keybinds)+@([pscustomobject]@{id=$Id;pc=$Key})}
    if((Test-PaydayKeybindGameRunning) -or (Get-KeybindLiveStatus)){throw (FText 'Gra została uruchomiona. Ponów zapis przez mostek.' 'Game started. Retry via the bridge.')}
    if([IO.File]::ReadAllText($doc.path) -cne $doc.raw){throw (FText 'Plik BLT zmienił się. Ponów zapis.' 'BLT file changed. Retry save.')}
    $tmp=$doc.path+'.psych0.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{
        [IO.File]::WriteAllText($tmp,($doc.data|ConvertTo-Json -Depth 100),(New-Object Text.UTF8Encoding($false)))
        [IO.File]::Replace($tmp,$doc.path,$doc.path+'.psych0-keybind.bak')
    }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
    $check=Read-BltKeybindData
    if(!@($check.data.keybinds|Where-Object {$_.id -ceq $Id -and $_.pc -ceq $Key}).Count){throw (PText 'text_402')}
    return (FText 'Klawisz zapisany w pliku BLT gry.' 'Key saved in the game BLT file.')
}
function Poll-Psych0KeybindResult {
    if(!$script:keybindPending){return}
    $path=Join-Path (Mod-Path) 'psych0vmod_keybind_result.json'
    if(Test-Path -LiteralPath $path){
        $r=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
        if($r.nonce -ceq $script:keybindPending.nonce){
            $script:keybindPending=$null
            if($r.status -ne 'done'){throw ([string]$r.detail)}
            if($script:featureStatus){$script:featureStatus.Text=FText 'Klawisz zapisany w BLT i aktywny w grze.' 'Key saved in BLT and active in-game.'}
            Update-Psych0KeybindSelection
            return
        }
    }
    if((Get-FeatureEpoch) -ge $script:keybindPending.expires){$script:keybindPending=$null;Remove-Item -LiteralPath (Join-Path (Mod-Path) 'psych0vmod_keybind_request.json') -Force -ErrorAction SilentlyContinue;throw (FText 'Brak potwierdzenia zapisu klawisza. Odśwież i sprawdź przypisanie.' 'No keybind save confirmation. Refresh and check the binding.')}
}
