﻿param([string]$Payday2Path = "",[switch]$HideConsole)
# ConsoleHost progress rendering cannot use a detached console. GUI owns status.
$global:ProgressPreference = 'SilentlyContinue'
if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$ErrorActionPreference = "Stop"
$script:startupStage="assemblies"
$script:processExitCode=0
try {

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class Psych0WindowVisibility {
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
    [DllImport("kernel32.dll")] public static extern bool FreeConsole();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr window, int command);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr window);
}
"@
$consoleWindow=[Psych0WindowVisibility]::GetConsoleWindow()
if($consoleWindow -ne [IntPtr]::Zero){
    # Windows may use STARTUPINFO for the first ShowWindow call; repeat SW_HIDE.
    [void][Psych0WindowVisibility]::ShowWindow($consoleWindow,0)
    [void][Psych0WindowVisibility]::ShowWindow($consoleWindow,0)
}
[void][Psych0WindowVisibility]::FreeConsole()

$ErrorActionPreference = "Stop"
$createdNew=$false
$script:singleInstanceMutex=[Threading.Mutex]::new($false,"Local\Psych0VMod",[ref]$createdNew)
try{$script:ownsInstanceMutex=$script:singleInstanceMutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$script:ownsInstanceMutex=$true}
if(!$script:ownsInstanceMutex){(Show-Psych0Message -Text ((PText 'text_289')) -Caption ('Psych0VMod'))|Out-Null;exit}
$AppVersion = "1.0.0-rc6.3"
$ModVersion = "1.0.0-rc1"
$AppDir = $PSScriptRoot
$ReleaseChannel=Get-Psych0Channel
$DataDir = Get-Psych0DataDirectory
$ConfigFile = Join-Path $DataDir "config.json"
$MacroFile = Join-Path $DataDir "macros.json"
$SamplesDir = Join-Path $DataDir "samples"
$SamplesFile = Join-Path $SamplesDir "index.json"
$BackupDir = Join-Path $DataDir "backups"
$LogDir = Join-Path $DataDir "logs"
$UpdateManifestId = $ReleaseChannel.manifest_id
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
New-Item -ItemType Directory -Force -Path $SamplesDir | Out-Null
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Write-AppLog([string]$Level,[string]$Message) {
    try{
        $Message=$Message -replace "(?i)(key=)[^&\s]+",'$1***'
        $log=Join-Path $LogDir 'Psych0VMod.log'
        if((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).Length -ge 1048576){
            $oldest=$log+'.3';if(Test-Path -LiteralPath $oldest){Remove-Item -LiteralPath $oldest -Force}
            for($i=2;$i -ge 1;$i--){$old=$log+'.'+$i;if(Test-Path -LiteralPath $old){Move-Item -LiteralPath $old -Destination ($log+'.'+($i+1)) -Force}}
            Move-Item -LiteralPath $log -Destination ($log+'.1') -Force
        }
        $line="{0} [{1}] {2}" -f [DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss'),$Level,$Message
        Add-Content -Encoding UTF8 -LiteralPath $log -Value $line
    }catch{
        # Logging must never prevent startup, recognition or update recovery.
        [Diagnostics.Trace]::WriteLine('Psych0VMod: local log unavailable')
    }
}

function Read-JsonFile($Path, $Fallback) {
    if (!(Test-Path $Path)) { return $Fallback }
    try {
        $text=Get-Content -Raw -Encoding UTF8 $Path
        if([string]::IsNullOrWhiteSpace($text)){return $Fallback}
        $value=ConvertFrom-Json -InputObject $text
        if($null -eq $value){return $Fallback}
        return $value
    } catch { Write-AppLog "WARN" "Cannot read JSON: $([IO.Path]::GetFileName($Path))";return $Fallback }
}
function Save-JsonFile($Path, $Value) {
    $temp=$Path+"."+[guid]::NewGuid().ToString("N")+".tmp"
    try {
        ConvertTo-Json -InputObject $Value -Depth 12 | Set-Content -Encoding UTF8 -Path $temp
        Move-Item -Force -Path $temp -Destination $Path
    }finally{if(Test-Path $temp){Remove-Item -Force $temp -ErrorAction SilentlyContinue}}
}
function Repair-AppConfiguration($Value) {
    $changed=$false
    if($Value -isnot [pscustomobject]){$Value=[pscustomobject]@{};$changed=$true}
    $choices=@{language=@('pl','en','de','ru');speech_language=@('pl','en','de','ru');voice_mode=@('offline','online','hybrid')}
    $fallbacks=@{language='pl';speech_language='pl';voice_mode='offline'}
    foreach($name in $choices.Keys){
        if(!$Value.PSObject.Properties[$name] -or [string]$Value.$name -notin $choices[$name]){$Value|Add-Member -NotePropertyName $name -NotePropertyValue $fallbacks[$name] -Force;$changed=$true}
    }
    foreach($rule in @(@('listen_seconds',1,10,3),@('duck_percent',0,100,70),@('minimum_confidence',0.01,1,0.80))){
        $name=[string]$rule[0];$valid=$false;$number=0.0
        if($Value.PSObject.Properties[$name] -and $null -ne $Value.$name -and $Value.$name -isnot [bool]){
            try{$number=[double]$Value.$name;$valid=(![double]::IsNaN($number) -and ![double]::IsInfinity($number) -and $number -ge $rule[1] -and $number -le $rule[2]);if($name -ne 'minimum_confidence' -and $number -ne [Math]::Truncate($number)){$valid=$false}}catch{}
        }
        if(!$valid){$Value|Add-Member -NotePropertyName $name -NotePropertyValue $rule[3] -Force;$changed=$true}
    }
    foreach($name in @('onboarding_completed','profile_actions_enabled','start_with_game','start_with_windows')){
        if(!$Value.PSObject.Properties[$name]){$Value|Add-Member -NotePropertyName $name -NotePropertyValue $false;$changed=$true}
        elseif($Value.$name -isnot [bool]){
            $parsed=$false
            if($Value.$name -is [string]){[void][bool]::TryParse($Value.$name,[ref]$parsed)}
            $Value.$name=$parsed;$changed=$true
        }
    }
    return [pscustomobject]@{config=$Value;changed=$changed}
}

function Normalize-Phrase([string]$Value) {
    if(!$Value){return ""}
    return (($Value.ToLowerInvariant() -replace "[^\p{L}\p{Nd}\s]"," " -replace "\s+"," ").Trim())
}
function Protect-Secret([string]$Value) {
    if(!$Value){return ""}
    Add-Type -AssemblyName System.Security
    $bytes=[Text.Encoding]::UTF8.GetBytes($Value)
    return [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))
}
function Unprotect-Secret([string]$Value) {
    if(!$Value){return ""}
    try {$bytes=[Convert]::FromBase64String($Value);return [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))}catch{return ""}
}

function Initialize-AudioApi {
    if("Psych0VModAudio" -as [type]) { return }
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class Psych0VModAudio {
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumerator {}

    private enum EDataFlow { eRender, eCapture, eAll }
    private enum ERole { eConsole, eMultimedia, eCommunications }

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("A95664D2-9614-4F35-A746-DE8DB63617E6")]
    private interface IMMDeviceEnumerator {
        int EnumAudioEndpoints(EDataFlow dataFlow, int stateMask, out object devices);
        int GetDefaultAudioEndpoint(EDataFlow dataFlow, ERole role, out IMMDevice endpoint);
        int GetDevice(string id, out IMMDevice device);
        int RegisterEndpointNotificationCallback(IntPtr client);
        int UnregisterEndpointNotificationCallback(IntPtr client);
    }

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("D666063F-1587-4E43-81F1-B948E807363F")]
    private interface IMMDevice {
        int Activate(ref Guid iid, int context, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object result);
    }

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("5CDF2C82-841E-4546-9722-0CF74078229A")]
    private interface IAudioEndpointVolume {
        int RegisterControlChangeNotify(IntPtr notify);
        int UnregisterControlChangeNotify(IntPtr notify);
        int GetChannelCount(out uint count);
        int SetMasterVolumeLevel(float levelDb, Guid context);
        int SetMasterVolumeLevelScalar(float level, Guid context);
        int GetMasterVolumeLevel(out float levelDb);
        int GetMasterVolumeLevelScalar(out float level);
    }

    private static IAudioEndpointVolume Endpoint() {
        IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumerator());
        IMMDevice device;
        Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia, out device));
        Guid iid = typeof(IAudioEndpointVolume).GUID;
        object endpoint;
        Marshal.ThrowExceptionForHR(device.Activate(ref iid, 23, IntPtr.Zero, out endpoint));
        return (IAudioEndpointVolume)endpoint;
    }

    public static float GetVolume() {
        float value;
        Marshal.ThrowExceptionForHR(Endpoint().GetMasterVolumeLevelScalar(out value));
        return value;
    }

    public static void SetVolume(float value) {
        value = Math.Max(0f, Math.Min(1f, value));
        Marshal.ThrowExceptionForHR(Endpoint().SetMasterVolumeLevelScalar(value, Guid.Empty));
    }
}
"@
}

function Start-AudioDuck {
    Initialize-AudioApi
    $previous=[Psych0VModAudio]::GetVolume()
    $factor=[Math]::Max(0, 100-[int]$config.duck_percent)/100.0
    [Psych0VModAudio]::SetVolume([single]($previous*$factor))
    return $previous
}

function Stop-AudioDuck($PreviousVolume) {
    if($null -ne $PreviousVolume){[Psych0VModAudio]::SetVolume([single]$PreviousVolume)}
}

function Initialize-HotkeyApi {
    if("Psych0VModHotKeyWindow" -as [type]) { return }
    Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public sealed class Psych0VModHotKeyWindow : NativeWindow, IDisposable {
    private const int WM_HOTKEY = 0x0312;
    private const int ID = 0x5056;
    public event EventHandler HotKeyPressed;

    [DllImport("user32.dll", SetLastError=true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);
    [DllImport("user32.dll", SetLastError=true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    public Psych0VModHotKeyWindow(uint modifiers, uint virtualKey) {
        CreateHandle(new CreateParams());
        if (!RegisterHotKey(Handle, ID, modifiers, virtualKey)) {
            int error = Marshal.GetLastWin32Error();
            DestroyHandle();
            throw new InvalidOperationException("Nie można zarejestrować klawisza globalnego. Kod Windows: " + error);
        }
    }

    protected override void WndProc(ref Message message) {
        if (message.Msg == WM_HOTKEY && message.WParam.ToInt32() == ID) {
            EventHandler handler = HotKeyPressed;
            if (handler != null) handler(this, EventArgs.Empty);
        }
        base.WndProc(ref message);
    }

    public void Dispose() {
        if (Handle != IntPtr.Zero) {
            UnregisterHotKey(Handle, ID);
            DestroyHandle();
        }
    }
}
"@
}

function Convert-Hotkey([string]$Text) {
    $parts=@($Text -split "\+" | ForEach-Object {$_.Trim()} | Where-Object {$_})
    if($parts.Count -eq 0){throw (PText 'text_290')}
    [uint32]$modifiers=0
    for($i=0;$i -lt $parts.Count-1;$i++){
        switch($parts[$i].ToLowerInvariant()){
            "alt" {$modifiers=$modifiers -bor 1}
            "ctrl" {$modifiers=$modifiers -bor 2}
            "control" {$modifiers=$modifiers -bor 2}
            "shift" {$modifiers=$modifiers -bor 4}
            "win" {$modifiers=$modifiers -bor 8}
            default {throw (PText 'text_332' @($($parts[$i])))}
        }
    }
    try{$key=[System.Windows.Forms.Keys][Enum]::Parse([System.Windows.Forms.Keys],$parts[-1],$true)}catch{throw (PText 'text_333' @($($parts[-1])))}
    return [pscustomobject]@{modifiers=$modifiers;key=[uint32]$key}
}

function Update-GameShortcut([bool]$Enabled) {
    $desktop=[Environment]::GetFolderPath("Desktop")
    $shortcutPath=Join-Path $desktop "PAYDAY 2 + Psych0VMod.lnk"
    if(!$Enabled){if(Test-Path $shortcutPath){Remove-Item -Force $shortcutPath};return}
    $launcher=Join-Path $AppDir "Psych0VMod-GameLauncher.ps1"
    if(!(Test-Path $launcher)){throw (PText 'text_441')}
    $shell=New-Object -ComObject WScript.Shell
    $shortcut=$shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath="powershell.exe"
    $shortcut.Arguments="-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$launcher`""
    $shortcut.WorkingDirectory=$AppDir
    $iconPath=Join-Path $AppDir "Psych0VMod.ico"
    if(Test-Path -LiteralPath $iconPath){$shortcut.IconLocation=$iconPath+",0"}
    $shortcut.Save()
}

function Find-Payday2Path {
    $candidates=@()
    try {$steam=(Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction Stop).SteamPath;if($steam){$candidates+=(Join-Path $steam "steamapps\common\PAYDAY 2")}}catch{}
    $candidates+=@("C:\Program Files (x86)\Steam\steamapps\common\PAYDAY 2","C:\Program Files\Steam\steamapps\common\PAYDAY 2")
    foreach($candidate in $candidates){if((Test-Path (Join-Path $candidate "PAYDAY2.exe")) -or (Test-Path (Join-Path $candidate "payday2_win32_release.exe"))){return $candidate}}
    return ""
}

$script:startupStage="configuration"
$defaultConfig = [pscustomobject]@{ language="pl"; payday2_path=$Payday2Path; listen_seconds=3; duck_percent=70; voice_mode="offline"; minimum_confidence=0.65; start_with_windows=$false }
$config = Read-JsonFile $ConfigFile $defaultConfig
$checkedConfig=Repair-AppConfiguration $config
$config=$checkedConfig.config
if($checkedConfig.changed){
    if(Test-Path $ConfigFile){$configRecovery=$ConfigFile+'.before-repair-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8);Copy-Item -LiteralPath $ConfigFile -Destination $configRecovery}
    Save-JsonFile $ConfigFile $config
    Write-AppLog 'WARN' 'Configuration fields repaired; original file preserved when present.'
}
if ($Payday2Path) { $config.payday2_path = $Payday2Path }
$required=@{language="pl";payday2_path="";listen_seconds=3;duck_percent=70;voice_mode="offline";minimum_confidence=0.65;hotkey="Ctrl+Shift+V";start_with_game=$false;google_api_key_encrypted="";onboarding_completed=$false}
foreach($name in $required.Keys){if(!$config.PSObject.Properties[$name]){$config|Add-Member -NotePropertyName $name -NotePropertyValue $required[$name]}}
if(!$config.payday2_path){$detected=Find-Payday2Path;if($detected){$config.payday2_path=$detected;Save-JsonFile $ConfigFile $config}}
if(!$config.PSObject.Properties['speech_language']){$config|Add-Member -NotePropertyName speech_language -NotePropertyValue ([string]$config.language)}
if(!$config.PSObject.Properties["vosk_threshold_migrated"]){$config.minimum_confidence=0.80;$config|Add-Member -NotePropertyName vosk_threshold_migrated -NotePropertyValue $true;Save-JsonFile $ConfigFile $config}
$script:macros = @(Read-JsonFile $MacroFile @() | Where-Object {$null -ne $_})
$script:samples = @(Read-JsonFile $SamplesFile @() | Where-Object {$null -ne $_})
$catalog = (Get-Content -Raw -Encoding UTF8 (Join-Path $AppDir "actions.json") | ConvertFrom-Json).actions

$script:startupStage="macro and sample migration"
$ProfilesDir=Join-Path $SamplesDir "profiles"
New-Item -ItemType Directory -Force -Path $ProfilesDir | Out-Null
foreach($m in $script:macros){
    if(!$m.PSObject.Properties["phrase"] -or !$m.PSObject.Properties["action"]){throw (PText 'text_291')}
    if(!$m.PSObject.Properties["id"]){$m|Add-Member -NotePropertyName id -NotePropertyValue ([guid]::NewGuid().ToString("N"))}
    if(!$m.PSObject.Properties["language"]){$m|Add-Member -NotePropertyName language -NotePropertyValue ([string]$config.speech_language)}
}
Save-JsonFile $MacroFile $script:macros
foreach($sample in $script:samples){
    if(!$sample.PSObject.Properties["macro_id"]){
        $owner=@($script:macros|Where-Object {$_.phrase -eq $sample.phrase -and $_.action -eq $sample.action})|Select-Object -First 1
        if($owner){$sample|Add-Member -NotePropertyName macro_id -NotePropertyValue ([string]$owner.id)}
    }
}
Save-JsonFile $SamplesFile $script:samples
if(!$config.PSObject.Properties["profile_actions_enabled"]){$config|Add-Member -NotePropertyName profile_actions_enabled -NotePropertyValue $false}

$script:startupStage="translations"
$ui = @{
    pl=@{title="Psych0VMod"; config="Konfiguracja"; test="Funkcje moda"; macros="Moje makra"; samples="Próbki głosu"; updates="Aktualizacje"; backups="Kopie zapasowe"; info="Info"; game="Folder PAYDAY 2"; browse="Wybierz"; language="Język"; mode="Tryb rozpoznawania"; seconds="Czas nasłuchu (s)"; duck="Przyciszenie gry (%)"; confidence="Minimalna pewność (%)"; hotkey="Klawisz nasłuchu"; start_game="Utwórz skrót uruchamiający grę razem z Psych0VMod"; save="Zapisz"; phrase="Komenda głosowa"; action="Funkcja"; add="Dodaj / zaktualizuj"; remove="Usuń"; listen="Nasłuchuj i testuj"; run="Wykonaj zaznaczoną funkcję"; heard="Usłyszano"; ready="Gotowy"; record="Nagraj próbkę"; play="Odtwórz"; sample_help="Wybierz makro i nagraj je 3 razy. Mów naturalnie po sygnale. Zmiana mikrofonu, duży hałas lub inny sposób mówienia może wymagać ponownego nagrania."; check="Sprawdź aktualizacje"; install="Zainstaluj Psych0Mod"; install_app="Zaktualizuj Psych0VMod"; make_backup="Utwórz kopię"; restore="Przywróć zaznaczoną"; refresh="Odśwież listę"}
    en=@{title="Psych0VMod"; config="Configuration"; test="Mod functions"; macros="My macros"; samples="Voice samples"; updates="Updates"; backups="Backups"; info="Info"; game="PAYDAY 2 folder"; browse="Browse"; language="Language"; mode="Recognition mode"; seconds="Listening time (s)"; duck="Game volume reduction (%)"; confidence="Minimum confidence (%)"; hotkey="Listening hotkey"; start_game="Create a shortcut that starts the game with Psych0VMod"; save="Save"; phrase="Voice command"; action="Action"; add="Add / update"; remove="Remove"; listen="Listen and test"; run="Run selected action"; heard="Heard"; ready="Ready"; record="Record sample"; play="Play"; sample_help="Select a macro and record it 3 times. Speak naturally after the prompt. A different microphone, loud noise, or a very different speaking style may require new samples."; check="Check for updates"; install="Install Psych0Mod"; install_app="Update Psych0VMod"; make_backup="Create backup"; restore="Restore selected"; refresh="Refresh list"}
    de=@{title="Psych0VMod"; config="Konfiguration"; test="Mod-Funktionen"; macros="Meine Makros"; samples="Sprachproben"; updates="Aktualisierungen"; backups="Sicherungen"; info="Info"; game="PAYDAY-2-Ordner"; browse="Auswählen"; language="Sprache"; mode="Erkennungsmodus"; seconds="Hörzeit (s)"; duck="Spiellautstärke senken (%)"; confidence="Mindestzuverlässigkeit (%)"; hotkey="Hörtaste"; start_game="Verknüpfung für Spielstart mit Psych0VMod erstellen"; save="Speichern"; phrase="Sprachbefehl"; action="Aktion"; add="Hinzufügen / aktualisieren"; remove="Entfernen"; listen="Anhören und testen"; run="Ausgewählte Aktion starten"; heard="Erkannt"; ready="Bereit"; record="Probe aufnehmen"; play="Abspielen"; sample_help="Wählen Sie ein Makro und nehmen Sie es dreimal auf. Sprechen Sie nach dem Hinweis natürlich. Ein anderes Mikrofon, starker Lärm oder eine andere Aussprache kann neue Proben erfordern."; check="Nach Updates suchen"; install="Psych0Mod installieren"; install_app="Psych0VMod aktualisieren"; make_backup="Sicherung erstellen"; restore="Auswahl wiederherstellen"; refresh="Liste aktualisieren"}
    ru=@{title="Psych0VMod"; config="Настройки"; test="Функции мода"; macros="Мои макросы"; samples="Образцы голоса"; updates="Обновления"; backups="Резервные копии"; info="Информация"; game="Папка PAYDAY 2"; browse="Выбрать"; language="Язык"; mode="Режим распознавания"; seconds="Время прослушивания (с)"; duck="Приглушение игры (%)"; confidence="Минимальная уверенность (%)"; hotkey="Клавиша прослушивания"; start_game="Создать ярлык запуска игры вместе с Psych0VMod"; save="Сохранить"; phrase="Голосовая команда"; action="Функция"; add="Добавить / обновить"; remove="Удалить"; listen="Слушать и проверить"; run="Запустить выбранную функцию"; heard="Распознано"; ready="Готово"; record="Записать образец"; play="Воспроизвести"; sample_help="Выберите макрос и запишите его 3 раза. Говорите естественно после сигнала. Смена микрофона, сильный шум или другая манера речи могут потребовать новых образцов."; check="Проверить обновления"; install="Установить Psych0Mod"; install_app="Обновить Psych0VMod"; make_backup="Создать копию"; restore="Восстановить выбранную"; refresh="Обновить список"}
}
$ui.pl.report="Utwórz raport diagnostyczny";$ui.pl.open_data="Otwórz folder danych"
$ui.en.report="Create diagnostic report";$ui.en.open_data="Open data folder"
$ui.de.report="Diagnosebericht erstellen";$ui.de.open_data="Datenordner öffnen"
$ui.ru.report="Создать отчёт диагностики";$ui.ru.open_data="Открыть папку данных"
$ui.pl.google_key="Klucz Google Speech API (opcjonalny)";$ui.en.google_key="Google Speech API key (optional)";$ui.de.google_key="Google Speech API-Schlüssel (optional)";$ui.ru.google_key="Ключ Google Speech API (необязательно)"
$ui.pl.clear_key="Usuń klucz";$ui.en.clear_key="Remove key";$ui.de.clear_key="Schlüssel löschen";$ui.ru.clear_key="Удалить ключ"
$ui.pl.component_check="Sprawdź składniki";$ui.en.component_check="Check components";$ui.de.component_check="Komponenten prüfen";$ui.ru.component_check="Проверить компоненты"
$ui.pl.welcome="Witaj w Psych0VMod. Sprawdź wykryty folder PAYDAY 2, wybierz język i klawisz nasłuchu, a następnie kliknij Zapisz. Potem utwórz własne makra i opcjonalnie nagraj po 3 próbki.";$ui.en.welcome="Welcome to Psych0VMod. Check the detected PAYDAY 2 folder, choose the language and listening hotkey, then click Save. Next, create your macros and optionally record 3 samples each.";$ui.de.welcome="Willkommen bei Psych0VMod. Prüfen Sie den erkannten PAYDAY-2-Ordner, wählen Sie Sprache und Hörtaste und klicken Sie auf Speichern. Erstellen Sie danach Makros und optional je 3 Sprachproben.";$ui.ru.welcome="Добро пожаловать в Psych0VMod. Проверьте папку PAYDAY 2, выберите язык и клавишу прослушивания, затем нажмите «Сохранить». После этого создайте макросы и при желании запишите по 3 образца."
$ui.pl.speech_settings="Pakiety mowy";$ui.en.speech_settings="Speech packs";$ui.de.speech_settings="Sprachpakete";$ui.ru.speech_settings="Речевые пакеты"
$ui.pl.sample_help="Wybierz makro. Próbki są opcjonalne. Kreator prowadzi przez 3 nagrania i buduje jeden profil. Mów po krótkim przygotowaniu trwającym pół sekundy."
$ui.en.sample_help="Select a macro. Samples are optional. The wizard guides 3 recordings and builds one acoustic profile. Speak after the short half-second preparation."
$ui.de.sample_help="Wählen Sie ein Makro. Proben sind optional. Der Assistent führt durch 3 Aufnahmen und erstellt ein akustisches Profil. Nach der kurzen Vorbereitung von einer halben Sekunde sprechen."
$ui.ru.sample_help="Выберите макрос. Образцы необязательны. Мастер проводит через 3 записи и создаёт акустический профиль. Говорите после короткой подготовки длительностью полсекунды."
$ui.pl.speech_language="Język komend (PL/EN w paczce)";$ui.en.speech_language="Command language (PL/EN bundled)";$ui.de.speech_language="Befehlssprache (PL/EN enthalten)";$ui.ru.speech_language="Язык команд (PL/EN в комплекте)"

function Set-Psych0ModLanguage([string]$Language){
 if($Language -notin @('pl','en','de','ru')){throw (PText 'Invalid interface language')}
 if(!$config.payday2_path){return}
 $root=Join-Path ([string]$config.payday2_path) 'mods/Psych0Mod'
 if(!(Test-Path -LiteralPath (Join-Path $root 'mod.txt'))){throw (PText 'Nie znaleziono mods\Psych0Mod')}
 $path=Join-Path $root 'psych0_config.txt'
 $raw=if(Test-Path -LiteralPath $path){[IO.File]::ReadAllText($path)}else{''}
 if($raw -match '(?m)^\s*language\s*='){$raw=[regex]::Replace($raw,'(?m)^\s*language\s*=.*$','language='+$Language)}else{$raw+="`r`nlanguage=$Language`r`n"}
 $tmp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($tmp,$raw,(New-Object Text.UTF8Encoding($false)));if(Test-Path -LiteralPath $path){[IO.File]::Replace($tmp,$path,$path+'.bak')}else{[IO.File]::Move($tmp,$path)}}finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
 # Game-side request is consumed once; there is no persistent override of F1 choices.
 $request=Join-Path $root 'psych0vmod_language_request.json';$temp=$request+'.tmp'
 try{[IO.File]::WriteAllText($temp,(@{version=1;language=$Language;expires=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()+60}|ConvertTo-Json),(New-Object Text.UTF8Encoding($false)));Move-Item -LiteralPath $temp -Destination $request -Force}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Restore-Psych0LanguageDraft {
 $path=Join-Path $DataDir 'language-ui-state.json'
 if(!(Test-Path -LiteralPath $path)){return}
 try{
  $state=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
  if($state.language -cne [string]$config.language){return}
  $clean=Assert-FeatureSet $state
  if($state.selected_preset){foreach($p in $script:featurePresetBox.Items){if($p.id -ceq $state.selected_preset){$script:featurePresetBox.SelectedItem=$p;break}}}
  $script:featureDraft=$clean.features;$script:featureParameters=$clean.parameters;$script:featureName.Text=[string]$state.name
  Update-FeatureChecks;Update-FeatureParameter
 }catch{Write-AppLog 'WARN' 'LANGUAGE_DRAFT_RESTORE_FAILED'}finally{Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue}
}
function Restart-Psych0Interface {
 $source=Join-Path $AppDir 'Psych0VMod-Restart.ps1'
 $helper=Join-Path ([IO.Path]::GetTempPath()) ('Psych0VMod-language-'+[guid]::NewGuid().ToString('N')+'.ps1')
 Copy-Item -LiteralPath $source -Destination $helper
 $draftPath=Join-Path $DataDir 'language-ui-state.json'
 if($script:featureName){Save-JsonFile $draftPath @{language=[string]$config.language;features=$script:featureDraft;parameters=$script:featureParameters;name=[string]$script:featureName.Text;selected_preset=$(if($script:featurePresetBox.SelectedItem){[string]$script:featurePresetBox.SelectedItem.id}else{''})}}
 try{Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$helper+'"'),'-ParentPid',$PID,'-AppPath',('"'+(Join-Path $AppDir 'Psych0VMod.ps1')+'"'));$form.Close()}catch{Remove-Item -LiteralPath $helper -Force -ErrorAction SilentlyContinue;throw}
}

function T($Key) { $lang=[string]$config.language; if(!$ui.ContainsKey($lang)){$lang="pl"}; return $ui[$lang][$Key] }
function Action-Name($Action) {
    if(!$Action){return ""}
    $lang=([string]$config.language).ToLowerInvariant()
    $property=$Action.PSObject.Properties[$lang]
    $v=if($property){[string]$property.Value}else{""}
    if(!$v){$v=[string]$Action.en};if(!$v){$v=[string]$Action.pl};if(!$v){$v=[string]$Action.id}
    return $v
}
function Mod-Path { if(!$config.payday2_path){return $null}; return Join-Path ([string]$config.payday2_path) "mods\Psych0Mod" }
$script:helpCache=@{}
function ConvertFrom-LuaString([string]$Value) {
    if($null -eq $Value){return ""}
    # Retain support for double-escaped exports and ordinary Lua escape sequences.
    $decoded=$Value.Replace('\\n',"`n").Replace('\\r',"`r").Replace('\n',"`n").Replace('\r',"`r").Replace('\\"','"').Replace('\"','"').Replace('\\','\')
    return [regex]::Replace($decoded,"`r`n|`r|`n","`r`n")
}
function Format-ActionDescription([string]$Value){
    if(!$Value){return ""}
    $text=[regex]::Replace($Value,"`r`n|`r|`n","`n")
    # Sections may be on separate lines or joined in a legacy help entry.
    $labels='Typ|Type|Co robi|What it does|Jak używać|How to use|Ograniczenia|Limitations|TASTE|Was macht es|Verwendung|Einschränkungen|Тип|Что делает|Как использовать|Ограничения'
    $text=[regex]::Replace($text,'[ \t\n]*(?=(?:'+$labels+')\s*:)',"`n`n",[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $bodyLabels='Co robi|What it does|Jak używać|How to use|Ograniczenia|Limitations|Was macht es|Verwendung|Einschränkungen|Что делает|Как использовать|Ограничения'
    $text=[regex]::Replace($text,'((?:'+$bodyLabels+')\s*:)[ \t\n]*',('$1'+"`n`n"),[Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $text=[regex]::Replace($text,"`n{3,}","`n`n")
    return $text.Trim().Replace("`n","`r`n")
}
function Get-ActionHelpKey([string]$Id) {
    $map=@{
        scanner="F2";refill_ammo="F3";ammo_collector="F4";fast_interactions="F5";movement="F6";anti_flash="F7";vacuum="F8";mechanic="F9";starter_pack="F10";item_scanner="F11"
        stealth="NUM1";laser="NUM2";intimidate="NUM3";cable_ties="NUM4";pagers="NUM5";quartermaster="NUM6";protection="NUM7";mission_items="NUM8";carry_stack="NUM9";soft_aim="NUM0"
        infinite_health="NUMPLUS";infinite_ammo="NUMMINUS";auto_magazine="NUMMULTIPLY";combat_mode="DELETE";burglar="INSERT";no_pagers="BEZPAGEROW";infinite_body_bags="WORKI";hostages="ZAKLADNICY"
        undetectable="NIEWYKRYWALNOSC";pack_bodies="CIALA";remove_npcs="USUNNPC";collect_loot="DUZYLUP";rescue_team="RATUNEK";disable_security="OCHRONA";secure_bags="TORBY";fill_team="DRUZYNA";clear_map="CZYSZCZENIE"
    }
    return [string]$map[$Id]
}
function Get-ActionDescription($Action) {
    if(!$Action){return ""}
    $cacheKey="$($config.language):$($Action.id)"
    if($script:helpCache.ContainsKey($cacheKey)){return [string]$script:helpCache[$cacheKey]}
    $fallback=Action-Name $Action
    $key=Get-ActionHelpKey ([string]$Action.id)
    $mod=Mod-Path;$helpFile=if($mod){Join-Path $mod "pomoc.lua"}else{$null}
    if(!$key -or !$helpFile -or !(Test-Path $helpFile)){$script:helpCache[$cacheKey]=$fallback;return $fallback}
    try {
        $raw=Get-Content -Raw -Encoding UTF8 $helpFile
        $pattern='(?ms)^\s*'+[regex]::Escape($key)+'\s*=\s*\{\s*title\s*=\s*"(?<title>(?:\\.|[^"])*)"\s*,\s*pages\s*=\s*\{\s*"(?<page>(?:\\.|[^"])*)"'
        $match=[regex]::Match($raw,$pattern)
        if(!$match.Success){throw (PText 'text_338' @($key))}
        $title=ConvertFrom-LuaString $match.Groups['title'].Value
        $page=ConvertFrom-LuaString $match.Groups['page'].Value
        if([string]$config.language -ne "pl"){
            $locFile=Join-Path $mod ("localization\auto_{0}.lua" -f [string]$config.language)
            if(Test-Path $locFile){
                $locRaw=Get-Content -Raw -Encoding UTF8 $locFile
                $locMatches=[regex]::Matches($locRaw,'\["(?<key>(?:\\.|[^"])*)"\]\s*=\s*"(?<value>(?:\\.|[^"])*)"')
                foreach($entry in $locMatches){
                    $source=ConvertFrom-LuaString $entry.Groups['key'].Value
                    if($source -eq $title){$title=ConvertFrom-LuaString $entry.Groups['value'].Value}
                    if($source -eq $page){$page=ConvertFrom-LuaString $entry.Groups['value'].Value}
                }
            }
        }
        $result=Format-ActionDescription "$title`r`n`r`n$page"
    } catch {$result=$fallback;Write-AppLog "WARN" "Help description fallback for $($Action.id): $($_.Exception.Message)"}
    $script:helpCache[$cacheKey]=$result
    return $result
}
function New-Psych0Backup {
    $mod=Mod-Path
    if(!$mod -or !(Test-Path $mod)){throw (PText 'text_442')}
    $stamp=(Get-Date -Format "yyyyMMdd-HHmmss")+"-"+[guid]::NewGuid().ToString("N").Substring(0,8)
    $target=Join-Path $BackupDir "Psych0Mod-$stamp.zip"
    Compress-Archive -Path (Join-Path $mod "*") -DestinationPath $target -CompressionLevel Optimal
    $all=@(Get-ChildItem $BackupDir -Filter "Psych0Mod-*.zip" | Sort-Object LastWriteTime -Descending)
    if($all.Count -gt 5){$all | Select-Object -Skip 5 | Remove-Item -Force}
    return $target
}
function New-Psych0VModBackup {
    if(!(Test-Path $AppDir)){throw (PText 'text_443')}
    $stamp=(Get-Date -Format "yyyyMMdd-HHmmss")+"-"+[guid]::NewGuid().ToString("N").Substring(0,8)
    $target=Join-Path $BackupDir "Psych0VMod-App-$stamp.zip"
    Compress-Archive -Path (Join-Path $AppDir "*") -DestinationPath $target -CompressionLevel Optimal
    $all=@(Get-ChildItem $BackupDir -Filter "Psych0VMod-App-*.zip" | Sort-Object LastWriteTime -Descending)
    if($all.Count -gt 5){$all | Select-Object -Skip 5 | Remove-Item -Force}
    return $target
}
function Restore-Psych0Backup([string]$Archive) {
    $mod=Mod-Path
    if(!$mod){throw (PText 'text_444')}
    [void](New-Psych0Backup)
    $temp=Join-Path $env:TEMP ("Psych0VMod-restore-"+[guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force $temp | Out-Null
    try {
        Expand-Archive -Force $Archive $temp
        if(!(Test-Path (Join-Path $temp "mod.txt")) -or !(Test-Path (Join-Path $temp "psych0vmod_bridge.lua"))){throw (PText 'text_445')}
        Assert-Psych0GameClosed
        Set-TransactionalDirectory $temp $mod $false $true
        $script:ModVersion=Get-InstalledPsych0ModVersion
    } finally { if(Test-Path $temp){Remove-Item -Recurse -Force $temp} }
}
function Restore-Psych0VModBackup([string]$Archive) {
    if(!(Test-Path $Archive)){throw (PText 'text_446')}
    $work=Join-Path $env:TEMP ("Psych0VMod-app-restore-"+[guid]::NewGuid().ToString("N"))
    $source=Join-Path $work 'Psych0VMod'
    New-Item -ItemType Directory -Force $source | Out-Null
    try {
        Expand-Archive -Force $Archive $source
        if(!(Test-Path (Join-Path $source "Psych0VMod.ps1"))){throw (PText 'text_447')}
        $helperSource=Join-Path $AppDir "Psych0VMod-SelfUpdate.ps1"
        if(!(Test-Path $helperSource)){throw (PText 'text_448')}
        [void](New-Psych0VModBackup)
        $helper=Join-Path $env:TEMP ("Psych0VMod-SelfUpdate-"+[guid]::NewGuid().ToString("N")+".ps1")
        Copy-Item -Force $helperSource $helper
        $arguments=@("-NoProfile","-ExecutionPolicy","Bypass","-File",("`""+$helper+"`""),"-ParentPid",$PID,"-Source",("`""+$source+"`""),"-Target",("`""+$AppDir+"`""),"-CleanupRoot",("`""+$work+"`""))
        if($config.payday2_path){$arguments+=@("-Payday2Path",("`""+[string]$config.payday2_path+"`""))}
        $arguments+=@("-RestoreBackup")
        Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -ArgumentList $arguments
        $form.Close()
    } catch {
        if(Test-Path $work){Remove-Item -Recurse -Force $work}
        throw
    }
}
function Assert-UpdateArchive([string]$Path,[string]$ExpectedHash) {
    if($ExpectedHash -notmatch '^[a-fA-F0-9]{64}$'){throw (PText 'text_437')}
    if((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $ExpectedHash){throw (PText 'text_268')}
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip=[IO.Compression.ZipFile]::OpenRead($Path)
    try{
        if(!$zip.Entries.Count){throw (PText 'text_382')}
        $seen=@{};$total=[long]0
        foreach($entry in $zip.Entries){
            $name=$entry.FullName.Replace('\','/')
            if($name.StartsWith('/') -or $name.Contains(':') -or @($name.Split('/')|Where-Object {$_ -eq '..'}).Count){throw (PText 'text_383')}
            if($seen.ContainsKey($name)){throw (PText 'text_384')};$seen[$name]=$true
            $total+=$entry.Length;if($total -gt 2147483648){throw (PText 'text_385')}
        }
    }finally{$zip.Dispose()}
}
function Assert-Psych0RelativePath([string]$Name) {
    if(!$Name -or $Name -match '[\\:]' -or $Name.StartsWith('/') -or $Name -match '(^|/)\.{1,2}(/|$)' -or $Name -match '[<>"|?*]' -or $Name -match '[. ]($|/)'){throw (PText 'text_335' @($Name))}
}
function Assert-Psych0Release([string]$Source) {
    $path=Join-Path $Source '.psych0-release.json'
    $release=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    Assert-Psych0ReleaseChannel $release
    if($release.schema -ne 1 -or $release.component -notin @('psych0mod','psych0vmod') -or !$release.version -or !@($release.files).Count){throw (PText 'text_386')}
    $seen=@{}
    foreach($file in $release.files){
        $name=[string]$file.path;Assert-Psych0RelativePath $name
        if($name -eq '.psych0-release.json' -or $seen.ContainsKey($name)){throw (PText 'text_387')};$seen[$name]=$true
        if($file.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw (PText 'text_388')}
        $p=Join-Path $Source $name
        if(!(Test-Path -LiteralPath $p -PathType Leaf) -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne $file.sha256){throw (PText 'text_336' @($name))}
    }
    foreach($file in Get-ChildItem -LiteralPath $Source -Recurse -File -Force){
        $name=$file.FullName.Substring([IO.Path]::GetFullPath($Source).TrimEnd([IO.Path]::DirectorySeparatorChar).Length+1).Replace('\','/')
        if($name -ne '.psych0-release.json' -and !$seen.ContainsKey($name)){throw (PText 'text_337' @($name))}
    }
    return $release
}
function Assert-Psych0GameClosed {
    if(Get-Process -Name 'payday2_win32_release','payday2_win64_release','payday2_win32_release_vr','PAYDAY2' -ErrorAction SilentlyContinue){throw (PText 'text_269')}
}
function Set-TransactionalDirectory([string]$Source,[string]$Target,[bool]$PreserveExisting=$true,[bool]$IsBackup=$false) {
    if(!(Test-Path -LiteralPath $Source -PathType Container)){throw (PText 'text_389')}
    $release=$null
    if(!$IsBackup -and (Test-Path -LiteralPath (Join-Path $Source '.psych0-release.json'))){$release=Assert-Psych0Release $Source}
    $targetFull=[IO.Path]::GetFullPath($Target).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $parent=Split-Path -Parent $targetFull
    $stage=Join-Path $parent ('.Psych0VMod-stage-'+[guid]::NewGuid().ToString('N'))
    $old=Join-Path $parent ('.Psych0VMod-rollback-'+[guid]::NewGuid().ToString('N'))
    $moved=$false;$committed=$false
    New-Item -ItemType Directory -Force $parent|Out-Null
    try{
        foreach($folder in @($Source,$targetFull)){
            if(Test-Path -LiteralPath $folder){
                if((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw (PText 'text_390')}
                if(@(Get-ChildItem -LiteralPath $folder -Recurse -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw (PText 'text_391')}
            }
        }
        New-Item -ItemType Directory $stage|Out-Null
        if($PreserveExisting -and (Test-Path -LiteralPath $targetFull)){Get-ChildItem -LiteralPath $targetFull -Force|Copy-Item -Destination $stage -Recurse -Force}
        if($release -and $PreserveExisting){
            $previousPath=Join-Path $targetFull '.psych0-release.json'
            $previous=@()
            if(Test-Path -LiteralPath $previousPath){
                try{$previousRelease=Get-Content -LiteralPath $previousPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{$previousRelease=$null}
                if(!$previousRelease -or $previousRelease.component -ne $release.component){$previousRelease=[pscustomobject]@{files=@($release.legacy_managed_files|Where-Object {$_}|ForEach-Object {[pscustomobject]@{path=$_}})}}
                $previous=@($previousRelease.files|ForEach-Object {[string]$_.path})
            }else{$previous=@($release.legacy_managed_files|Where-Object {$_})}
            $new=@{};foreach($file in $release.files){$new[[string]$file.path]=$true}
            foreach($name in $previous){
                Assert-Psych0RelativePath $name
                if($name -match '^(models|engines|native|grafiks|graphics|samples|backups|logs)(/|$)' -or $name -in @('config.json','macros.json','presets.json','psych0_config.txt','psych0_presets.json','psych0_autostart_state.json')){continue}
                if(!$new.ContainsKey($name)){
                    $obsolete=Join-Path $stage $name
                    if(Test-Path -LiteralPath $obsolete -PathType Container){throw (PText 'text_392')}
                    if(Test-Path -LiteralPath $obsolete){Remove-Item -LiteralPath $obsolete -Force}
                }
            }
        }
        Get-ChildItem -LiteralPath $Source -Force|Copy-Item -Destination $stage -Recurse -Force
        if(!$IsBackup -and !$PreserveExisting){
            foreach($userFile in @('psych0_config.txt','psych0_presets.json','psych0_presets.json.bak','psych0_autostart_state.json','psych0_autostart_state.json.bak','.psych0-install.json')){
                if(Test-Path -LiteralPath (Join-Path $targetFull $userFile)){Copy-Item -LiteralPath (Join-Path $targetFull $userFile) -Destination (Join-Path $stage $userFile) -Force}
            }
        }
        if($release){
            foreach($file in $release.files){
                if(!$PreserveExisting -and $file.path -eq 'psych0_config.txt'){continue}
                if((Get-FileHash -LiteralPath (Join-Path $stage $file.path) -Algorithm SHA256).Hash -ne $file.sha256){throw (PText 'text_393')}
            }
        }
        if(Test-Path -LiteralPath $targetFull){Move-Item -LiteralPath $targetFull -Destination $old;$moved=$true}
        try{Move-Item -LiteralPath $stage -Destination $targetFull;$committed=$true}
        catch{if($moved){Move-Item -LiteralPath $old -Destination $targetFull};throw}
    }finally{
        if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force}
        if($committed -and (Test-Path -LiteralPath $old)){Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue}
    }
}
function Get-InstalledPsych0ModVersion {
    $mod=Mod-Path
    if(!$mod -or !(Test-Path -LiteralPath (Join-Path $mod 'mod.txt'))){return '0.0.0'}
    return [string](Get-Content -LiteralPath (Join-Path $mod 'mod.txt') -Raw -Encoding UTF8|ConvertFrom-Json).version
}

function Get-UpdateManifest {
    $url=Get-Psych0ManifestUrl
    $manifest=Get-Psych0CloudManifest
    Assert-Psych0ManifestChannel $manifest
    return $manifest
}
function Convert-Version([string]$Value) {
    if($Value -notmatch '^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$'){return $null}
    $major=[int]$Matches[1];$minor=[int]$Matches[2];$patch=[int]$Matches[3]
    $tag=[string]$Matches[4]
    $rank=if(!$tag){4}elseif($tag -match '^rc'){3}elseif($tag -match '^beta'){2}elseif($tag -match '^alpha'){1}else{0}
    $tagNumbers=@();if($tag -match '^(?:rc|beta|alpha)(\d+(?:\.\d+)*)$'){$tagNumbers=@($Matches[1].Split('.')|ForEach-Object {[int]$_})}
    return [pscustomobject]@{major=$major;minor=$minor;patch=$patch;rank=$rank;tagNumbers=$tagNumbers}
}
function Test-NewerVersion([string]$Remote,[string]$Local) {
    $r=Convert-Version $Remote;$l=Convert-Version $Local
    if(!$r -or !$l){return $false}
    foreach($part in @('major','minor','patch','rank')){
        if($r.$part -gt $l.$part){return $true}
        if($r.$part -lt $l.$part){return $false}
    }
    $count=[Math]::Max($r.tagNumbers.Count,$l.tagNumbers.Count)
    for($i=0;$i -lt $count;$i++){
        $rv=if($i -lt $r.tagNumbers.Count){$r.tagNumbers[$i]}else{0}
        $lv=if($i -lt $l.tagNumbers.Count){$l.tagNumbers[$i]}else{0}
        if($rv -gt $lv){return $true};if($rv -lt $lv){return $false}
    }
    return $false
}
function Install-Psych0ModUpdate($Manifest) {
    Assert-Psych0GameClosed
    $component=$Manifest.components.psych0mod
    [void]@(Get-Psych0ComponentUrls $component)
    $zip=Join-Path $env:TEMP ("Psych0Mod-update-"+[guid]::NewGuid().ToString("N")+".zip")
    $temp=Join-Path $env:TEMP ("Psych0Mod-update-"+[guid]::NewGuid().ToString("N"))
    try {
        $status.Text=(PText 'text_450'); [Windows.Forms.Application]::DoEvents()
        Save-Psych0ComponentArchive $component $zip
        Assert-UpdateArchive $zip ([string]$component.sha256)
        [void](New-Psych0Backup)
        New-Item -ItemType Directory -Force $temp | Out-Null
        Expand-Archive -Force $zip $temp
        $source=Join-Path $temp "Psych0Mod"
        $target=Mod-Path
        if(!(Test-Path (Join-Path $source "mod.txt")) -or !(Test-Path (Join-Path $source "psych0vmod_bridge.lua"))){throw (PText 'text_451')}
        $release=Assert-Psych0Release $source
        if($release.component -ne "psych0mod" -or $release.version -ne $component.version){throw (PText 'text_452')}
        Assert-Psych0GameClosed
        Set-TransactionalDirectory $source $target $false
        $script:ModVersion=Get-InstalledPsych0ModVersion
        $status.Text=(PText 'text_297')
    } finally {
        if(Test-Path $zip){Remove-Item -Force $zip}
        if(Test-Path $temp){Remove-Item -Recurse -Force $temp}
    }
}
function Install-Psych0VModUpdate($Manifest) {
    Assert-Psych0GameClosed
    $component=$Manifest.components.psych0vmod
    [void]@(Get-Psych0ComponentUrls $component)
    $work=Join-Path $env:TEMP ("Psych0VMod-app-update-"+[guid]::NewGuid().ToString("N"))
    $zip=Join-Path $work "update.zip"
    $unpack=Join-Path $work "unpacked"
    New-Item -ItemType Directory -Force $unpack | Out-Null
    try {
        $status.Text=(PText 'text_454'); [Windows.Forms.Application]::DoEvents()
        Save-Psych0ComponentArchive $component $zip
        Assert-UpdateArchive $zip ([string]$component.sha256)
        Expand-Archive -Force $zip $unpack
        $source=Join-Path $unpack 'Psych0VMod'
        if(!(Test-Path (Join-Path $source "Psych0VMod.ps1"))){throw (PText 'text_455')}
        $release=Assert-Psych0Release $source
        if($release.component -ne "psych0vmod" -or $release.version -ne $component.version){throw (PText 'text_456')}
        $helperSource=Join-Path $source "Psych0VMod-SelfUpdate.ps1"
        if(!(Test-Path $helperSource)){throw (PText 'text_448')}
        [void](New-Psych0VModBackup)
        $helper=Join-Path $env:TEMP ("Psych0VMod-SelfUpdate-"+[guid]::NewGuid().ToString("N")+".ps1")
        Copy-Item -Force $helperSource $helper
        $arguments=@("-NoProfile","-ExecutionPolicy","Bypass","-File",("`""+$helper+"`""),"-ParentPid",$PID,"-Source",("`""+$source+"`""),"-Target",("`""+$AppDir+"`""),"-CleanupRoot",("`""+$work+"`""))
        if($config.payday2_path){$arguments+=@("-Payday2Path",("`""+[string]$config.payday2_path+"`""))}
        Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -ArgumentList $arguments
        $status.Text=(PText 'text_457')
        $form.Close()
    } catch {
        if(Test-Path $work){Remove-Item -Recurse -Force $work}
        throw
    }
}
function Invoke-Psych0Action([string]$ActionId) {
    if(!@($catalog|Where-Object {$_.id -eq $ActionId}).Count){$status.Text=(PText 'text_458');return}
    $mod = Mod-Path
    if(!$mod -or !(Test-Path $mod)){ (Show-Psych0Message -Text ("Nie znaleziono / Cannot find: mods\Psych0Mod") -Caption ('Psych0VMod')) | Out-Null; return }
    $nonce=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()
    $tmp=Join-Path $mod "psych0vmod_command.tmp"
    $dst=Join-Path $mod "psych0vmod_command.txt"
    "$nonce`t$ActionId" | Set-Content -Encoding ASCII $tmp
    Move-Item -Force $tmp $dst
    $status.Text=(PText 'text_339' @($ActionId))
}

function Get-SpeechCulture {
    $map=@{pl="pl-PL";en="en-US";de="de-DE";ru="ru-RU"}
    $name=$map[[string]$config.speech_language]
    if(!$name){$name="en-US"}
    return [Globalization.CultureInfo]::GetCultureInfo($name)
}

function Get-InstalledSpeechEngines {
    try {
        Add-Type -AssemblyName System.Speech
        return @([System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers())
    } catch { return @() }
}
function Get-VoskModelPath([string]$Language=[string]$config.speech_language) {
    $local=Join-Path $DataDir ("models\"+$Language)
    if(Test-Path (Join-Path $local "am\final.mdl")){return $local}
    return (Join-Path $AppDir ("models\"+$Language))
}
function Test-VoskReady([string]$Language=[string]$config.speech_language) {
    return ((Test-Path (Join-Path (Get-VoskModelPath $Language) "am\final.mdl")) -and (Test-Path (Join-Path $AppDir "engines\vosk\libvosk.dll")) -and (Test-Path (Join-Path $AppDir "Psych0VMod-Vosk.cs")))
}
function Get-SpeechHelp {
    return (PText 'text_577' @($($config.speech_language)))
}
function Initialize-Vosk {
    if("Psych0VModVosk" -as [type]){return}
    Add-Type -Path (Join-Path $AppDir "Psych0VMod-Vosk.cs")
}
function Initialize-MicrophoneRecorder {
    if("Psych0VModMicrophone" -as [type]){return}
    $source=Join-Path $AppDir "Psych0VMod-Microphone.cs"
    if(!(Test-Path $source)){throw (PText 'text_298')}
    Add-Type -Path $source
}
function Record-MicrophoneWav([string]$Path,[int]$Seconds) {
    Initialize-MicrophoneRecorder
    if([Psych0VModMicrophone]::waveInGetNumDevs() -eq 0){throw (PText 'text_299')}
    # Half-second microphone warmup; preparation is discarded, not part of speech capture.
    # Do not pump UI events during capture (prevents nested hotkeys/settings changes).
    $labels=@{
        pl=@{prepare="Przygotuj się";record="NAGRYWANIE — mów teraz"}
        en=@{prepare="Get ready";record="RECORDING — speak now"}
        de=@{prepare="Bereit machen";record="AUFNAHME — jetzt sprechen"}
        ru=@{prepare="Приготовьтесь";record="ЗАПИСЬ — говорите сейчас"}
    }
    $lang=[string]$config.language;if(!$labels.ContainsKey($lang)){$lang="pl"}
    $text=$labels[$lang]
    $countdown=[Action]{
        $status.Text=$text.prepare;$status.Refresh();[Threading.Thread]::Sleep(500)
        $status.Text="$($text.record) (${Seconds}s)";$status.Refresh()
    }
    # Recorder starts the full configured speech interval AFTER this warmup callback.
    [Psych0VModMicrophone]::RecordWithCountdown($Path,$Seconds,$countdown)

}
function Invoke-LocalSpeech([string]$Path,[string]$Language=[string]$config.speech_language) {
    if(!(Test-VoskReady $Language)){throw (PText 'text_464' @($Language))}
    Initialize-Vosk
    $segments=@([Psych0VModVosk]::Recognize((Join-Path $AppDir "engines\vosk"),(Get-VoskModelPath $Language),$Path)|ConvertFrom-Json)
    $texts=@();$scores=@()
    foreach($segment in $segments){
        if($segment.text){$texts+=[string]$segment.text}
        foreach($word in @($segment.result)){if($word){$scores+=if($word.PSObject.Properties["conf"]){[double]$word.conf}else{0.0}}}
    }
    $text=Normalize-Phrase ($texts -join " ")
    if(!$text){return $null}
    # Minimum word confidence: a strong word cannot mask a doubtful word.
    $score=if($scores.Count){[double](($scores|Measure-Object -Minimum).Minimum)}else{0.0}
    return [pscustomobject]@{text=$text;confidence=$score;engine="Vosk";language=$Language}
}

function Get-WavFingerprint([string]$Path) {
    $stream=[IO.File]::OpenRead($Path);$reader=[IO.BinaryReader]::new($stream)
    try {
        if((-join $reader.ReadChars(4)) -ne "RIFF"){return $null}
        [void]$reader.ReadUInt32();if((-join $reader.ReadChars(4)) -ne "WAVE"){return $null}
        $format=0;$channels=0;$bits=0;$data=$null
        while($stream.Position+8 -le $stream.Length){
            $chunk=-join $reader.ReadChars(4);$size=$reader.ReadUInt32();$start=$stream.Position
            if($chunk -eq "fmt "){$format=$reader.ReadUInt16();$channels=$reader.ReadUInt16();[void]$reader.ReadUInt32();[void]$reader.ReadUInt32();[void]$reader.ReadUInt16();$bits=$reader.ReadUInt16()}
            elseif($chunk -eq "data"){$data=$reader.ReadBytes([int]$size);break}
            $stream.Position=[Math]::Min($stream.Length,$start+$size+($size%2))
        }
        if($format -ne 1 -or $bits -ne 16 -or $channels -lt 1 -or !$data){return $null}
        $frameBytes=2*$channels;$frames=[Math]::Floor($data.Length/$frameBytes);if($frames -lt 32){return $null}
        $bins=New-Object double[] 32;$counts=New-Object int[] 32
        for($frame=0;$frame -lt $frames;$frame++){
            $energy=0.0
            for($ch=0;$ch -lt $channels;$ch++){$offset=$frame*$frameBytes+$ch*2;$sample=[BitConverter]::ToInt16($data,$offset);$energy+=[Math]::Abs([double]$sample)/32768.0}
            $bin=[Math]::Min(31,[Math]::Floor($frame*32.0/$frames));$bins[$bin]+=$energy/$channels;$counts[$bin]++
        }
        $norm=0.0
        for($i=0;$i -lt 32;$i++){if($counts[$i]){$bins[$i]/=$counts[$i]};$norm+=$bins[$i]*$bins[$i]}
        $norm=[Math]::Sqrt($norm);if($norm -le 0){return $null}
        for($i=0;$i -lt 32;$i++){$bins[$i]=[Math]::Round($bins[$i]/$norm,6)}
        return ,$bins
    } finally {$reader.Dispose();$stream.Dispose()}
}

function Get-ResultFingerprint($Result) {
    if(!$Result -or !$Result.Audio){return $null}
    $temp=Join-Path $env:TEMP ("Psych0VMod-voice-"+[guid]::NewGuid().ToString("N")+".wav")
    $stream=$null
    try {$stream=[IO.File]::Open($temp,[IO.FileMode]::Create,[IO.FileAccess]::Write);$Result.Audio.WriteToWaveStream($stream);$stream.Close();$stream=$null;return (Get-WavFingerprint $temp)}
    finally {if($stream){$stream.Dispose()};if(Test-Path $temp){Remove-Item -Force $temp}}
}

function Initialize-VoiceProfiles {
    if("Psych0VoiceProfile" -as [type]){return}
    Add-Type -Path (Join-Path $AppDir "Psych0VMod-VoiceProfile.cs")
}
function Get-MacroSamples($Macro){
    return @($script:samples|Where-Object {$_.macro_id -eq $Macro.id -and $_.phrase -eq $Macro.phrase -and $_.action -eq $Macro.action -and (!$_.PSObject.Properties['language'] -or $_.language -eq $Macro.language)})
}
function Get-ProfilePath($Macro){return (Join-Path $ProfilesDir ($Macro.id+".json"))}
function Build-MacroProfile($Macro){
    Initialize-VoiceProfiles
    $items=@(Get-MacroSamples $Macro)
    if($items.Count -ne 3 -or @($items|Where-Object {!$_.approved}).Count){throw (PText 'text_300')}
    $files=[string[]]@($items|ForEach-Object {Join-Path $SamplesDir ([string]$_.file)})
    $skips=[int[]]@($items|ForEach-Object {if($_.PSObject.Properties["capture_version"] -and $_.capture_version -ge 2){0}else{350}})
    $profile=[Psych0VoiceProfile]::Build($files,$skips)
    $entry=[pscustomobject]@{macro_id=$Macro.id;phrase=$Macro.phrase;action=$Macro.action;language=$Macro.language;sample_ids=@($items|ForEach-Object {$_.id});profile=$profile;created_utc=[DateTime]::UtcNow.ToString("o")}
    Save-JsonFile (Get-ProfilePath $Macro) $entry
}
function Get-ValidProfileEntry($Macro){
    $entry=Read-JsonFile (Get-ProfilePath $Macro) $null
    if(!$entry -or $entry.phrase -ne $Macro.phrase -or $entry.action -ne $Macro.action -or $entry.language -ne $Macro.language){return $null}
    $items=@(Get-MacroSamples $Macro)
    if(@($items|Where-Object {!$_.approved}).Count){return $null}
    $ids=@($items|ForEach-Object {$_.id})
    if($ids.Count -ne 3 -or @($entry.sample_ids).Count -ne 3 -or @($entry.sample_ids|Where-Object {$_ -notin $ids}).Count){return $null}
    if(!$entry.profile -or $entry.profile.Version -notin @(1,2) -or !$entry.profile.Frames){return $null}
    return $entry
}
function Get-MacroProfile($Macro){
    $entry=Get-ValidProfileEntry $Macro
    if(!$entry){return $null}
    Initialize-VoiceProfiles
    if($entry.profile.Version -eq 1){
        # Rebuild from preserved raw WAVs; do not reinterpret an old feature matrix.
        Build-MacroProfile $Macro
        $entry=Get-ValidProfileEntry $Macro
        if(!$entry -or $entry.profile.Version -ne 2){throw (PText 'text_301')}
    }
    $profile=New-Object "Psych0VoiceProfile+Profile"
    $profile.Version=[int]$entry.profile.Version
    $profile.Radius=[double]$entry.profile.Radius
    $profile.TrainingDistance=[double]$entry.profile.TrainingDistance
    $profile.Frames=@($entry.profile.Frames|ForEach-Object {,[double[]]$_})
    return $profile
}

function Find-VoiceProfile([string]$Path){
    $script:profileDiagnostic="Nie sprawdzono profili / Profiles not checked"
    $report=New-Object 'System.Collections.Generic.List[string]' 
    Initialize-VoiceProfiles
    $features=[Psych0VoiceProfile]::Extract($Path)
    $candidates=@()
    foreach($m in $script:macros){
        $profile=$null;try{$profile=Get-MacroProfile $m}catch{Write-AppLog "WARN" "Invalid stored profile";continue}
        if(!$profile){
            $count=@(Get-MacroSamples $m).Count
            $report.Add((PText 'text_340' @($($m.phrase),$count)))
            continue
        }
        $match=[Psych0VoiceProfile]::Compare($profile,$features)
        $report.Add("$($m.phrase): dystans / distance $([Math]::Round($match.Distance,4)), limit $([Math]::Round($match.Limit,4)) — $(if($match.Accepted){'w limicie / within limit'}else{'odrzucono / rejected'})")
        $candidates+=[pscustomobject]@{macro=$m;distance=$match.Distance;limit=$match.Limit;accepted=$match.Accepted}
    }
    $script:voiceReport+=$report.ToArray()
    # Different phrases for the same action are alternatives, not conflicting functions.
    $ranked=@($candidates|Group-Object -Property {[string]$_.macro.action}|ForEach-Object {$_.Group|Sort-Object distance|Select-Object -First 1}|Sort-Object distance)
    if(!$ranked.Count){$script:profileDiagnostic="brak aktualnego profilu / no current profile";return $null}
    if(!$ranked[0].accepted){$script:profileDiagnostic="'$($ranked[0].macro.phrase)': dystans $([Math]::Round($ranked[0].distance,3)) > limit $([Math]::Round($ranked[0].limit,3)) / outside limit";return $null}
    # Require a 20% relative advantage over the closest different action; no unscaled absolute margin.
    if($ranked.Count -gt 1 -and ($ranked[0].distance -gt $ranked[1].distance*.8)){$script:profileDiagnostic="konflikt / conflict: $($ranked[0].macro.phrase)→$($ranked[0].macro.action) ($([Math]::Round($ranked[0].distance,3))) i / and $($ranked[1].macro.phrase)→$($ranked[1].macro.action) ($([Math]::Round($ranked[1].distance,3)))";$script:voiceReport+=$script:profileDiagnostic;return $null}
    $script:profileDiagnostic="zaakceptowano / accepted: $($ranked[0].macro.phrase)"
    return $ranked[0]
}
. (Join-Path $AppDir "Psych0VMod-VoiceCore.ps1")

function Record-VoiceSample($Macro) {
    if(!$Macro){throw (PText 'text_459')}
    if($script:isListening){throw (PText 'text_302')}
    $script:isListening=$true
    $previousVolume=$null;$file=$null;$saved=$false
    try {
        $id=[guid]::NewGuid().ToString("N")
        $file=Join-Path $SamplesDir ($id+".wav")
        $previousVolume=Start-AudioDuck
        Record-MicrophoneWav $file ([int]$config.listen_seconds)
        Stop-AudioDuck $previousVolume;$previousVolume=$null
        Initialize-VoiceProfiles
        [void][Psych0VoiceProfile]::Extract($file)
        $player=New-Object Media.SoundPlayer($file)
        try{$player.PlaySync()}finally{$player.Dispose()}
        $approval=(Show-Psych0Message -Text ((PText 'text_303')) -Caption ((PText 'text_304')) -Buttons ([Windows.Forms.MessageBoxButtons]::YesNoCancel))
        if($approval -eq [Windows.Forms.DialogResult]::Cancel){throw [OperationCanceledException]::new("Nagrywanie anulowane / Recording cancelled")};if($approval -ne [Windows.Forms.DialogResult]::Yes){return $null}
        # User labels the recording. It is not proof that the phrase was recognized.
        $entry=[pscustomobject]@{id=$id;capture_version=2;macro_id=[string]$Macro.id;language=[string]$Macro.language;phrase=[string]$Macro.phrase;action=[string]$Macro.action;confidence=0.0;verified=$false;approved=$true;created_utc=[DateTime]::UtcNow.ToString("o");file=[IO.Path]::GetFileName($file)}
        $updated=@($script:samples)+$entry
        Save-JsonFile $SamplesFile $updated
        $script:samples=$updated;$saved=$true
        return $entry
    } finally {
        if(!$saved -and $file -and (Test-Path $file)){Remove-Item -Force $file -ErrorAction SilentlyContinue}
        try{Stop-AudioDuck $previousVolume}catch{}
        $script:isListening=$false
    }
}

function New-DiagnosticReport {
    # Explicit allowlist: no logs, phrases, audio, paths, identifiers or secrets.
    $lines=@(
        "Psych0VMod diagnostic report (allowlisted technical fields)",
        "App version: $AppVersion",
        "OS version: $([Environment]::OSVersion.Version)",
        "PowerShell: $($PSVersionTable.PSVersion)",
        "UI language: $($config.language)",
        "Voice mode: $($config.voice_mode)",
        "Command language: $($config.speech_language)",
        "Macros count: $(@($script:macros).Count)",
        "Samples count: $(@($script:samples).Count)",
        "Profile action execution enabled: $([bool]$config.profile_actions_enabled)",
        "",
        (Get-ComponentCheck -InterfaceLanguage en),
        "",
        "No audio, command phrases, API keys, user paths or raw logs included.",
        "Presence checks do not verify microphone hardware or game integration."
    )
    $target=Join-Path $DataDir ("Psych0VMod-Diagnostic-"+(Get-Date -Format "yyyyMMdd-HHmmss-fffffff")+".txt")
    $lines|Set-Content -Encoding UTF8 $target
    return $target
}

function Get-SetupChecks([string]$CommandLanguage="",[string]$VoiceMode="") {
    $selectedMode=if($VoiceMode){$VoiceMode}else{[string]$config.voice_mode}
    $game=[string]$config.payday2_path;$mod=Mod-Path
    $gameReady=$game -and ((Test-Path -LiteralPath (Join-Path $game 'PAYDAY2.exe') -PathType Leaf) -or (Test-Path -LiteralPath (Join-Path $game 'payday2_win32_release.exe') -PathType Leaf))
    [pscustomobject]@{id='game';name='PAYDAY 2';ready=[bool]$gameReady;optional=$true}
    [pscustomobject]@{id='mod';name='Psych0Mod';ready=[bool]($mod -and (Test-Path -LiteralPath (Join-Path $mod 'mod.txt') -PathType Leaf));optional=$true}
    [pscustomobject]@{id='bridge';name='Bridge';ready=[bool]($mod -and (Test-Path -LiteralPath (Join-Path $mod 'psych0vmod_bridge.lua') -PathType Leaf));optional=$true}
    $selected=if($CommandLanguage){$CommandLanguage}else{[string]$config.speech_language}
    $required=@(@($selected)+@($script:macros|ForEach-Object {[string]$_.language})|Where-Object {$_}|Sort-Object -Unique)
    foreach($language in $required){
        # Unknown languages must not become arbitrary model paths.
        $ready=$false
        if($language -in @('pl','en','de','ru')){$ready=[bool](Test-VoskReady $language)}
        $name=if($language -in @('pl','en','de','ru')){"Vosk $language"}else{'Vosk (unsupported language)'}
        [pscustomobject]@{id='model';name=$name;ready=$ready;optional=($selectedMode -eq 'online')}
    }
    foreach($module in @('Psych0VMod-Microphone.cs','Psych0VMod-VoiceProfile.cs','Psych0VMod-VoiceCore.ps1')){
        [pscustomobject]@{id='app';name=$module;ready=[bool](Test-Path -LiteralPath (Join-Path $AppDir $module) -PathType Leaf);optional=$false}
    }
    [pscustomobject]@{id='key';name='Google Speech API';ready=[bool]([string]$config.google_api_key_encrypted);optional=($selectedMode -ne 'online')}
}
function Get-SetupText([string]$Language=[string]$config.language) {
    $texts=@{
        pl=@{present='Pliki obecne — działania nie testowano';missing='Brak';optional='Opcjonalne w tej konfiguracji';game='W Ustawieniach wybierz folder zawierający plik gry. Bez gry możesz skonfigurować aplikację.';mod='Zainstaluj składnik Psych0Mod w folderze gry; sam pusty folder nie wystarcza.';bridge='Przywróć pełny składnik moda z paczki instalacyjnej.';model='PL/EN: przywróć modele i silnik z pełnej paczki. DE/RU: użyj menedżera modeli, jeśli jest dostępny w Twojej wersji.';app='Przywróć komplet plików aplikacji z pełnej paczki.';key='Zapisz własny klucz w Ustawieniach. Offline go nie wymaga; hybryda bez klucza działa lokalnie.';saved='Klucz zapisany — poprawności nie testowano';scope='Kontrola lokalnych plików. Bez nagrywania, sieci i uruchamiania gry. Nie potwierdza działania mikrofonu ani integracji.';setup='Kreator';ui='Język okna';command='Język komend';restart='Zapisano. Uruchom program ponownie, aby zastosować język okna.';report='Raport utworzony';manual='Instrukcja';mode='Tryb rozpoznawania';models='Sprawdź modele'}
        en=@{present='Files present — operation not tested';missing='Missing';optional='Optional in this configuration';game='Select the folder containing the game executable in Settings. Setup can continue without the game.';mod='Install the Psych0Mod component in the game folder; an empty folder is insufficient.';bridge='Restore the complete mod component from the installer package.';model='PL/EN: restore models and engine from the full package. DE/RU: use the model manager if available in your version.';app='Restore all application files from the full package.';key='Save your own key in Settings. Offline needs no key; hybrid without a key remains local.';saved='Key saved — validity not tested';scope='Local file checks only. No recording, network or game launch. Microphone and game integration are not verified.';setup='Setup';ui='Interface language';command='Command language';restart='Saved. Restart to apply the interface language.';report='Report created';manual='Instructions';mode='Recognition mode';models='Check models'}
        de=@{present='Dateien vorhanden — Funktion nicht getestet';missing='Fehlt';optional='In dieser Konfiguration optional';game='In den Einstellungen den Ordner mit der Spiel-EXE auswählen. Einrichtung ohne Spiel möglich.';mod='Psych0Mod im Spielordner installieren; ein leerer Ordner reicht nicht.';bridge='Die vollständige Mod-Komponente aus dem Installationspaket wiederherstellen.';model='PL/EN: Modelle und Engine aus dem vollständigen Paket wiederherstellen. DE/RU: Modellverwaltung verwenden, falls verfügbar.';app='Alle Anwendungsdateien aus dem vollständigen Paket wiederherstellen.';key='Eigenen Schlüssel in den Einstellungen speichern. Offline benötigt keinen; Hybrid ohne Schlüssel arbeitet lokal.';saved='Schlüssel gespeichert — Gültigkeit nicht getestet';scope='Nur lokale Dateiprüfung. Keine Aufnahme, Netzwerkverbindung oder Spielstart. Mikrofon und Spielintegration nicht geprüft.';setup='Einrichtung';ui='Oberflächensprache';command='Befehlssprache';restart='Gespeichert. Für die Oberflächensprache neu starten.';report='Bericht erstellt';manual='Anleitung';mode='Erkennungsmodus';models='Modelle prüfen'}
        ru=@{present='Файлы присутствуют — работа не проверена';missing='Отсутствует';optional='Необязательно в этой конфигурации';game='В настройках выберите папку с EXE игры. Настройку можно завершить без игры.';mod='Установите Psych0Mod в папку игры; пустой папки недостаточно.';bridge='Восстановите полный компонент мода из установочного пакета.';model='PL/EN: восстановите модели и движок из полного пакета. DE/RU: используйте менеджер моделей, если он доступен.';app='Восстановите все файлы приложения из полного пакета.';key='Сохраните собственный ключ в настройках. Offline не требует ключа; Hybrid без ключа работает локально.';saved='Ключ сохранён — действительность не проверена';scope='Только локальные файлы. Без записи, сети и запуска игры. Микрофон и интеграция с игрой не проверены.';setup='Настройка';ui='Язык интерфейса';command='Язык команд';restart='Сохранено. Перезапустите приложение для смены языка окна.';report='Отчёт создан';manual='Инструкция';mode='Режим распознавания';models='Проверить модели'}
    }
    if(!$texts.ContainsKey($Language)){$Language='en'}
    return $texts[$Language]
}
function Get-ComponentCheck([string]$CommandLanguage="",[string]$InterfaceLanguage=[string]$config.language,[string]$VoiceMode="") {
    $text=Get-SetupText $InterfaceLanguage;$lines=@()
    foreach($check in @(Get-SetupChecks $CommandLanguage $VoiceMode)){
        $state=if($check.ready){if($check.id -eq 'key'){$text.saved}else{$text.present}}else{$text.missing}
        $lines+="$($check.name): $state"
        if(!$check.ready){$lines+='  '+$text[$check.id];if($check.optional){$lines+='  '+$text.optional}}
    }
    $lines+='';$lines+=$text.scope
    return ($lines -join "`r`n")
}

$script:startupStage="window controls"
# Separate taskbar identity and application icon.
try {
    Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class Psych0AppIdentity { [DllImport("shell32.dll", CharSet=CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id); }'
    [void][Psych0AppIdentity]::SetCurrentProcessExplicitAppUserModelID('Psych0VMod.Desktop')
} catch {}
# Record an existing developer installation when upgrading through the legacy updater.
try{
    $receiptPath=Join-Path $DataDir 'install.json'
    $installedMod=Mod-Path
    if(!(Test-Path $receiptPath) -and $installedMod -and (Test-Path (Join-Path $installedMod '.psych0-release.json'))){
        $ledger=Get-Content (Join-Path $installedMod '.psych0-release.json') -Raw -Encoding UTF8|ConvertFrom-Json
        if($ledger.channel -eq $ReleaseChannel.name){
            $receipt=@{schema=1;channel=$ReleaseChannel.name;app=[IO.Path]::GetFullPath($AppDir);mod=[IO.Path]::GetFullPath($installedMod);game=[IO.Path]::GetFullPath([string]$config.payday2_path)}
            Save-JsonFile $receiptPath $receipt
        }
    }
}catch{Write-AppLog 'WARN' 'INSTALL_RECEIPT_NOT_CREATED'}
$form=New-Object Windows.Forms.Form
$script:appIconPath=Join-Path $AppDir 'Psych0VMod.ico'
if(Test-Path -LiteralPath $script:appIconPath){$form.Icon=New-Object Drawing.Icon($script:appIconPath)}
$form.Text="Psych0VMod $AppVersion [$($ReleaseChannel.name)]"; $form.Size=New-Object Drawing.Size(900,710); $form.StartPosition="CenterScreen"
$windowLayout=New-Object Windows.Forms.TableLayoutPanel
$windowLayout.Dock='Fill';$windowLayout.ColumnCount=1;$windowLayout.RowCount=3
$windowLayout.Margin=New-Object Windows.Forms.Padding(0);$windowLayout.Padding=New-Object Windows.Forms.Padding(0)
[void]$windowLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,54)))
[void]$windowLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,100)))
[void]$windowLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,35)))
$form.Controls.Add($windowLayout)
$tabs=New-Object Windows.Forms.TabControl;$tabs.Dock='Fill';$tabs.Multiline=$true;$tabs.Margin=New-Object Windows.Forms.Padding(0);$windowLayout.Controls.Add($tabs,0,1)
$script:headerImage=$null
$header=New-Object Windows.Forms.Panel;$header.Dock='Top';$header.Height=54;$header.BackColor=[Drawing.Color]::FromArgb(24,28,32)
$header.BackgroundImageLayout='Stretch'
$headerTitle=New-Object Windows.Forms.Label;$headerTitle.Text="Psych0VMod   $AppVersion   [$($ReleaseChannel.name)]";$headerTitle.ForeColor=[Drawing.Color]::White;$headerTitle.BackColor=[Drawing.Color]::Transparent;$headerTitle.Font=New-Object Drawing.Font('Segoe UI',15,[Drawing.FontStyle]::Bold);$headerTitle.AutoSize=$true;$headerTitle.Location=New-Object Drawing.Point(18,12);$header.Controls.Add($headerTitle)
$header.Dock='Fill';$header.Margin=New-Object Windows.Forms.Padding(0);$windowLayout.Controls.Add($header,0,0)
$headerPath=Join-Path $AppDir 'assets\background.png'
if(Test-Path -LiteralPath $headerPath){
    $loaded=$null
    try{
        $loaded=[Drawing.Image]::FromFile($headerPath)
        $script:headerImage=New-Object Drawing.Bitmap -ArgumentList $loaded
        $header.BackgroundImage=$script:headerImage
    }catch{Write-AppLog 'WARN' 'Header image unavailable; solid background used.'}
    finally{if($loaded){$loaded.Dispose()}}
}

function New-Tab($Text){$p=New-Object Windows.Forms.TabPage;$p.Text=$Text;$p.AutoScroll=$true;$tabs.TabPages.Add($p)|Out-Null;return $p}
$tabConfig=New-Tab (T "config"); $tabTest=New-Tab (T "test"); $tabMacros=New-Tab (T "macros"); $tabSamples=New-Tab (T "samples"); $tabUpdates=New-Tab (T "updates"); $tabBackups=New-Tab (T "backups"); $tabInfo=New-Tab (T "info"); $tabDiagnostics=New-Tab $(switch([string]$config.language){"pl"{"Diagnostyka"};"de"{"Diagnose"};"ru"{"Диагностика"};default{"Diagnostics"}})

$grid=New-Object Windows.Forms.TableLayoutPanel; $grid.Dock="Top"; $grid.Height=490; $grid.ColumnCount=3; $grid.RowCount=12; $grid.Padding=New-Object Windows.Forms.Padding(15); $tabConfig.Controls.Add($grid)
function Add-Row($row,$label,$control,$button=$null){$l=New-Object Windows.Forms.Label;$l.Text=$label;$l.AutoSize=$true;$l.Margin=New-Object Windows.Forms.Padding(3,9,3,3);$grid.Controls.Add($l,0,$row);$control.Width=520;$grid.Controls.Add($control,1,$row);if($button){$grid.Controls.Add($button,2,$row)}}
$pathBox=New-Object Windows.Forms.TextBox;$pathBox.Text=[string]$config.payday2_path
$browse=New-Object Windows.Forms.Button;$browse.Text=T "browse";$browse.Add_Click({$d=New-Object Windows.Forms.FolderBrowserDialog;$d.Description="PAYDAY 2";if($d.ShowDialog() -eq "OK"){$pathBox.Text=$d.SelectedPath}});Add-Row 0 (T "game") $pathBox $browse
$langBox=New-Object Windows.Forms.ComboBox;$langBox.DropDownStyle="DropDownList";@("pl","en","de","ru")|%{$langBox.Items.Add($_)|Out-Null};$langBox.SelectedItem=[string]$config.language
$speechSettings=New-Object Windows.Forms.Button;$speechSettings.Text=(Get-SetupText).models;$speechSettings.Add_Click({if($ReleaseChannel.name -eq 'developer'){$tabs.SelectedTab=$tabDiagnostics;$diagnosticText.Text=Get-ComponentCheck}else{$tabs.SelectedTab=$tabModels}});Add-Row 1 (T "language") $langBox $speechSettings
$speechLanguageBox=New-Object Windows.Forms.ComboBox;$speechLanguageBox.DropDownStyle="DropDownList";@("pl","en","de","ru")|ForEach-Object {[void]$speechLanguageBox.Items.Add($_)};$speechLanguageBox.SelectedItem=[string]$config.speech_language;Add-Row 2 (T 'speech_language') $speechLanguageBox
$modeBox=New-Object Windows.Forms.ComboBox;$modeBox.FormattingEnabled=$true;$modeBox.Add_Format({param($sender,$eventArgs) $eventArgs.Value=Get-Psych0ModeLabel ([string]$eventArgs.ListItem)});$modeBox.DropDownStyle="DropDownList";@("offline","online","hybrid")|%{$modeBox.Items.Add($_)|Out-Null};$modeBox.SelectedItem=[string]$config.voice_mode;Add-Row 3 (T "mode") $modeBox
$seconds=New-Object Windows.Forms.NumericUpDown;$seconds.Minimum=1;$seconds.Maximum=10;$seconds.Value=[decimal]$config.listen_seconds;Add-Row 4 (T "seconds") $seconds
$duck=New-Object Windows.Forms.NumericUpDown;$duck.Minimum=0;$duck.Maximum=100;$duck.Value=[decimal]$config.duck_percent;Add-Row 5 (T "duck") $duck
$confidence=New-Object Windows.Forms.NumericUpDown;$confidence.Minimum=1;$confidence.Maximum=100;$confidence.Value=[decimal]([Math]::Round([double]$config.minimum_confidence*100));Add-Row 6 (T "confidence") $confidence
$googleKey=New-Object Windows.Forms.TextBox;$googleKey.UseSystemPasswordChar=$true;$googleKey.Text=""
$clearGoogleKey=New-Object Windows.Forms.Button;$clearGoogleKey.Text=T 'clear_key';$clearGoogleKey.Add_Click({$config.google_api_key_encrypted="";Save-JsonFile $ConfigFile $config;$googleKey.Clear();$status.Text=(PText 'text_305')});Add-Row 7 (T "google_key") $googleKey $clearGoogleKey
$hotkeyBox=New-Object Windows.Forms.TextBox;$hotkeyBox.ReadOnly=$true;$hotkeyBox.Text=[string]$config.hotkey;$hotkeyBox.Add_KeyDown({param($sender,$event);if($event.KeyCode -eq [Windows.Forms.Keys]::Back){$sender.Text="";$event.SuppressKeyPress=$true;return};if($event.KeyCode -in @([Windows.Forms.Keys]::ControlKey,[Windows.Forms.Keys]::ShiftKey,[Windows.Forms.Keys]::Menu,[Windows.Forms.Keys]::LWin,[Windows.Forms.Keys]::RWin)){return};$parts=@();if($event.Control){$parts+="Ctrl"};if($event.Alt){$parts+="Alt"};if($event.Shift){$parts+="Shift"};$parts+=$event.KeyCode.ToString();$sender.Text=($parts -join "+");$event.SuppressKeyPress=$true});Add-Row 8 (T "hotkey") $hotkeyBox
$startGame=New-Object Windows.Forms.CheckBox;$startGame.Text=T "start_game";$startGame.Checked=[bool]$config.start_with_game;$startGame.AutoSize=$true;$grid.Controls.Add($startGame,1,9)
$save=New-Object Windows.Forms.Button;$save.Text=T "save";$save.Width=180;$save.Add_Click({try{$oldLanguage=[string]$config.language;$newLanguage=[string]$langBox.SelectedItem;if($oldLanguage -ne $newLanguage -and ($script:featurePending -or $script:keybindPending -or $script:achievementPending -or $script:isListening -or ($script:offlinePending -and $script:offlinePending.Count))){throw (PText 'language_pending')};[void](Convert-Hotkey $hotkeyBox.Text);$config.payday2_path=$pathBox.Text;$config.language=[string]$langBox.SelectedItem;$config.speech_language=[string]$speechLanguageBox.SelectedItem;$config.voice_mode=[string]$modeBox.SelectedItem;$config.listen_seconds=[int]$seconds.Value;$config.duck_percent=[int]$duck.Value;$config.minimum_confidence=[double]$confidence.Value/100;if($googleKey.Text.Trim()){$config.google_api_key_encrypted=Protect-Secret $googleKey.Text.Trim();$googleKey.Clear()};$config.hotkey=$hotkeyBox.Text;$config.start_with_game=[bool]$startGame.Checked;$config.onboarding_completed=$true;Update-GameShortcut $config.start_with_game;Save-JsonFile $ConfigFile $config;if($oldLanguage -ne [string]$config.language){try{Set-Psych0ModLanguage ([string]$config.language)}catch{[void](Show-Psych0Message -Text ((PText 'language_sync_error')) -Caption ('Psych0VMod'))};[void](Show-Psych0Message -Text ((PText 'language_restart')) -Caption ('Psych0VMod'));Restart-Psych0Interface}else{(Show-Psych0Message -Text ((PText 'text_306')) -Caption ('Psych0VMod'))|Out-Null}}catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))|Out-Null}});$grid.Controls.Add($save,1,10)

$status=New-Object Windows.Forms.Label;$status.Text=T "ready";$status.Dock="Bottom";$status.Height=35;$status.Padding=New-Object Windows.Forms.Padding(10);$status.Dock='Fill';$status.Margin=New-Object Windows.Forms.Padding(0);$windowLayout.Controls.Add($status,0,2)
$testActions=New-Object Windows.Forms.ListBox;$testActions.Dock="Top";$testActions.Height=220;$tabTest.Controls.Add($testActions)
foreach($a in $catalog){[void]$testActions.Items.Add("$(Action-Name $a) [$($a.id)]")}
$testDescription=New-Object Windows.Forms.TextBox;$testDescription.Multiline=$true;$testDescription.ReadOnly=$true;$testDescription.ScrollBars="Vertical";$testDescription.Location=New-Object Drawing.Point(8,228);$testDescription.Size=New-Object Drawing.Size(850,245);$tabTest.Controls.Add($testDescription)
$testActions.Add_SelectedIndexChanged({if($testActions.SelectedIndex -ge 0){$testDescription.Text=Get-ActionDescription $catalog[$testActions.SelectedIndex]}})
$checkComponents=New-Object Windows.Forms.Button;$checkComponents.Text=T 'component_check';$checkComponents.Dock="Bottom";$checkComponents.Height=40;$checkComponents.Add_Click({try{(Show-Psych0Message -Text ((Get-ComponentCheck)) -Caption ((PText 'text_419')))|Out-Null}catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))|Out-Null}});$tabTest.Controls.Add($checkComponents)
$run=New-Object Windows.Forms.Button;$run.Text=T "run";$run.Dock="Bottom";$run.Height=45;$run.Add_Click({if($testActions.SelectedIndex -ge 0){Invoke-Psych0Action ([string]$catalog[$testActions.SelectedIndex].id)}});$tabTest.Controls.Add($run)

$script:startupStage="macro controls"
$macroList=New-Object Windows.Forms.ListView;$macroList.View="Details";$macroList.FullRowSelect=$true;$macroList.Dock="Top";$macroList.Height=240;[void]$macroList.Columns.Add((T "phrase"),330);[void]$macroList.Columns.Add((T "action"),430);[void]$macroList.Columns.Add("PL/EN/DE/RU",100);$tabMacros.Controls.Add($macroList)
function Refresh-Macros{$macroList.Items.Clear();foreach($m in @($script:macros)){$a=$catalog|? id -eq $m.action|select -First 1;$it=New-Object Windows.Forms.ListViewItem([string]$m.phrase);[void]$it.SubItems.Add((Action-Name $a));[void]$it.SubItems.Add([string]$m.language);$it.Tag=$m;[void]$macroList.Items.Add($it)}}
$phrase=New-Object Windows.Forms.TextBox;$phrase.Location=New-Object Drawing.Point(15,255);$phrase.Width=240;$tabMacros.Controls.Add($phrase)
$macroLanguage=New-Object Windows.Forms.ComboBox;$macroLanguage.Location=New-Object Drawing.Point(265,255);$macroLanguage.Width=70;$macroLanguage.DropDownStyle="DropDownList";@("pl","en","de","ru")|ForEach-Object {[void]$macroLanguage.Items.Add($_)};$macroLanguage.SelectedItem=[string]$config.speech_language;if($macroLanguage.SelectedIndex -lt 0){$macroLanguage.SelectedIndex=0};$tabMacros.Controls.Add($macroLanguage)
$actionBox=New-Object Windows.Forms.ComboBox;$actionBox.Location=New-Object Drawing.Point(345,255);$actionBox.Width=400;$actionBox.DropDownStyle="DropDownList";foreach($a in $catalog){[void]$actionBox.Items.Add("$(Action-Name $a) [$($a.id)]")};$actionBox.SelectedIndex=0;$tabMacros.Controls.Add($actionBox)
$macroDescription=New-Object Windows.Forms.TextBox;$macroDescription.Multiline=$true;$macroDescription.ReadOnly=$true;$macroDescription.ScrollBars="Vertical";$macroDescription.Location=New-Object Drawing.Point(15,290);$macroDescription.Size=New-Object Drawing.Size(820,160);$tabMacros.Controls.Add($macroDescription)
$actionBox.Add_SelectedIndexChanged({if($actionBox.SelectedIndex -ge 0){$macroDescription.Text=Get-ActionDescription $catalog[$actionBox.SelectedIndex]}});$macroDescription.Text=Get-ActionDescription $catalog[0]
$macroList.Add_SelectedIndexChanged({if($macroList.SelectedItems.Count){$m=$macroList.SelectedItems[0].Tag;$phrase.Text=[string]$m.phrase;$macroLanguage.SelectedItem=[string]$m.language;for($i=0;$i -lt $catalog.Count;$i++){if([string]$catalog[$i].id -eq [string]$m.action){$actionBox.SelectedIndex=$i;break}}}})
$add=New-Object Windows.Forms.Button;$add.Text=T "add";$add.Location=New-Object Drawing.Point(15,465);$add.Width=210;$add.Add_Click({try{
    $selectedId=if($macroList.SelectedItems.Count){[string]$macroList.SelectedItems[0].Tag.id}else{''}
    $script:macros=@(Set-Psych0VoiceMacro $phrase.Text ([string]$macroLanguage.SelectedItem) ([string]$catalog[$actionBox.SelectedIndex].id) $selectedId)
    Save-JsonFile $MacroFile $script:macros;Refresh-Macros;Refresh-SampleMacros;$phrase.Clear()
}catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_420')))}
});$tabMacros.Controls.Add($add)
$remove=New-Object Windows.Forms.Button;$remove.Text=T "remove";$remove.Location=New-Object Drawing.Point(235,465);$remove.Width=120;$remove.Add_Click({$selectedId=if($macroList.SelectedItems.Count){[string]$macroList.SelectedItems[0].Tag.id}else{""};$p=Normalize-Phrase $phrase.Text;$language=[string]$macroLanguage.SelectedItem;if(!$selectedId -and !$p){return};$script:macros=@($script:macros|Where-Object {if($selectedId){[string]$_.id -ne $selectedId}else{!($_.phrase -eq $p -and $_.language -eq $language)}});Save-JsonFile $MacroFile $script:macros;Refresh-Macros;Refresh-SampleMacros;$phrase.Clear()});$tabMacros.Controls.Add($remove)
$listen=New-Object Windows.Forms.Button;$listen.Text=T "listen";$listen.Location=New-Object Drawing.Point(365,465);$listen.Width=250;$tabMacros.Controls.Add($listen)
Refresh-Macros

$script:startupStage="sample controls"
$sampleHelp=New-Object Windows.Forms.Label;$sampleHelp.Text=(PText 'text_307');$sampleHelp.Location=New-Object Drawing.Point(15,15);$sampleHelp.Size=New-Object Drawing.Size(820,55);$tabSamples.Controls.Add($sampleHelp)
$sampleMacro=New-Object Windows.Forms.ComboBox;$sampleMacro.Location=New-Object Drawing.Point(15,80);$sampleMacro.Width=760;$sampleMacro.DropDownStyle="DropDownList";$tabSamples.Controls.Add($sampleMacro)
$sampleList=New-Object Windows.Forms.ListView;$sampleList.View="Details";$sampleList.FullRowSelect=$true;$sampleList.Location=New-Object Drawing.Point(15,120);$sampleList.Size=New-Object Drawing.Size(820,290);[void]$sampleList.Columns.Add((T "phrase"),360);[void]$sampleList.Columns.Add((T "action"),280);[void]$sampleList.Columns.Add("Confidence",120);$tabSamples.Controls.Add($sampleList)
function Refresh-SampleMacros{$selected=$sampleMacro.SelectedIndex;$sampleMacro.Items.Clear();foreach($m in @($script:macros)){[void]$sampleMacro.Items.Add("$($m.phrase) [$($m.action)]")};if($sampleMacro.Items.Count -gt 0){$sampleMacro.SelectedIndex=[Math]::Max(0,[Math]::Min($selected,$sampleMacro.Items.Count-1))}}
function Refresh-Samples{
    $sampleList.Items.Clear()
    if($sampleMacro.SelectedIndex -lt 0){return}
    $m=$script:macros[$sampleMacro.SelectedIndex]
    $items=@(Get-MacroSamples $m)
    foreach($s in $items){$it=New-Object Windows.Forms.ListViewItem([string]$s.phrase);[void]$it.SubItems.Add([string]$s.action);[void]$it.SubItems.Add($(if($s.PSObject.Properties["approved"] -and $s.approved){"Zatwierdzona / Approved"}else{"Nagrana / Recorded"}));$it.Tag=$s;[void]$sampleList.Items.Add($it)}
    $profile=$null;try{$profile=Get-ValidProfileEntry $m}catch{Write-AppLog "WARN" "Invalid stored profile"}
    $sampleProgress.Text="$($items.Count)/3 — $(if($profile){(PText 'text_308')}else{(PText 'text_309')})"
}
$sampleProgress=New-Object Windows.Forms.Label;$sampleProgress.Location=New-Object Drawing.Point(15,415);$sampleProgress.Size=New-Object Drawing.Size(820,30);$tabSamples.Controls.Add($sampleProgress)
$sampleMacro.Add_SelectedIndexChanged({try{Refresh-Samples}catch{$sampleProgress.Text=(PText 'text_310')}})
$recordSample=New-Object Windows.Forms.Button;$recordSample.Text=(PText 'text_311');$recordSample.Location=New-Object Drawing.Point(15,465);$recordSample.Width=210
$recordSample.Add_Click({
    if($sampleMacro.SelectedIndex -lt 0){return}
    $m=$script:macros[$sampleMacro.SelectedIndex]
    try{
        while(@(Get-MacroSamples $m).Count -lt 3){
            $n=@(Get-MacroSamples $m).Count+1
            $continue=(Show-Psych0Message -Text ((PText 'text_341' @($n,$($m.phrase)))) -Caption ((PText 'text_312')) -Buttons ([Windows.Forms.MessageBoxButtons]::OKCancel))
            if($continue -ne [Windows.Forms.DialogResult]::OK){return}
            [void](Record-VoiceSample $m);Refresh-Samples
        }
        foreach($existing in @(Get-MacroSamples $m)){
            if($existing.PSObject.Properties["approved"] -and $existing.approved){continue}
            $review=New-Object Media.SoundPlayer((Join-Path $SamplesDir ([string]$existing.file)))
            try{$review.PlaySync()}finally{$review.Dispose()}
            if((Show-Psych0Message -Text ((PText 'text_342' @($($m.phrase)))) -Caption ((PText 'text_313')) -Buttons ([Windows.Forms.MessageBoxButtons]::YesNo)) -ne [Windows.Forms.DialogResult]::Yes){return}
            $existing|Add-Member -NotePropertyName approved -NotePropertyValue $true -Force
        }
        Save-JsonFile $SamplesFile $script:samples
        $status.Text=(PText 'text_314');$status.Refresh()
        Build-MacroProfile $m
        Refresh-Samples;$status.Text=(PText 'text_465' @($($m.phrase)))
    }catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_421')))|Out-Null;Refresh-Samples}
});$tabSamples.Controls.Add($recordSample)
$playSample=New-Object Windows.Forms.Button;$playSample.Text=T "play";$playSample.Location=New-Object Drawing.Point(235,465);$playSample.Width=150;$playSample.Add_Click({if(!$sampleList.SelectedItems.Count){return};$file=Join-Path $SamplesDir ([string]$sampleList.SelectedItems[0].Tag.file);if(Test-Path $file){$player=New-Object Media.SoundPlayer($file);$player.PlaySync();$player.Dispose()}});$tabSamples.Controls.Add($playSample)
$deleteSample=New-Object Windows.Forms.Button;$deleteSample.Text=T "remove";$deleteSample.Location=New-Object Drawing.Point(395,465);$deleteSample.Width=150;$deleteSample.Add_Click({if(!$sampleList.SelectedItems.Count){return};$item=$sampleList.SelectedItems[0].Tag;$file=Join-Path $SamplesDir ([string]$item.file);if(Test-Path $file){Remove-Item -Force $file};$script:samples=@($script:samples|Where-Object {$_.id -ne $item.id});Save-JsonFile $SamplesFile $script:samples;$owner=@($script:macros|Where-Object {$_.id -eq $item.macro_id})|Select-Object -First 1;if($owner){Remove-Item (Get-ProfilePath $owner) -Force -ErrorAction SilentlyContinue};Refresh-Samples});$tabSamples.Controls.Add($deleteSample)
$profileLabels=@{
    pl=@{name="Uruchamiaj funkcje także na podstawie próbek głosu";help="Włączone: gdy Vosk nie rozpozna pewnej komendy, dopasowanie do Twoich nagranych próbek może uruchomić przypisaną funkcję gry.`r`n`r`nWyłączone: próbki działają w teście, ale nie uruchamiają funkcji przez klawisz nasłuchu. Pewne rozpoznanie Vosk nadal działa.`r`n`r`nPrzed włączeniem sprawdź komendy, inne słowa, ciszę i dźwięki gry przyciskiem Nasłuchuj i testuj."}
    en=@{name="Allow voice samples to trigger game actions";help="Enabled: when Vosk cannot identify a confident command, a match to your recorded samples can trigger the assigned game action.`r`n`r`nDisabled: samples work in tests but do not trigger actions through the listening hotkey. Confident Vosk recognition still works.`r`n`r`nBefore enabling, test your commands, other words, silence and game audio with Listen and test."}
    de=@{name="Spielaktionen auch durch Sprachproben auslösen";help="Aktiviert: Wenn Vosk keinen sicheren Befehl erkennt, kann ein Treffer zu Ihren Sprachproben die zugewiesene Spielaktion auslösen.`r`n`r`nDeaktiviert: Proben funktionieren im Test, lösen aber über die Hörtaste keine Aktionen aus. Sichere Vosk-Erkennung bleibt aktiv.`r`n`r`nTesten Sie vorher Befehle, andere Wörter, Stille und Spielgeräusche."}
    ru=@{name="Выполнять игровые действия также по образцам голоса";help="Включено: если Vosk не распознает команду уверенно, совпадение с вашими образцами может выполнить назначенное действие.`r`n`r`nВыключено: образцы работают в тесте, но не выполняют действия по клавише прослушивания. Уверенное распознавание Vosk продолжает работать.`r`n`r`nПеред включением проверьте команды, другие слова, тишину и звуки игры."}
}
$profileUiLanguage=([string]$config.language).ToLowerInvariant();if(!$profileLabels.ContainsKey($profileUiLanguage)){$profileUiLanguage="pl"}
$profileToolTip=New-Object Windows.Forms.ToolTip
$profileToolTip.InitialDelay=500;$profileToolTip.ReshowDelay=100;$profileToolTip.AutoPopDelay=30000;$profileToolTip.ShowAlways=$true
$profileEnable=New-Object Windows.Forms.CheckBox;$profileEnable.Text=$profileLabels[$profileUiLanguage].name;$profileEnable.Location=New-Object Drawing.Point(15,505);$profileEnable.Size=New-Object Drawing.Size(820,30);$profileEnable.Checked=[bool]$config.profile_actions_enabled;$profileEnable.Add_CheckedChanged({$config.profile_actions_enabled=[bool]$profileEnable.Checked;Save-JsonFile $ConfigFile $config});$tabSamples.Controls.Add($profileEnable);$profileToolTip.SetToolTip($profileEnable,[string]$profileLabels[$profileUiLanguage].help)
$tabSamples.Add_Enter({Refresh-SampleMacros;Refresh-Samples})
Refresh-SampleMacros;Refresh-Samples

$updateText=New-Object Windows.Forms.TextBox;$updateText.Multiline=$true;$updateText.ReadOnly=$true;$updateText.Dock="Top";$updateText.Height=430;$updateText.Font=New-Object Drawing.Font("Segoe UI",11);$tabUpdates.Controls.Add($updateText)
$checkUpdate=New-Object Windows.Forms.Button;$checkUpdate.Text=T "check";$checkUpdate.Width=220;$checkUpdate.Location=New-Object Drawing.Point(15,450);$tabUpdates.Controls.Add($checkUpdate)
$installAllUpdate=New-Object Windows.Forms.Button;$installAllUpdate.Text=$(switch([string]$config.language){"pl"{"Zaktualizuj PsychVMod"};"de"{"PsychVMod aktualisieren"};"ru"{"Обновить PsychVMod"};default{"Update PsychVMod"}});$installAllUpdate.Width=250;$installAllUpdate.Location=New-Object Drawing.Point(245,450);$installAllUpdate.Enabled=$false;$tabUpdates.Controls.Add($installAllUpdate)
$script:updateManifest=$null
$script:updateInProgress=$false
function Get-Psych0UpdatePlan($Manifest) {
    if(!$Manifest.components.psych0mod -or !$Manifest.components.psych0vmod){throw (PText 'text_460')}
    return [pscustomobject]@{app=(Test-NewerVersion ([string]$Manifest.components.psych0vmod.version) $AppVersion);mod=(Test-NewerVersion ([string]$Manifest.components.psych0mod.version) (Get-InstalledPsych0ModVersion))}
}
function Invoke-Psych0SuiteUpdate($Manifest,[ValidateSet('updates','app','mod','both')][string]$Mode='updates') {
    Assert-Psych0GameClosed
    Assert-Psych0ManifestChannel $Manifest
    if($Mode -eq 'updates'){$plan=Get-Psych0UpdatePlan $Manifest}
    else{
        $plan=[pscustomobject]@{app=($Mode -in @('app','both'));mod=($Mode -in @('mod','both'))}
        foreach($id in @('psych0vmod','psych0mod')){
            if(($id -eq 'psych0vmod' -and $plan.app) -or ($id -eq 'psych0mod' -and $plan.mod)){
                $component=$Manifest.components.$id
                if(!$component -or !$component.version -or [string]$component.sha256 -notmatch '^[0-9a-fA-F]{64}$'){throw (PText 'text_460')}
                [void]@(Get-Psych0ComponentUrls $component)
            }
        }
    }
    # Update the mod before self-update closes the running application.
    if($plan.mod){Install-Psych0ModUpdate $Manifest}
    if($plan.app){Install-Psych0VModUpdate $Manifest}
    return $plan
}
function Show-Psych0UpdateState {
    $script:ModVersion=Get-InstalledPsych0ModVersion
    $plan=Get-Psych0UpdatePlan $script:updateManifest
    $mod=$script:updateManifest.components.psych0mod;$app=$script:updateManifest.components.psych0vmod
    $appState=if($plan.app){"NOWA WERSJA / UPDATE AVAILABLE"}else{"BRAK NOWSZEJ WERSJI / UP TO DATE"}
    $modState=if($plan.mod){"NOWA WERSJA / UPDATE AVAILABLE"}else{"BRAK NOWSZEJ WERSJI / UP TO DATE"}
    $updateText.Text=(PText 'text_345' @($AppVersion,$($app.version),$appState,$ModVersion,$($mod.version),$modState,$($script:updateManifest.channel),$($script:updateManifest.published_utc)))
    $installAllUpdate.Enabled=(!$script:updateInProgress -and ($plan.app -or $plan.mod))
}
$checkUpdate.Add_Click({
    if($script:updateInProgress){return}
    $checkUpdate.Enabled=$false;$installAllUpdate.Enabled=$false;$script:updateManifest=$null
    try{$status.Text=(PText 'text_461');$script:updateManifest=Get-UpdateManifest;Show-Psych0UpdateState;$status.Text=T "ready"}
    catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_278')))|Out-Null;$status.Text=(PText 'text_315')}
    finally{$checkUpdate.Enabled=$true}
})
$installAllUpdate.Add_Click({
    if($script:updateInProgress -or !$script:updateManifest){return}
    try{
        Assert-Psych0GameClosed
        $plan=Get-Psych0UpdatePlan $script:updateManifest
        if(!$plan.app -and !$plan.mod){Show-Psych0UpdateState;return}
        $message=if([string]$config.language -eq 'pl'){(PText 'text_316')}else{(PText 'text_316')}
        if((Show-Psych0Message -Text ($message) -Caption ("PsychVMod") -Buttons ([Windows.Forms.MessageBoxButtons]::YesNo)) -ne "Yes"){return}
        $script:updateInProgress=$true;$checkUpdate.Enabled=$false;$installAllUpdate.Enabled=$false;$reinstallButton.Enabled=$false;$reinstallScope.Enabled=$false
        $result=Invoke-Psych0SuiteUpdate $script:updateManifest
        if(!$result.app){$status.Text=(PText 'text_297')}
    }catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_278')))|Out-Null;$status.Text=(PText 'text_315')}
    finally{
        $script:updateInProgress=$false
        if(!$form.IsDisposed){$checkUpdate.Enabled=$true;$reinstallButton.Enabled=$true;$reinstallScope.Enabled=$true;if($script:updateManifest){Show-Psych0UpdateState};Refresh-Backups}
    }
})

# Reinstallation deliberately ignores version comparison; user settings live outside managed files.
$tabUpdates.AutoScroll=$true
if($ReleaseChannel.name -eq 'developer'){
    $githubAuth=New-Object Windows.Forms.Button;$githubAuth.Text=PText 'github_auth_title';$githubAuth.Location=New-Object Drawing.Point(15,640);$githubAuth.Size=New-Object Drawing.Size(300,35);$tabUpdates.Controls.Add($githubAuth)
    $githubAuth.Add_Click({try{Clear-Psych0GithubCredential;[void](Get-Psych0GithubToken);$status.Text=PText 'github_auth_saved'}catch{$status.Text=PText 'github_auth_cancelled'}})
}

$reinstallScope=New-Object Windows.Forms.ComboBox;$reinstallScope.DropDownStyle='DropDownList';$reinstallScope.Location=New-Object Drawing.Point(15,500);$reinstallScope.Width=300
foreach($key in @('reinstall_app','reinstall_mod','reinstall_both')){[void]$reinstallScope.Items.Add((PText $key))};$reinstallScope.SelectedIndex=2;$tabUpdates.Controls.Add($reinstallScope)
$reinstallButton=New-Object Windows.Forms.Button;$reinstallButton.Text=PText 'reinstall_button';$reinstallButton.Location=New-Object Drawing.Point(325,498);$reinstallButton.Size=New-Object Drawing.Size(270,35);$tabUpdates.Controls.Add($reinstallButton)
$reinstallHelp=New-Object Windows.Forms.Label;$reinstallHelp.Text=PText 'reinstall_help';$reinstallHelp.Location=New-Object Drawing.Point(15,542);$reinstallHelp.Size=New-Object Drawing.Size(800,85);$tabUpdates.Controls.Add($reinstallHelp)
$reinstallButton.Add_Click({
    if($script:updateInProgress){return}
    $mode=@('app','mod','both')[$reinstallScope.SelectedIndex]
    if((Show-Psych0Message -Text (PText 'reinstall_confirm' @([string]$reinstallScope.SelectedItem)) -Caption (PText 'reinstall_button') -Buttons 'YesNo' -DefaultButton 'Button2') -ne 'Yes'){return}
    $script:updateInProgress=$true;$checkUpdate.Enabled=$false;$installAllUpdate.Enabled=$false;$reinstallButton.Enabled=$false;$reinstallScope.Enabled=$false
    try{
        Assert-Psych0GameClosed
        $status.Text=PText 'reinstall_loading';[Windows.Forms.Application]::DoEvents()
        $manifest=Get-UpdateManifest
        $result=Invoke-Psych0SuiteUpdate $manifest $mode
        $script:updateManifest=$manifest
        if(!$result.app){$status.Text=PText 'reinstall_done'}
    }catch{(Show-Psych0Message -Text (PText $_.Exception.GetBaseException().Message) -Caption (PText 'text_278'))|Out-Null;$status.Text=PText 'text_315'}
    finally{
        $script:updateInProgress=$false
        if(!$form.IsDisposed){$checkUpdate.Enabled=$true;$reinstallButton.Enabled=$true;$reinstallScope.Enabled=$true;Refresh-Backups;try{if($script:updateManifest){Show-Psych0UpdateState}}catch{$installAllUpdate.Enabled=$false}}
    }
})

$backupList=New-Object Windows.Forms.ListBox;$backupList.Dock="Top";$backupList.Height=430;$tabBackups.Controls.Add($backupList)
function Refresh-Backups{$backupList.Items.Clear();foreach($f in @(Get-ChildItem $BackupDir -Filter "*.zip"|Where-Object {$_.Name -like "Psych0Mod-*.zip" -or $_.Name -like "Psych0VMod-App-*.zip"}|Sort-Object LastWriteTime -Descending)){[void]$backupList.Items.Add($f)}}
$makeBackup=New-Object Windows.Forms.Button;$makeBackup.Text=T "make_backup";$makeBackup.Width=180;$makeBackup.Location=New-Object Drawing.Point(15,450);$makeBackup.Add_Click({try{[void](New-Psych0Backup);Refresh-Backups;$status.Text=(PText 'text_319')}catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_422')))|Out-Null}});$tabBackups.Controls.Add($makeBackup)
$restoreBackup=New-Object Windows.Forms.Button;$restoreBackup.Text=T "restore";$restoreBackup.Width=220;$restoreBackup.Location=New-Object Drawing.Point(205,450);$restoreBackup.Add_Click({if(!$backupList.SelectedItem){return};$selected=$backupList.SelectedItem;if((Show-Psych0Message -Text ((PText 'text_317')) -Caption ('Psych0VMod') -Buttons ([Windows.Forms.MessageBoxButtons]::YesNo)) -ne "Yes"){return};try{if($selected.Name -like "Psych0VMod-App-*.zip"){Restore-Psych0VModBackup ([string]$selected.FullName)}else{Restore-Psych0Backup ([string]$selected.FullName);Refresh-Backups;$status.Text=(PText 'text_318')}}catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_423')))|Out-Null}});$tabBackups.Controls.Add($restoreBackup)
$refreshBackup=New-Object Windows.Forms.Button;$refreshBackup.Text=T "refresh";$refreshBackup.Width=150;$refreshBackup.Location=New-Object Drawing.Point(435,450);$refreshBackup.Add_Click({Refresh-Backups});$tabBackups.Controls.Add($refreshBackup)
Refresh-Backups

$diagnosticText=New-Object Windows.Forms.TextBox;$diagnosticText.Multiline=$true;$diagnosticText.ReadOnly=$true;$diagnosticText.ScrollBars="Vertical";$diagnosticText.Dock="Fill";$diagnosticText.Font=New-Object Drawing.Font("Segoe UI",11);$tabDiagnostics.Controls.Add($diagnosticText)
$diagnosticButtons=New-Object Windows.Forms.FlowLayoutPanel;$diagnosticButtons.Dock="Bottom";$diagnosticButtons.Height=100;$diagnosticButtons.WrapContents=$true;$diagnosticButtons.AutoScroll=$true;$tabDiagnostics.Controls.Add($diagnosticButtons)
$diagnosticRefresh=New-Object Windows.Forms.Button;$diagnosticRefresh.Text=T "refresh";$diagnosticRefresh.Width=180;$diagnosticRefresh.Height=35;$diagnosticRefresh.Add_Click({$diagnosticText.Text=Get-ComponentCheck});$diagnosticButtons.Controls.Add($diagnosticRefresh)
$repairButton=New-Object Windows.Forms.Button;$repairButton.Text=(PText 'text_320');$repairButton.Width=240;$repairButton.Height=35
$repairButton.Add_Click({try{
    Assert-Psych0GameClosed
    $work=Join-Path ([IO.Path]::GetTempPath()) ('Psych0VMod-recovery-'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force $work|Out-Null
    foreach($name in @('Psych0VMod-Channel.ps1','channel.json','Napraw-PsychVMod.ps1','Psych0VMod-Integrity.ps1','Psych0VMod-RepairCore.ps1','Psych0VMod-Restart.ps1','Psych0VMod-Localization.ps1','localization.json')){Copy-Item -LiteralPath (Join-Path $AppDir $name) -Destination $work -Force}
    $args=@('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $work 'Napraw-PsychVMod.ps1')+'"'),'-ParentPid',$PID,'-AppTarget',('"'+$AppDir+'"'))
    if($config.payday2_path){$args+=@('-GamePath',('"'+[string]$config.payday2_path+'"'))}
    Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -ArgumentList $args
    $form.Close()
}catch{Write-AppLog 'ERROR' $_.Exception.ToString();[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_248')))}})
$diagnosticButtons.Controls.Add($repairButton)

$diagnosticText.Text=Get-ComponentCheck;$diagnosticButtons.BringToFront()
$tabs.Add_SelectedIndexChanged({if($tabs.SelectedTab -eq $tabDiagnostics){$diagnosticText.Text=Get-ComponentCheck}})

$infoButtons=New-Object Windows.Forms.FlowLayoutPanel;$infoButtons.Dock="Bottom";$infoButtons.Height=55;$tabInfo.Controls.Add($infoButtons)
$reportButton=New-Object Windows.Forms.Button;$reportButton.Text=T 'report';$reportButton.Width=240;$reportButton.Height=35;$reportButton.Add_Click({try{$path=New-DiagnosticReport;[Windows.Forms.Clipboard]::SetText($path);Start-Process explorer.exe -ArgumentList @("/select,`"$path`"");$status.Text=(Get-SetupText).report}catch{Write-AppLog "ERROR" $_.Exception.ToString();(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_424')))|Out-Null}});$diagnosticButtons.Controls.Add($reportButton)
$openDataButton=New-Object Windows.Forms.Button;$openDataButton.Text=T 'open_data';$openDataButton.Width=220;$openDataButton.Height=35;$openDataButton.Add_Click({Start-Process explorer.exe -ArgumentList @("`"$DataDir`"")});$infoButtons.Controls.Add($openDataButton)
$contactButtons=New-Object Windows.Forms.FlowLayoutPanel;$contactButtons.Dock='Top';$contactButtons.Height=58;$contactButtons.WrapContents=$false;$contactButtons.AutoScroll=$true;$tabInfo.Controls.Add($contactButtons)
$contactWriteButton=New-Object Windows.Forms.Button;$contactWriteButton.Text=PText 'contact_write';$contactWriteButton.Width=220;$contactWriteButton.Height=35
$contactWriteButton.Add_Click({try{Start-Process -FilePath (Get-Psych0ContactUri) -ErrorAction Stop}catch{(Show-Psych0Message -Text (PText 'contact_open_failed') -Caption (PText 'contact_title'))|Out-Null}});$contactButtons.Controls.Add($contactWriteButton)
$contactBugButton=New-Object Windows.Forms.Button;$contactBugButton.Text=PText 'contact_bug';$contactBugButton.Width=220;$contactBugButton.Height=35
$contactBugButton.Add_Click({try{Start-Process -FilePath (Get-Psych0ContactUri -ReportBug -Version $AppVersion) -ErrorAction Stop}catch{(Show-Psych0Message -Text (PText 'contact_open_failed') -Caption (PText 'contact_title'))|Out-Null}});$contactButtons.Controls.Add($contactBugButton)
$contactCopyButton=New-Object Windows.Forms.Button;$contactCopyButton.Text=PText 'contact_copy';$contactCopyButton.Width=220;$contactCopyButton.Height=35
$contactCopyButton.Add_Click({[Windows.Forms.Clipboard]::SetText((Get-Psych0ProjectEmail));$status.Text=PText 'contact_copied'});$contactButtons.Controls.Add($contactCopyButton)
$supportButtons=New-Object Windows.Forms.FlowLayoutPanel;$supportButtons.Dock='Top';$supportButtons.Height=58;$supportButtons.WrapContents=$false;$supportButtons.AutoScroll=$true;$tabInfo.Controls.Add($supportButtons)
$supportOpenButton=New-Object Windows.Forms.Button;$supportOpenButton.Text=PText 'support_open';$supportOpenButton.Width=300;$supportOpenButton.Height=35
$supportOpenButton.Add_Click({try{Start-Process -FilePath (Get-Psych0SupportUri) -ErrorAction Stop}catch{(Show-Psych0Message -Text (PText 'support_open_failed' @((Get-Psych0SupportUri))) -Caption (PText 'notice_support_title'))|Out-Null}});$supportButtons.Controls.Add($supportOpenButton)
$supportCopyButton=New-Object Windows.Forms.Button;$supportCopyButton.Text=PText 'support_copy';$supportCopyButton.Width=220;$supportCopyButton.Height=35
$supportCopyButton.Add_Click({[Windows.Forms.Clipboard]::SetText((Get-Psych0SupportUri));$status.Text=PText 'support_copied'});$supportButtons.Controls.Add($supportCopyButton)
$supportQrButton=New-Object Windows.Forms.Button;$supportQrButton.Text=PText 'support_qr';$supportQrButton.Width=220;$supportQrButton.Height=35
$supportQrButton.Add_Click({
 $qrDialog=$null;$qrImage=$null
 try{
  $qrImage=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'assets/support-buycoffee-qr.png'))
  $qrDialog=New-Object Windows.Forms.Form;$qrDialog.Text=PText 'support_qr';$qrDialog.StartPosition='CenterParent';$qrDialog.Size=New-Object Drawing.Size(420,600);$qrDialog.MinimumSize=New-Object Drawing.Size(320,450);$qrDialog.MinimizeBox=$false
  $qrPicture=New-Object Windows.Forms.PictureBox;$qrPicture.Dock='Fill';$qrPicture.SizeMode='Zoom';$qrPicture.BackColor=[Drawing.Color]::White;$qrPicture.Image=$qrImage;$qrDialog.Controls.Add($qrPicture)
  [void]$qrDialog.ShowDialog($form)
 }catch{(Show-Psych0Message -Text (PText 'support_open_failed' @((Get-Psych0SupportUri))) -Caption (PText 'notice_support_title'))|Out-Null}
 finally{if($qrDialog){$qrDialog.Dispose()};if($qrImage){$qrImage.Dispose()}}
});$supportButtons.Controls.Add($supportQrButton)
$info=New-Object Windows.Forms.TextBox;$info.Multiline=$true;$info.ReadOnly=$true;$info.Dock="Fill";$info.ScrollBars="Vertical";$info.Font=New-Object Drawing.Font("Segoe UI",11);$helpTexts=@{
pl="Program steruje funkcjami Psych0Mod przez most komunikacyjny.`r`n`r`nOFFLINE: Vosk rozpoznaje tekst i dopasowuje go do zapisanej frazy. Język komendy musi odpowiadać modelowi: amunicja → PL, full ammo → EN. Dla komend w obu językach potrzebne są oba modele.`r`n`r`nPRÓBKI: są opcjonalne. Kreator zbiera trzy zatwierdzone nagrania i tworzy jeden wzorzec. Przy niepewnym wyniku Vosk program może porównać głos ze wzorcem. Wynik profilu nie jest procentem pewności Vosk. Wykonywanie funkcji przez profile włączasz w zakładce próbek; przycisk testu sprawdza je także przy wyłączonej opcji.`r`n`r`nONLINE: wymaga Internetu i własnego klucza Google Speech API. Usługa może naliczać opłaty. HYBRID: najpierw próbuje lokalnie; po niepowodzeniu używa Google, jeśli zapisano klucz. Nagranie wysyłane do rozpoznania online opuszcza komputer.`r`n`r`nDIAGNOSTYKA: sprawdza obecność plików, nie działanie mikrofonu ani gry. Raport nie zawiera nagrań, fraz, kluczy, ścieżek użytkownika ani surowych logów.`r`n`r`nKOPIE: aplikacja i mod mają osobne kopie. Zachowywanych jest pięć najnowszych kopii każdego rodzaju.`r`n`r`nPo zmianie mikrofonu lub dużej zmianie sposobu mówienia może być potrzebne ponowne nagranie próbek. Niebezpieczne funkcje wymagają potwierdzenia myszą w grze."
en="OFFLINE: Vosk converts speech to text and matches a saved phrase. Match the command language to the model: amunicja → PL, full ammo → EN. Commands in both languages require both models.`r`n`r`nSAMPLES: optional. The wizard builds one profile from three approved recordings. Profiles can handle uncertain Vosk results; profile distance is not Vosk confidence. Enable profile action execution in Samples. The test button checks profiles even when execution is disabled.`r`n`r`nONLINE: Internet and your own Google Speech API key are required; provider charges may apply. HYBRID tries local recognition first, then Google if a key is saved. Online recognition sends audio outside your computer.`r`n`r`nDIAGNOSTICS checks local files, not microphone hardware or game integration. Reports exclude audio, phrases, keys, user paths and raw logs.`r`n`r`nBACKUPS: app and mod have separate backups; five latest of each are kept. A changed microphone or speaking style may require new samples. Dangerous actions require mouse confirmation in game."
de="OFFLINE: Vosk erkennt Text und vergleicht ihn mit einer gespeicherten Phrase. Sprache und Modell müssen zusammenpassen: amunicja → PL, full ammo → EN. Beide Sprachen benötigen beide Modelle.`r`n`r`nSPRACHPROBEN: optional. Drei bestätigte Aufnahmen bilden ein Profil für unsichere Vosk-Ergebnisse. Profilabstand ist keine Vosk-Konfidenz. Profilausführung muss aktiviert werden; der Test prüft Profile auch bei deaktivierter Ausführung.`r`n`r`nONLINE benötigt Internet und einen eigenen Google Speech API-Schlüssel; Gebühren sind möglich. HYBRID versucht zuerst lokale Erkennung und danach Google, falls ein Schlüssel gespeichert ist. Online wird Audio an den Anbieter gesendet.`r`n`r`nDIAGNOSE prüft Dateien, nicht Mikrofon oder Spiel. Berichte enthalten keine Aufnahmen, Phrasen, Schlüssel, Benutzerpfade oder Rohprotokolle.`r`n`r`nJe fünf separate Sicherungen für App und Mod. Nach Mikrofonwechsel können neue Proben nötig sein. Gefährliche Funktionen erfordern eine Bestätigung per Maus im Spiel."
ru="OFFLINE: Vosk распознаёт текст и сравнивает его с сохранённой фразой. Язык команды должен соответствовать модели: amunicja → PL, full ammo → EN. Для двух языков нужны обе модели.`r`n`r`nОБРАЗЦЫ: необязательны. Три подтверждённые записи создают профиль для неуверенных результатов Vosk. Расстояние профиля не является уверенностью Vosk. Выполнение через профили нужно включить; тест проверяет их и при отключённом выполнении.`r`n`r`nONLINE требует Интернет и собственный ключ Google Speech API; возможна плата. HYBRID сначала использует локальное распознавание, затем Google при наличии ключа. Онлайн отправляет звук провайдеру.`r`n`r`nДИАГНОСТИКА проверяет файлы, а не микрофон или игру. Отчёт не содержит записей, фраз, ключей, путей пользователя или исходных журналов.`r`n`r`nХранятся пять отдельных копий приложения и мода. После смены микрофона могут потребоваться новые образцы. Опасные функции требуют подтверждения мышью в игре."
}
$helpLanguage=[string]$config.language;if(!$helpTexts.ContainsKey($helpLanguage)){$helpLanguage="en"}
$info.Text="Psych0VMod $AppVersion`r`n`r`n"+(Get-Psych0ProjectNoticeText)+"`r`n`r`n"+(PText 'notice_help_title')+"`r`n`r`n"+$helpTexts[$helpLanguage];$tabInfo.Controls.Add($info);$info.BringToFront()

function Start-VoiceRecognition([bool]$TestOnly=$false) {
    if($script:isListening -or $script:modelDownloadBusy){return}
    if(@($script:macros).Count -eq 0){(Show-Psych0Message -Text ((PText 'text_321')) -Caption ('Psych0VMod'))|Out-Null;return}
    $script:isListening=$true
    $script:profileDiagnostic=(PText 'text_462')
    $script:voiceReport=@((PText 'voice_last_test' @($AppVersion)),"$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",(PText 'voice_mode' @((Get-Psych0ModeLabel ([string]$config.voice_mode)))))
    $previousVolume=$null;$wav=$null
    try {
        $mode=[string]$config.voice_mode
        if($mode -notin @("offline","online","hybrid")){throw (PText 'text_463')}
        $hasCloud=($mode -ne "offline" -and [bool](Unprotect-Secret ([string]$config.google_api_key_encrypted)))
        if($mode -eq "online" -and !$hasCloud){throw (PText 'text_283')}
        $wav=Join-Path $env:TEMP ("Psych0VMod-recording-"+[guid]::NewGuid().ToString("N")+".wav")
        $previousVolume=Start-AudioDuck
        Record-MicrophoneWav $wav ([int]$config.listen_seconds)
        # Restore game volume before network calls, which can take up to 20 seconds.
        Stop-AudioDuck $previousVolume;$previousVolume=$null
        $decision=Resolve-Psych0VoiceCommand $wav $TestOnly
        $selected=$decision.macro;$details=$decision.detail
        if(!$selected){
            $status.Text=switch($decision.reason){
                'input' {(PText 'text_322')}
                'ambiguous' {(PText 'text_323')}
                'models' {(PText 'text_324')}
                'profile-disabled' {(PText 'text_325')}
                default {(PText 'text_326')}
            }
            if($decision.result -and $decision.result.text){$status.Text+=" ($($decision.result.text), $([Math]::Round($decision.result.confidence*100))%)"}
            return
        }
        if($TestOnly){$status.Text=PText 'voice_test' @($selected.phrase,(Action-Name ($catalog|Where-Object id -eq $selected.action|Select-Object -First 1)),$details)}else{Invoke-Psych0Action ([string]$selected.action)}

    } catch {
        Write-AppLog "ERROR" $_.Exception.ToString()
        (Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_425')))|Out-Null
        $status.Text=(PText 'text_315')
    } finally {
        $script:voiceReport+=PText 'voice_result' @($status.Text)
        try{Stop-AudioDuck $previousVolume}catch{}
        if($wav -and (Test-Path $wav)){Remove-Item -Force $wav -ErrorAction SilentlyContinue}
        $script:isListening=$false
    }
}

$voiceDetails=New-Object Windows.Forms.Button
$voiceDetails.Text=$(if($config.language -eq "pl"){ (PText 'text_327') }else{ (PText 'text_327') })
$voiceDetails.Location=New-Object Drawing.Point(625,465);$voiceDetails.Width=210
$voiceDetails.Add_Click({
    $report=if($script:voiceReport){$script:voiceReport -join "`r`n`r`n"}else{(PText 'text_328')}
    (Show-Psych0Message -Text ($report) -Caption ((PText 'text_329')))|Out-Null
})
if($ReleaseChannel.name -eq 'developer'){$tabMacros.Controls.Add($voiceDetails)}
$listen.Add_Click({Start-VoiceRecognition $true})

function Install-OptionalModelArchive([string]$Archive,$Spec) {
    if([string]$Spec.language -notin @('de','ru') -or [string]$Spec.root -notmatch '^vosk-model-small-[a-z]{2}-[0-9.]+$'){throw (PText 'text_405')}
    Assert-UpdateArchive $Archive ([string]$Spec.sha256)
    $unpack=Join-Path $DataDir ('model-unpack-'+[guid]::NewGuid().ToString('N'))
    try{
        New-Item -ItemType Directory $unpack|Out-Null
        Expand-Archive -LiteralPath $Archive -DestinationPath $unpack
        $source=Join-Path $unpack ([string]$Spec.root)
        foreach($required in @('am\final.mdl','conf\model.conf','conf\mfcc.conf','graph\HCLr.fst','graph\Gr.fst')){
            $file=Join-Path $source $required
            if(!(Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -eq 0){throw (PText 'text_343' @($required))}
        }
        if('Psych0VModVosk' -as [type]){[Psych0VModVosk]::CloseModels()}
        Set-TransactionalDirectory $source (Join-Path $DataDir ('models\'+$Spec.language)) $false
    }finally{if(Test-Path -LiteralPath $unpack){Remove-Item -LiteralPath $unpack -Recurse -Force}}
}
$script:modelDownloadBusy=$false;$script:modelDownloadCancel=$false
$tabModels=New-Tab $(switch([string]$config.language){'pl'{(PText 'text_330')};'de'{(PText 'text_330')};'ru'{(PText 'text_330')};default{(PText 'text_330')}})
$modelTexts=@{
pl=@('PL i EN są w pełnej paczce. DE i RU pobierasz tylko na życzenie. Internet jest potrzebny do pobrania; późniejsze rozpoznawanie działa offline. Pobranie nie wysyła nagrań ani kluczy.','Pobierz model','Anuluj','Odśwież','Zainstalowany','Nie zainstalowano','Pobieranie','Sprawdzanie i instalacja','Gotowe — wybierz język przy komendzie.','Anulowano');
en=@('PL and EN are bundled. Download DE and RU only when wanted. Internet is needed for download; recognition then works offline. No recordings or keys are uploaded.','Download model','Cancel','Refresh','Installed','Not installed','Downloading','Verifying and installing','Ready — select the language for your command.','Cancelled');
de=@('PL und EN sind enthalten. DE und RU auf Wunsch herunterladen. Internet nur zum Download nötig, danach offline. Keine Aufnahmen oder Schlüssel werden gesendet.','Modell herunterladen','Abbrechen','Aktualisieren','Installiert','Nicht installiert','Download','Prüfen und installieren','Bereit — Sprache beim Befehl wählen.','Abgebrochen');
ru=@('PL и EN включены. DE и RU можно скачать по желанию. Интернет нужен для скачивания, затем распознавание офлайн. Записи и ключи не отправляются.','Скачать модель','Отмена','Обновить','Установлено','Не установлено','Загрузка','Проверка и установка','Готово — выберите язык команды.','Отменено')
}
$modelUiLanguage=[string]$config.language;if(!$modelTexts.ContainsKey($modelUiLanguage)){$modelUiLanguage='en'}
$modelWords=$modelTexts[$modelUiLanguage]
$modelHelp=New-Object Windows.Forms.Label;$modelHelp.Text=$modelWords[0];$modelHelp.Location=New-Object Drawing.Point(15,15);$modelHelp.Size=New-Object Drawing.Size(820,80);$tabModels.Controls.Add($modelHelp)
$modelChoice=New-Object Windows.Forms.ComboBox;$modelChoice.DropDownStyle='DropDownList';$modelChoice.Location=New-Object Drawing.Point(15,105);$modelChoice.Width=600;$tabModels.Controls.Add($modelChoice)
$script:modelCatalog=Get-Content -Raw -Encoding UTF8 (Join-Path $AppDir 'model-catalog.json')|ConvertFrom-Json
$script:modelCatalog=@($script:modelCatalog)
foreach($spec in $script:modelCatalog){[void]$modelChoice.Items.Add("$($spec.language.ToUpperInvariant()) — $($spec.root) — $([Math]::Round($spec.bytes/1MB,1)) MiB — $($spec.license)")};if($modelChoice.Items.Count){$modelChoice.SelectedIndex=0}
$modelState=New-Object Windows.Forms.TextBox;$modelState.Multiline=$true;$modelState.ReadOnly=$true;$modelState.Location=New-Object Drawing.Point(15,150);$modelState.Size=New-Object Drawing.Size(820,170);$tabModels.Controls.Add($modelState)
$modelProgress=New-Object Windows.Forms.ProgressBar;$modelProgress.Location=New-Object Drawing.Point(15,340);$modelProgress.Size=New-Object Drawing.Size(820,25);$tabModels.Controls.Add($modelProgress)
$modelDownload=New-Object Windows.Forms.Button;$modelDownload.Text=$modelWords[1];$modelDownload.Location=New-Object Drawing.Point(15,385);$modelDownload.Size=New-Object Drawing.Size(240,35);$tabModels.Controls.Add($modelDownload)
$modelCancel=New-Object Windows.Forms.Button;$modelCancel.Text=$modelWords[2];$modelCancel.Enabled=$false;$modelCancel.Location=New-Object Drawing.Point(270,385);$modelCancel.Size=New-Object Drawing.Size(180,35);$modelCancel.Add_Click({$script:modelDownloadCancel=$true});$tabModels.Controls.Add($modelCancel)
$modelRefresh=New-Object Windows.Forms.Button;$modelRefresh.Text=$modelWords[3];$modelRefresh.Location=New-Object Drawing.Point(465,385);$modelRefresh.Size=New-Object Drawing.Size(180,35);$tabModels.Controls.Add($modelRefresh)
function Refresh-ModelState {
    $modelState.Text=(@('pl','en','de','ru')|ForEach-Object {"$($_.ToUpperInvariant()): "+$(if(Test-VoskReady $_){$modelWords[4]}else{$modelWords[5]})}) -join "`r`n"
}
$modelRefresh.Add_Click({Refresh-ModelState});Refresh-ModelState
$modelDownload.Add_Click({
    if($script:modelDownloadBusy -or $script:isListening -or $modelChoice.SelectedIndex -lt 0){return}
    $spec=$script:modelCatalog[$modelChoice.SelectedIndex]
    $uri=[Uri]$spec.url
    if($uri.Scheme -ne 'https' -or $uri.Host -ne 'alphacephei.com'){(Show-Psych0Message -Text ((PText 'text_406')) -Caption ('Psych0VMod'))|Out-Null;return}
    $script:modelDownloadBusy=$true;$script:modelDownloadCancel=$false
    $modelDownload.Enabled=$false;$modelChoice.Enabled=$false;$modelRefresh.Enabled=$false;$modelCancel.Enabled=$true
    foreach($page in $tabs.TabPages){if($page -ne $tabModels){$page.Enabled=$false}}
    $downloadDir=Join-Path $DataDir ('model-download-'+[guid]::NewGuid().ToString('N'));$client=$null
    try{
        New-Item -ItemType Directory $downloadDir|Out-Null;$archive=Join-Path $downloadDir 'model.zip'
        $client=New-Object Net.WebClient
        $task=$client.DownloadFileTaskAsync($uri,$archive);$clock=[Diagnostics.Stopwatch]::StartNew()
        while(!$task.IsCompleted){
            if($script:modelDownloadCancel -or $clock.Elapsed.TotalMinutes -ge 15){$client.CancelAsync()}
            if(Test-Path -LiteralPath $archive){$size=(Get-Item -LiteralPath $archive).Length;$modelProgress.Value=[Math]::Min(99,[int](100*$size/[double]$spec.bytes));if($size -gt [long]$spec.bytes+1048576){$client.CancelAsync();throw (PText 'text_407')}}
            $modelState.Text="$($modelWords[6]) $($modelProgress.Value)%";[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 50
        }
        if($script:modelDownloadCancel){throw [OperationCanceledException]::new($modelWords[9])}
        $task.GetAwaiter().GetResult()
        $modelCancel.Enabled=$false;$modelState.Text=$modelWords[7];[Windows.Forms.Application]::DoEvents()
        if($script:modelDownloadCancel){throw [OperationCanceledException]::new($modelWords[9])}
        Install-OptionalModelArchive $archive $spec
        $modelProgress.Value=100;Refresh-ModelState;$status.Text=$modelWords[8]
    }catch{
        $modelState.Text=if($script:modelDownloadCancel){$modelWords[9]}else{PText $_.Exception.GetBaseException().Message};$modelProgress.Value=0
    }finally{
        if($client){$client.CancelAsync();$client.Dispose()}
        if(Test-Path -LiteralPath $downloadDir){Remove-Item -LiteralPath $downloadDir -Recurse -Force -ErrorAction SilentlyContinue}
        $script:modelDownloadBusy=$false;$modelDownload.Enabled=$true;$modelChoice.Enabled=$true;$modelRefresh.Enabled=$true;$modelCancel.Enabled=$false
        foreach($page in $tabs.TabPages){$page.Enabled=$true}
    }
})
$form.Add_FormClosing({param($sender,$event) if($script:modelDownloadBusy){$event.Cancel=$true;$script:modelDownloadCancel=$true}})

function Complete-Onboarding([string]$InterfaceLanguage,[string]$CommandLanguage,[string]$VoiceMode="") {
    if($InterfaceLanguage -notin @('pl','en','de','ru')){throw (PText 'text_408')}
    if($CommandLanguage -notin @('pl','en','de','ru')){throw (PText 'text_409')}
    if($VoiceMode -and $VoiceMode -notin @('offline','hybrid','online')){throw (PText 'text_410')}
    $next=$config|ConvertTo-Json -Depth 12|ConvertFrom-Json
    if($VoiceMode){$next.voice_mode=$VoiceMode}
    $next.language=$InterfaceLanguage;$next.speech_language=$CommandLanguage;$next.onboarding_completed=$true
    Save-JsonFile $ConfigFile $next
    $script:config=$next
}
function Show-SetupWizard {
    $wizard=New-Object Windows.Forms.Form;$wizard.Text="Psych0VMod — $((Get-SetupText).setup)";$wizard.Size=New-Object Drawing.Size(720,580);$wizard.StartPosition='CenterParent';$wizard.MinimizeBox=$false;$wizard.MaximizeBox=$false
    $wizard.FormBorderStyle='FixedDialog';$wizard.AutoScaleMode='Dpi'
    $state=[pscustomobject]@{page=0;finished=$false}
    $heading=New-Object Windows.Forms.Label;$heading.Location=New-Object Drawing.Point(20,15);$heading.Size=New-Object Drawing.Size(660,35);$heading.Font=New-Object Drawing.Font('Segoe UI',13);$wizard.Controls.Add($heading)
    $uiChoice=New-Object Windows.Forms.ComboBox;$uiChoice.DropDownStyle='DropDownList';$uiChoice.Location=New-Object Drawing.Point(20,60);$uiChoice.Width=180;@('pl','en','de','ru')|ForEach-Object {[void]$uiChoice.Items.Add($_)};$uiChoice.SelectedItem=[string]$config.language;if($uiChoice.SelectedIndex -lt 0){$uiChoice.SelectedIndex=0};$wizard.Controls.Add($uiChoice)
    $commandChoice=New-Object Windows.Forms.ComboBox;$commandChoice.DropDownStyle='DropDownList';$commandChoice.Location=New-Object Drawing.Point(230,60);$commandChoice.Width=180;@('pl','en','de','ru')|ForEach-Object {[void]$commandChoice.Items.Add($_)};$commandChoice.SelectedItem=[string]$config.speech_language;if($commandChoice.SelectedIndex -lt 0){$commandChoice.SelectedIndex=0};$wizard.Controls.Add($commandChoice)
    $recognitionChoice=New-Object Windows.Forms.ComboBox;$recognitionChoice.FormattingEnabled=$true;$recognitionChoice.Add_Format({param($sender,$eventArgs) $eventArgs.Value=Get-Psych0ModeLabel ([string]$eventArgs.ListItem)});$recognitionChoice.DropDownStyle='DropDownList';$recognitionChoice.Location=New-Object Drawing.Point(20,60);$recognitionChoice.Width=180;@('offline','hybrid','online')|ForEach-Object {[void]$recognitionChoice.Items.Add($_)};$recognitionChoice.SelectedItem=[string]$config.voice_mode;if($recognitionChoice.SelectedIndex -lt 0){$recognitionChoice.SelectedIndex=0};$wizard.Controls.Add($recognitionChoice)
    $uiLabel=New-Object Windows.Forms.Label;$uiLabel.Location=New-Object Drawing.Point(20,95);$uiLabel.Size=New-Object Drawing.Size(190,30);$wizard.Controls.Add($uiLabel)
    $commandLabel=New-Object Windows.Forms.Label;$commandLabel.Location=New-Object Drawing.Point(230,95);$commandLabel.Size=New-Object Drawing.Size(380,30);$wizard.Controls.Add($commandLabel)
    $body=New-Object Windows.Forms.TextBox;$body.Multiline=$true;$body.ReadOnly=$true;$body.ScrollBars='Vertical';$body.Location=New-Object Drawing.Point(20,130);$body.Size=New-Object Drawing.Size(660,335);$body.Font=New-Object Drawing.Font('Segoe UI',11);$wizard.Controls.Add($body)
    $back=New-Object Windows.Forms.Button;$back.Location=New-Object Drawing.Point(20,480);$back.Size=New-Object Drawing.Size(140,35);$wizard.Controls.Add($back)
    $later=New-Object Windows.Forms.Button;$later.Location=New-Object Drawing.Point(190,480);$later.Size=New-Object Drawing.Size(180,35);$wizard.Controls.Add($later)
    $next=New-Object Windows.Forms.Button;$next.Location=New-Object Drawing.Point(490,480);$next.Size=New-Object Drawing.Size(190,35);$wizard.Controls.Add($next)
    $labels=@{
        pl=@('Język okna / język komend','Jak działa rozpoznawanie','Kontrola składników','Wstecz','Później','Dalej','Zakończ','Zmiana języka okna będzie widoczna po ponownym uruchomieniu. Braki nie blokują konfiguracji.');
        en=@('Interface / command language','How recognition works','Component checks','Back','Later','Next','Finish','Restart to apply the interface language. Missing files do not block setup.');
        de=@('Oberfläche / Befehlssprache','Spracherkennung','Komponentenprüfung','Zurück','Später','Weiter','Fertig','Neustart für die Oberflächensprache. Fehlende Dateien blockieren die Einrichtung nicht.');
        ru=@('Язык окна / команд','Распознавание речи','Проверка компонентов','Назад','Позже','Далее','Готово','Для языка окна нужен перезапуск. Отсутствующие файлы не блокируют настройку.')
    }
    $render={
        $lang=[string]$uiChoice.SelectedItem;$l=$labels[$lang];$setupText=Get-SetupText $lang;$wizard.Text="Psych0VMod — $($setupText.setup)";$uiLabel.Text=$(if($state.page -eq 1){$setupText.mode}else{$setupText.ui});$commandLabel.Text=$setupText.command;$uiLabel.Visible=($state.page -lt 2);$commandLabel.Visible=($state.page -eq 0);$recognitionChoice.Visible=($state.page -eq 1)
        $heading.Text="$(1+$state.page)/3 — $($l[$state.page])";$back.Text=$l[3];$later.Text=$l[4];$next.Text=$(if($state.page -eq 2){$l[6]}else{$l[5]});$back.Enabled=($state.page -gt 0)
        $uiChoice.Visible=($state.page -eq 0);$commandChoice.Visible=($state.page -eq 0)
        $body.Text=switch($state.page){0 {"$($l[0])`r`n`r`nPL: amunicja`r`nEN: full ammo`r`n`r`n$($l[7])"};1 {$helpTexts[$lang]};2 {(Get-ComponentCheck ([string]$commandChoice.SelectedItem) $lang ([string]$recognitionChoice.SelectedItem))+"`r`n`r`n"+$l[7]}}
    }
    $uiChoice.Add_SelectedIndexChanged({& $render})
    $back.Add_Click({$state.page--; & $render})
    $wizard.CancelButton=$later;$later.Add_Click({$wizard.Close()})
    $next.Add_Click({
        if($state.page -lt 2){$state.page++; & $render;return}
        try{
            Complete-Onboarding ([string]$uiChoice.SelectedItem) ([string]$commandChoice.SelectedItem) ([string]$recognitionChoice.SelectedItem)
            $langBox.SelectedItem=[string]$config.language;$speechLanguageBox.SelectedItem=[string]$config.speech_language;$modeBox.SelectedItem=[string]$config.voice_mode
            $state.finished=$true;$wizard.Close();$tabs.SelectedTab=$tabConfig;try{Set-Psych0ModLanguage ([string]$config.language)}catch{[void](Show-Psych0Message -Text ((PText 'language_sync_error')) -Caption ('Psych0VMod'))};[void](Show-Psych0Message -Text ((PText 'language_restart')) -Caption ('Psych0VMod'));Restart-Psych0Interface
        }catch{(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))|Out-Null}
    })
    & $render
    try{[void]$wizard.ShowDialog($form)}finally{$wizard.Dispose()}
}
$settingHints=@{
pl=@('Język wypowiadanej frazy, niezależny od języka okna. Amunicja: PL. Full ammo: EN. Komendy w obu językach wymagają obu modeli.','Offline: Vosk i opcjonalne próbki. Online: Internet i własny klucz. Hybrid: lokalnie, a po niepowodzeniu online przy zapisanym kluczu.','Minimalna pewność Vosk. Nie jest to wynik podobieństwa próbki. Wyższy próg może częściej odrzucać komendy.');
en=@('Language of the spoken phrase, separate from interface language. Amunicja: PL. Full ammo: EN. Both languages require both models.','Offline: Vosk and optional profiles. Online: Internet and your key. Hybrid: local first, then online if a key is saved.','Minimum Vosk confidence, not acoustic profile similarity. Higher thresholds may reject more commands.');
de=@('Sprache der gesprochenen Phrase, unabhängig von der Oberfläche. Amunicja: PL. Full ammo: EN. Beide Sprachen benötigen beide Modelle.','Offline: Vosk und optionale Profile. Online: Internet und eigener Schlüssel. Hybrid: zuerst lokal, dann online bei gespeichertem Schlüssel.','Mindestkonfidenz von Vosk, nicht Profilähnlichkeit. Höhere Werte können mehr Befehle ablehnen.');
ru=@('Язык произнесённой фразы не зависит от языка окна. Amunicja: PL. Full ammo: EN. Для двух языков нужны обе модели.','Offline: Vosk и образцы. Online: Интернет и собственный ключ. Hybrid: сначала локально, затем онлайн при наличии ключа.','Минимальная уверенность Vosk, а не сходство образца. Высокий порог может чаще отклонять команды.')
}
$hintLanguage=[string]$config.language;if(!$settingHints.ContainsKey($hintLanguage)){$hintLanguage='en'}
$profileToolTip.SetToolTip($speechLanguageBox,$settingHints[$hintLanguage][0]);$profileToolTip.SetToolTip($macroLanguage,$settingHints[$hintLanguage][0]);$profileToolTip.SetToolTip($modeBox,$settingHints[$hintLanguage][1]);$profileToolTip.SetToolTip($confidence,$settingHints[$hintLanguage][2])

$setupButton=New-Object Windows.Forms.Button;$setupButton.Text=(Get-SetupText).setup;$setupButton.Width=160;$setupButton.Height=35;$setupButton.Add_Click({Show-SetupWizard});if($ReleaseChannel.name -eq 'developer'){$diagnosticButtons.Controls.Add($setupButton)}else{$setupButton.Location=New-Object Drawing.Point(15,540);$tabConfig.Controls.Add($setupButton)}

$manualButton=New-Object Windows.Forms.Button;$manualButton.Text=(Get-SetupText).manual;$manualButton.Width=160;$manualButton.Height=35;$manualButton.Add_Click({
    $manual=Join-Path $AppDir 'INSTRUKCJA.txt'
    if(Test-Path -LiteralPath $manual -PathType Leaf){Start-Process notepad.exe -ArgumentList @("`"$manual`"")}else{$tabs.SelectedTab=$tabInfo}
});$infoButtons.Controls.Add($manualButton);$infoButtons.BringToFront();$contactButtons.BringToFront();$supportButtons.BringToFront()

$profileModule=Join-Path $AppDir 'Psych0VMod-SaveEditor.ps1'
if(Test-Path -LiteralPath $profileModule){
    . $profileModule
    Initialize-SaveEditor $tabs
    $form.Add_FormClosing({param($sender,$eventArgs)
        try{Stop-SaveEditor}catch{$eventArgs.Cancel=$true;(Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))|Out-Null}
    })
    $form.Add_FormClosed({if($script:profileTimer){$script:profileTimer.Dispose()}})
}

$achievementModule=Join-Path $AppDir 'Psych0VMod-Achievements.ps1'
. $achievementModule
Initialize-Achievements $tabs
$form.Add_FormClosing({try{Stop-AchievementRequest}catch{Write-AppLog 'WARN' 'ACHIEVEMENT_CLOSE_CANCEL_FAILED'}})
$form.Add_FormClosed({if($script:achievementTimer){$script:achievementTimer.Stop();$script:achievementTimer.Dispose()}})

. (Join-Path $AppDir 'Psych0VMod-Features.ps1')
. (Join-Path $AppDir 'Psych0VMod-Keybinds.ps1')
Initialize-Features $tabTest
Restore-Psych0LanguageDraft
$form.Add_FormClosing({param($sender,$eventArgs) if(!$eventArgs.Cancel){Stop-FeatureRequest;if($script:keybindPending){Remove-Item -LiteralPath (Join-Path (Mod-Path) 'psych0vmod_keybind_request.json') -Force -ErrorAction SilentlyContinue;$script:keybindPending=$null}}})
$form.Add_FormClosed({if($script:featureTimer){$script:featureTimer.Stop();$script:featureTimer.Dispose()};if($script:featureButtonTips){$script:featureButtonTips.Dispose()}})

# Keep game tools together, then voice tools, maintenance and help.
$orderedTabs=@(
    $tabConfig, $tabTest, $tabs.TabPages['saveEditor'], $tabs.TabPages['achievements'],
    $tabMacros, $tabSamples, $tabModels,
    $tabUpdates, $tabBackups, $tabDiagnostics, $tabInfo
) | Where-Object { $null -ne $_ -and ($ReleaseChannel.name -eq 'developer' -or $_ -ne $tabDiagnostics) }
$selectedTab=$tabs.SelectedTab
$tabs.SuspendLayout()
try {
    $tabs.TabPages.Clear()
    foreach($page in $orderedTabs){[void]$tabs.TabPages.Add($page)}
    if($selectedTab){$tabs.SelectedTab=$selectedTab}
} finally { $tabs.ResumeLayout() }

try{Initialize-MicrophoneRecorder;Initialize-AudioApi}catch{Write-AppLog 'WARN' ('VOICE_PREWARM '+$_.Exception.GetBaseException().Message)}
$script:hotkeyWindow=$null
$script:isListening=$false
try {
    Initialize-HotkeyApi
    $hotkey=Convert-Hotkey ([string]$config.hotkey)
    $script:hotkeyWindow=New-Object -TypeName Psych0VModHotKeyWindow -ArgumentList @($hotkey.modifiers,$hotkey.key)
    $script:hotkeyWindow.add_HotKeyPressed({Start-VoiceRecognition})
    $status.Text="$(T 'ready') — $($config.hotkey)"
} catch {
    $status.Text=(PText 'text_331')
    (Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ((PText 'text_426')))|Out-Null
}

$form.Add_FormClosed({if($script:headerImage){$header.BackgroundImage=$null;$script:headerImage.Dispose();$script:headerImage=$null};if($profileToolTip){$profileToolTip.Dispose()};if($script:hotkeyWindow){$script:hotkeyWindow.Dispose();$script:hotkeyWindow=$null};if($script:singleInstanceMutex){$script:singleInstanceMutex.ReleaseMutex();$script:singleInstanceMutex.Dispose();$script:singleInstanceMutex=$null}})
$form.Add_Shown({
    [void][Psych0WindowVisibility]::ShowWindow($form.Handle,9)
    [void][Psych0WindowVisibility]::SetForegroundWindow($form.Handle)
    Write-AppLog 'INFO' "WINDOW shown PID=$PID nativeVisible=$([Psych0WindowVisibility]::IsWindowVisible($form.Handle))"
    if(!$config.onboarding_completed){Show-SetupWizard}
})

$script:startupStage="window ready"
Write-AppLog "INFO" "START PID=$PID path=$AppDir version=$AppVersion interface=$($config.language) speech=$($config.speech_language) macros=$($script:macros.Count) samples=$($script:samples.Count)"
[void]$form.ShowDialog()
Write-AppLog "INFO" "CLOSE window ended PID=$PID"
} catch {
    $script:processExitCode=1
    $failure=$_
    $errorDir=Join-Path (Get-Psych0DataDirectory) 'logs'
    $errorFile=Join-Path $errorDir "Startup-error.txt"
    $message="Psych0VMod startup error ($script:startupStage)`r`n$($failure.Exception.Message)`r`n$($failure.InvocationInfo.PositionMessage)`r`n$($failure.ScriptStackTrace)"
    try{New-Item -ItemType Directory -Force $errorDir|Out-Null;$message|Set-Content -Encoding UTF8 $errorFile}catch{}
    try{(Show-Psych0Message -Text ((PText 'text_346' @((PText $failure.Exception.GetBaseException().Message),$errorFile))) -Caption ((PText 'text_427')))|Out-Null}catch{Write-Host $message}
    Write-Error -Message $message -ErrorAction Continue
    exit 1
} finally {
    Write-AppLog "INFO" "CLOSE releasing instance PID=$PID"
    if($script:singleInstanceMutex){
        try{$script:singleInstanceMutex.ReleaseMutex()}catch{}
        try{$script:singleInstanceMutex.Dispose()}catch{}
        $script:singleInstanceMutex=$null
    }
    Write-AppLog "INFO" "CLOSE process exit PID=$PID"
    [Environment]::Exit($script:processExitCode)
}
