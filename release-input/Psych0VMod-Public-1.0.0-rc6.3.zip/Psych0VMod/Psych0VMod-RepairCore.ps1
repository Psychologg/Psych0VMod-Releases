﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
function Assert-UpdateArchive([string]$Path,[string]$ExpectedHash) {
    if($ExpectedHash -notmatch '^[a-fA-F0-9]{64}$'){throw (PText 'text_437')}
    if((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $ExpectedHash){throw (PText 'text_268')}
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip=[IO.Compression.ZipFile]::OpenRead($Path)
    try{
        if(!$zip.Entries.Count){throw (PText 'text_382')}
        $seen=@{};$total=[long]0
        foreach($entry in $zip.Entries){
            $name=$entry.FullName.Replace('\','/')
            if($name.StartsWith('/') -or $name.Contains(':') -or @($name.Split('/')|Where-Object {$_ -eq '..'}).Count){throw (PText 'text_383')}
            if($seen.ContainsKey($name)){throw (PText 'text_384')};$seen[$name]=$true
            $total+=$entry.Length;if($total -gt 2147483648){throw (PText 'text_385')}
        }
    }finally{$zip.Dispose()}
}
function Assert-Psych0RelativePath([string]$Name) {
    if(!$Name -or $Name -match '[\\:]' -or $Name.StartsWith('/') -or $Name -match '(^|/)\.{1,2}(/|$)' -or $Name -match '[<>"|?*]' -or $Name -match '[. ]($|/)'){throw (PText 'text_335' @($Name))}
}
function Assert-Psych0Release([string]$Source) {
    $path=Join-Path $Source '.psych0-release.json'
    $release=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    Assert-Psych0ReleaseChannel $release
    if($release.schema -ne 1 -or $release.component -notin @('psych0mod','psych0vmod') -or !$release.version -or !@($release.files).Count){throw (PText 'text_386')}
    $seen=@{}
    foreach($file in $release.files){
        $name=[string]$file.path;Assert-Psych0RelativePath $name
        if($name -eq '.psych0-release.json' -or $seen.ContainsKey($name)){throw (PText 'text_387')};$seen[$name]=$true
        if($file.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw (PText 'text_388')}
        $p=Join-Path $Source $name
        if(!(Test-Path -LiteralPath $p -PathType Leaf) -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne $file.sha256){throw (PText 'text_336' @($name))}
    }
    foreach($file in Get-ChildItem -LiteralPath $Source -Recurse -File -Force){
        $name=$file.FullName.Substring([IO.Path]::GetFullPath($Source).TrimEnd([IO.Path]::DirectorySeparatorChar).Length+1).Replace('\','/')
        if($name -ne '.psych0-release.json' -and !$seen.ContainsKey($name)){throw (PText 'text_337' @($name))}
    }
    return $release
}
function Assert-Psych0GameClosed {
    if(Get-Process -Name 'payday2_win32_release','payday2_win64_release','payday2_win32_release_vr','PAYDAY2' -ErrorAction SilentlyContinue){throw (PText 'text_269')}
}
function Set-TransactionalDirectory([string]$Source,[string]$Target,[bool]$PreserveExisting=$true,[bool]$IsBackup=$false) {
    if(!(Test-Path -LiteralPath $Source -PathType Container)){throw (PText 'text_389')}
    $release=$null
    if(!$IsBackup -and (Test-Path -LiteralPath (Join-Path $Source '.psych0-release.json'))){$release=Assert-Psych0Release $Source}
    $targetFull=[IO.Path]::GetFullPath($Target).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $parent=Split-Path -Parent $targetFull
    $stage=Join-Path $parent ('.Psych0VMod-stage-'+[guid]::NewGuid().ToString('N'))
    $old=Join-Path $parent ('.Psych0VMod-rollback-'+[guid]::NewGuid().ToString('N'))
    $moved=$false;$committed=$false
    New-Item -ItemType Directory -Force $parent|Out-Null
    try{
        foreach($folder in @($Source,$targetFull)){
            if(Test-Path -LiteralPath $folder){
                if((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw (PText 'text_390')}
                if(@(Get-ChildItem -LiteralPath $folder -Recurse -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw (PText 'text_391')}
            }
        }
        New-Item -ItemType Directory $stage|Out-Null
        if($PreserveExisting -and (Test-Path -LiteralPath $targetFull)){Get-ChildItem -LiteralPath $targetFull -Force|Copy-Item -Destination $stage -Recurse -Force}
        if($release -and $PreserveExisting){
            $previousPath=Join-Path $targetFull '.psych0-release.json'
            $previous=@()
            if(Test-Path -LiteralPath $previousPath){
                try{$previousRelease=Get-Content -LiteralPath $previousPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{$previousRelease=$null}
                if(!$previousRelease -or $previousRelease.component -ne $release.component){$previousRelease=[pscustomobject]@{files=@($release.legacy_managed_files|Where-Object {$_}|ForEach-Object {[pscustomobject]@{path=$_}})}}
                $previous=@($previousRelease.files|ForEach-Object {[string]$_.path})
            }else{$previous=@($release.legacy_managed_files|Where-Object {$_})}
            $new=@{};foreach($file in $release.files){$new[[string]$file.path]=$true}
            foreach($name in $previous){
                Assert-Psych0RelativePath $name
                if($name -match '^(models|engines|native|grafiks|graphics|samples|backups|logs)(/|$)' -or $name -in @('config.json','macros.json','presets.json','psych0_config.txt','psych0_presets.json','psych0_autostart_state.json')){continue}
                if(!$new.ContainsKey($name)){
                    $obsolete=Join-Path $stage $name
                    if(Test-Path -LiteralPath $obsolete -PathType Container){throw (PText 'text_392')}
                    if(Test-Path -LiteralPath $obsolete){Remove-Item -LiteralPath $obsolete -Force}
                }
            }
        }
        Get-ChildItem -LiteralPath $Source -Force|Copy-Item -Destination $stage -Recurse -Force
        if(!$IsBackup -and !$PreserveExisting){
            foreach($userFile in @('psych0_config.txt','psych0_presets.json','psych0_presets.json.bak','psych0_autostart_state.json','psych0_autostart_state.json.bak','.psych0-install.json')){
                if(Test-Path -LiteralPath (Join-Path $targetFull $userFile)){Copy-Item -LiteralPath (Join-Path $targetFull $userFile) -Destination (Join-Path $stage $userFile) -Force}
            }
        }
        if($release){
            foreach($file in $release.files){
                if(!$PreserveExisting -and $file.path -eq 'psych0_config.txt'){continue}
                if((Get-FileHash -LiteralPath (Join-Path $stage $file.path) -Algorithm SHA256).Hash -ne $file.sha256){throw (PText 'text_393')}
            }
        }
        if(Test-Path -LiteralPath $targetFull){Move-Item -LiteralPath $targetFull -Destination $old;$moved=$true}
        try{Move-Item -LiteralPath $stage -Destination $targetFull;$committed=$true}
        catch{if($moved){Move-Item -LiteralPath $old -Destination $targetFull};throw}
    }finally{
        if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force}
        if($committed -and (Test-Path -LiteralPath $old)){Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue}
    }
}
function Get-InstalledPsych0ModVersion {
    $mod=Mod-Path
    if(!$mod -or !(Test-Path -LiteralPath (Join-Path $mod 'mod.txt'))){return '0.0.0'}
    return [string](Get-Content -LiteralPath (Join-Path $mod 'mod.txt') -Raw -Encoding UTF8|ConvertFrom-Json).version
}
