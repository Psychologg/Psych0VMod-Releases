﻿param([int]$ParentPid=0,[string]$AppTarget='', [string]$GamePath='')
# ConsoleHost progress rendering cannot use a detached console. GUI owns status.
if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$global:ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
. (Join-Path $PSScriptRoot 'Psych0VMod-RepairCore.ps1')
. (Join-Path $PSScriptRoot 'Psych0VMod-Integrity.ps1')
$root=Join-Path ([IO.Path]::GetTempPath()) ('Psych0VMod-repair-'+[guid]::NewGuid().ToString('N'))
$log=Join-Path (Get-Psych0DataDirectory) 'logs/Repair-last.txt'
New-Item -ItemType Directory -Force (Split-Path -Parent $log)|Out-Null
$mutex=$null;$locked=$false;$restartAllowed=$false
try{
    if($ParentPid){while(Get-Process -Id $ParentPid -ErrorAction SilentlyContinue){Start-Sleep -Milliseconds 250}}
    $mutex=New-Object Threading.Mutex($false,'Local\Psych0VMod')
    try{$locked=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true}
    if(!$locked){throw (PText 'text_243')}
    $restartAllowed=$true
    Assert-Psych0GameClosed
    if(!$AppTarget){$AppTarget=Join-Path $env:LOCALAPPDATA (Get-Psych0Channel).app_folder}
    if(!$GamePath){
        $config=Join-Path (Get-Psych0DataDirectory) 'config.json'
        if(Test-Path $config){$GamePath=[string](Get-Content $config -Raw -Encoding UTF8|ConvertFrom-Json).payday2_path}
    }
    if(!(Test-Psych0GameFolder $GamePath)){
        $picker=New-Object Windows.Forms.FolderBrowserDialog;$picker.Description=(PText 'text_431');if($GamePath -and (Test-Path -LiteralPath $GamePath -PathType Container)){$picker.SelectedPath=$GamePath}
        if($picker.ShowDialog() -ne 'OK'){throw (PText 'text_432')};$GamePath=$picker.SelectedPath;$picker.Dispose()
        if(!(Test-Psych0GameFolder $GamePath)){throw (PText 'text_433')}
    }
    Write-Host (PText 'text_244')
    $manifest=Get-Psych0CloudManifest
    Assert-Psych0ManifestChannel $manifest
    $plan=New-Psych0RepairPlan $manifest $AppTarget (Join-Path $GamePath 'mods/Psych0Mod') $root
    Set-Content -LiteralPath $log -Encoding UTF8 -Value ('START repair PID='+$PID+' parent='+$ParentPid+"`r`n"+($plan.issues -join "`r`n"))
    if(!$plan.issues.Count){[void](Show-Psych0Message -Text ((PText 'text_245')) -Caption ('PsychVMod'));return}
    Write-Host ($plan.issues -join "`r`n")
    $text='Wykryto problemy: '+$plan.issues.Count+(PText 'text_246')
    if($plan.speechNeeded){$text+=(PText 'text_466')}
    if((Show-Psych0Message -Text ($text) -Caption ('PsychVMod') -Buttons ('YesNo')) -ne 'Yes'){return}
    Complete-Psych0RepairSource $plan
    [Environment]::CurrentDirectory=[IO.Path]::GetTempPath();Set-Location ([IO.Path]::GetTempPath())
    Invoke-Psych0RepairCommit $plan
    Add-Content -LiteralPath $log -Encoding UTF8 -Value 'PASS: repaired files verified by SHA-256'
    [void](Show-Psych0Message -Text ((PText 'text_247')) -Caption ('PsychVMod'))
}catch{
    Add-Content -LiteralPath $log -Encoding UTF8 -Value $_.Exception.ToString()
    [void](Show-Psych0Message -Text (((PText $_.Exception.GetBaseException().Message)+"`r`n"+(PText 'log_path')+$log)) -Caption ((PText 'text_248')))
}finally{
    Add-Content -LiteralPath $log -Encoding UTF8 -Value ('CLOSE releasing mutex PID='+$PID)
    try{if($locked){$mutex.ReleaseMutex()}}finally{if($mutex){$mutex.Dispose()}}
    if(Test-Path $root){Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
    if($restartAllowed -and (Test-Path (Join-Path $AppTarget 'Psych0VMod.ps1'))){
        $restart=Join-Path ([IO.Path]::GetTempPath()) ('Psych0VMod-restart-'+[guid]::NewGuid().ToString('N')+'.ps1')
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Psych0VMod-Restart.ps1') -Destination $restart
        Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$restart+'"'),'-ParentPid',$PID,'-AppPath',('"'+(Join-Path $AppTarget 'Psych0VMod.ps1')+'"'))
    }
    Add-Content -LiteralPath $log -Encoding UTF8 -Value ('CLOSE repair process exit PID='+$PID)
    [Environment]::Exit(0)
}
