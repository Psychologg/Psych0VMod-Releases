﻿param([Parameter(Mandatory=$true)][int]$ParentPid,[Parameter(Mandatory=$true)][string]$AppPath)
$ErrorActionPreference='Stop'
try{
    Wait-Process -Id $ParentPid -ErrorAction SilentlyContinue
    Start-Process powershell.exe -WorkingDirectory ([IO.Path]::GetTempPath()) -WindowStyle Normal -ArgumentList @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',('"'+$AppPath+'"'),'-HideConsole')
}finally{Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue}
