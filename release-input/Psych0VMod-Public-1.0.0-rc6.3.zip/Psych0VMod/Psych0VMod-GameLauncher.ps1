﻿$app=Join-Path $PSScriptRoot "Psych0VMod.ps1"
$existing=Get-Process -Name "powershell","pwsh" -ErrorAction SilentlyContinue | Where-Object {
    try {$_.MainWindowTitle -like "Psych0VMod*"} catch {$false}
}

if(!$existing){
    Start-Process powershell.exe -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",("`""+$app+"`""))
    Start-Sleep -Seconds 2
}

Start-Process "steam://rungameid/218620"
