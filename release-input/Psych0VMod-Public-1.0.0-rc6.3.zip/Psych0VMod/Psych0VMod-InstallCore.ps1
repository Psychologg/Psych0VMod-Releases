﻿. (Join-Path $PSScriptRoot 'Psych0VMod-RepairCore.ps1')
. (Join-Path $PSScriptRoot 'Psych0VMod-Integrity.ps1')
function Assert-Psych0InstallIdle {
    Assert-Psych0GameClosed
    $mutex=New-Object Threading.Mutex($false,'Local\Psych0VMod')
    $locked=$false
    try{try{$locked=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true};if(!$locked){throw (PText 'install_busy')}}finally{if($locked){$mutex.ReleaseMutex()};$mutex.Dispose()}
}
function Assert-Psych0OwnedDirectory([string]$Path,[string]$ExpectedKind) {
    $full=[IO.Path]::GetFullPath($Path).TrimEnd([IO.Path]::DirectorySeparatorChar)
    if((Split-Path -Leaf $full) -notlike 'Psych0VMod*' -and !($ExpectedKind -eq 'mod' -and (Split-Path -Leaf $full) -eq 'Psych0Mod')){throw (PText 'install_owned')}
    if(Test-Path -LiteralPath $full){
        if((Get-Item -LiteralPath $full -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw (PText 'install_owned')}
        if(@(Get-ChildItem -LiteralPath $full -Recurse -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw (PText 'install_owned')}
        $releaseFile=Join-Path $full '.psych0-release.json'
        if(!(Test-Path -LiteralPath $releaseFile)){if(@(Get-ChildItem -LiteralPath $full -Force).Count){throw (PText 'install_owned')};return}
        $release=Get-Content -LiteralPath $releaseFile -Raw -Encoding UTF8|ConvertFrom-Json
        if($release.component -ne $(if($ExpectedKind -eq 'app'){'psych0vmod'}else{'psych0mod'})){throw (PText 'install_owned')}
        Assert-Psych0ReleaseChannel $release
    }
}
function Install-Psych0Suite([string]$SourceApp,[string]$SourceMod,[string]$AppTarget,[string]$GamePath) {
    Assert-Psych0InstallIdle
    if(!(Test-Psych0GameFolder $GamePath)){throw (PText 'text_433')}
    $modTarget=Join-Path $GamePath 'mods/Psych0Mod'
    Assert-Psych0OwnedDirectory $AppTarget 'app';Assert-Psych0OwnedDirectory $modTarget 'mod'
    [void](Assert-Psych0Release $SourceApp);[void](Assert-Psych0Release $SourceMod)
    $backup=Join-Path (Get-Psych0DataDirectory) ('install-backups/'+[guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $backup -Force)
    foreach($pair in @(@($AppTarget,'app'),@($modTarget,'mod'))){if(Test-Path -LiteralPath $pair[0]){Copy-Item -LiteralPath $pair[0] -Destination (Join-Path $backup $pair[1]) -Recurse -Force}}
    Assert-Psych0InstallIdle
    # Each directory commit has rollback; the full previous installation remains in install-backups.
    Set-TransactionalDirectory $SourceMod $modTarget $false
    Set-TransactionalDirectory $SourceApp $AppTarget $true
    $receipt=[pscustomobject]@{schema=1;channel=(Get-Psych0Channel).name;app=[IO.Path]::GetFullPath($AppTarget);mod=[IO.Path]::GetFullPath($modTarget);game=[IO.Path]::GetFullPath($GamePath);backup=$backup}
    $receipt|ConvertTo-Json|Set-Content -LiteralPath (Join-Path (Get-Psych0DataDirectory) 'install.json') -Encoding UTF8
    foreach($target in @($AppTarget,$modTarget)){$receipt|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $target '.psych0-install.json') -Encoding UTF8}
    return $receipt
}
function Uninstall-Psych0Suite($Receipt) {
    Assert-Psych0InstallIdle
    if($Receipt.schema -ne 1 -or $Receipt.channel -ne (Get-Psych0Channel).name){throw (PText 'install_owned')}
    $expectedMod=[IO.Path]::GetFullPath((Join-Path $Receipt.game 'mods/Psych0Mod'))
    if([IO.Path]::GetFullPath($Receipt.mod) -ne $expectedMod){throw (PText 'install_owned')}
    $appFull=[IO.Path]::GetFullPath($Receipt.app)
    if($appFull -eq $expectedMod -or $appFull.StartsWith($expectedMod+[IO.Path]::DirectorySeparatorChar) -or $expectedMod.StartsWith($appFull+[IO.Path]::DirectorySeparatorChar)){throw (PText 'install_owned')}
    # Validate both targets before removing any managed files. A changed channel is left alone.
    $targets=@()
    foreach($pair in @(@($appFull,'app'),@($expectedMod,'mod'))){
        if(!(Test-Path -LiteralPath $pair[0])){continue}
        Assert-Psych0OwnedDirectory $pair[0] $pair[1]
        $ledger=Get-Content -LiteralPath (Join-Path $pair[0] '.psych0-release.json') -Raw -Encoding UTF8|ConvertFrom-Json
        foreach($file in $ledger.files){Assert-Psych0RelativePath ([string]$file.path)}
        $targets+=[pscustomobject]@{path=$pair[0];files=$ledger.files}
    }
    $saved=Join-Path (Get-Psych0DataDirectory) ('uninstall-backups/'+[guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $saved -Force)
    foreach($target in $targets){Copy-Item -LiteralPath $target.path -Destination (Join-Path $saved (Split-Path -Leaf $target.path)) -Recurse -Force}
    Assert-Psych0InstallIdle
    foreach($target in $targets){
        foreach($file in $target.files){
            $name=[string]$file.path
            # Preserve all user settings, even when old releases listed a default config file.
            if($name -in @('psych0_config.txt','psych0_presets.json','psych0_autostart_state.json','config.json','macros.json','presets.json') -or $name -match '^(samples|profiles|backups|logs)/'){continue}
            $path=Join-Path $target.path $name
            if(Test-Path -LiteralPath $path -PathType Leaf){Remove-Item -LiteralPath $path -Force}
        }
        foreach($name in @('.psych0-release.json','.psych0-install.json')){Remove-Item -LiteralPath (Join-Path $target.path $name) -Force -ErrorAction SilentlyContinue}
        # Unknown files, saves and user configuration remain. No recursive deletion of game folders.
        Get-ChildItem -LiteralPath $target.path -Directory -Recurse|Sort-Object {$_.FullName.Length} -Descending|ForEach-Object {if(!@(Get-ChildItem -LiteralPath $_.FullName -Force).Count){Remove-Item -LiteralPath $_.FullName}}
        if(!@(Get-ChildItem -LiteralPath $target.path -Force).Count){Remove-Item -LiteralPath $target.path}
    }
    return $saved
}
function Invoke-Psych0Maintenance([scriptblock]$Action) {
    $mutex=New-Object Threading.Mutex($false,'Local\Psych0VMod');$locked=$false
    try{try{$locked=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true};if(!$locked){throw (PText 'install_busy')};Assert-Psych0GameClosed;& $Action}finally{if($locked){$mutex.ReleaseMutex()};$mutex.Dispose()}
}
