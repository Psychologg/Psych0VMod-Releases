﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
function script:Get-Psych0SaveCandidates {
 param([string[]]$SteamRoots=@(),[string]$LocalSaveRoot='', [switch]$OnlyProvidedRoots)
 $roots=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($root in $SteamRoots){if($root){[void]$roots.Add([IO.Path]::GetFullPath($root))}}
 if(!$OnlyProvidedRoots){
  foreach($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')){
   try{$reg=Get-ItemProperty $key -ErrorAction Stop;foreach($p in @($reg.SteamPath,$reg.InstallPath)){if($p){[void]$roots.Add([IO.Path]::GetFullPath($p))}}}catch{}
  }
  foreach($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles)){if($base){[void]$roots.Add((Join-Path $base 'Steam'))}}
  foreach($drive in Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue){if($drive.Root){[void]$roots.Add((Join-Path $drive.Root 'Steam'))}}
  if(!$LocalSaveRoot -and $env:LOCALAPPDATA){$LocalSaveRoot=Join-Path $env:LOCALAPPDATA 'PAYDAY 2/saves'}
 }
 $found=New-Object 'System.Collections.Generic.List[object]'
 $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 function Add-Candidate([string]$Path,[string]$Source,[string]$Account){
  if(!(Test-Path -LiteralPath $Path -PathType Leaf)){return}
  try{$f=Get-Item -LiteralPath $Path -ErrorAction Stop;if($f.Length -le 0 -or !$seen.Add($f.FullName)){return}
   $found.Add([pscustomobject]@{Path=$f.FullName;Source=$Source;Account=$Account;ModifiedUtc=$f.LastWriteTimeUtc;Bytes=$f.Length;Display=('{0} | {1} | {2} | {3}' -f $Source,$Account,$f.LastWriteTime.ToString('yyyy-MM-dd HH:mm'),$f.FullName)})
  }catch{}
 }
 foreach($root in $roots){
  $userdata=Join-Path $root 'userdata'
  foreach($account in Get-ChildItem -LiteralPath $userdata -Directory -ErrorAction SilentlyContinue){
   Add-Candidate (Join-Path $account.FullName '218620/remote/save098.sav') 'Steam' $account.Name
  }
 }
 if($LocalSaveRoot){
  foreach($account in Get-ChildItem -LiteralPath $LocalSaveRoot -Directory -ErrorAction SilentlyContinue){
   Add-Candidate (Join-Path $account.FullName 'save098.sav') 'Local' $account.Name
  }
 }
 $found.ToArray() | Sort-Object ModifiedUtc -Descending
}

function script:Get-Psych0LatestSaveBackup([string]$SavePath){
 $full=[IO.Path]::GetFullPath($SavePath);$folder=Split-Path $full -Parent
 $prefix=[IO.Path]::GetFileName($full)+'.psych0-backup-'
 $backups=@(Get-ChildItem -LiteralPath $folder -File -ErrorAction SilentlyContinue | Where-Object {$_.Name.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -and $_.Extension -eq '.bak'} | Sort-Object LastWriteTimeUtc -Descending)
 if(!$backups.Count){throw (PText 'text_438')}
 $backups[0]
}

function script:Get-Psych0SaveBackups([string]$SavePath){
 $full=[IO.Path]::GetFullPath($SavePath);$folder=Split-Path $full -Parent
 $prefix=[IO.Path]::GetFileName($full)+'.psych0-backup-'
 @(Get-ChildItem -LiteralPath $folder -File -ErrorAction SilentlyContinue | Where-Object {$_.Name.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -and $_.Extension -eq '.bak'} | Sort-Object @{Expression='LastWriteTimeUtc';Descending=$true},@{Expression='Name';Descending=$true} | Select-Object -First 10)
}
function script:Get-Psych0BackupPreview($Current,[byte[]]$Bytes){
 $copy=[Psych0Offline.Save]::new($Bytes)
 if($copy.Owner -ne $Current.Owner){throw (PText 'text_270')}
 $paths=@('MoneyManager/total','MoneyManager/offshore','SkillTreeManager/points','SkillTreeManager/specializations/points','ExperienceManager/level','ExperienceManager/total')
 $rows=@(foreach($path in $paths){
  $before=[decimal]::Parse($Current.Get($path),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture)
  $after=[decimal]::Parse($copy.Get($path),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture)
  [pscustomobject]@{Path=$path;Current=$before;Backup=$after;Difference=($after-$before)}
 })
 [pscustomobject]@{Save=$copy;Rows=$rows;Identical=($copy.OriginalHash -eq $Current.OriginalHash)}
}
