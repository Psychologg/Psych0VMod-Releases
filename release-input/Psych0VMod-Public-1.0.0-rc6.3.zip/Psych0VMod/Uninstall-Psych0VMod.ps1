﻿param([string]$AppTarget='')
. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')
. (Join-Path $PSScriptRoot 'Psych0VMod-InstallCore.ps1')
Add-Type -AssemblyName System.Windows.Forms
$ErrorActionPreference='Stop'
try{
    $receipt=Get-Content -LiteralPath (Join-Path (Get-Psych0DataDirectory) 'install.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if($AppTarget -and [IO.Path]::GetFullPath($AppTarget) -ne [IO.Path]::GetFullPath($receipt.app)){throw (PText 'install_owned')}
    if((Show-Psych0Message -Text (PText 'uninstall_confirm' @((Get-Psych0Channel).name)) -Caption (PText 'uninstall_title') -Buttons 'YesNo' -DefaultButton 'Button2') -ne 'Yes'){return}
    [Environment]::CurrentDirectory=[IO.Path]::GetTempPath();Set-Location ([IO.Path]::GetTempPath())
    [void](Invoke-Psych0Maintenance {Uninstall-Psych0Suite $receipt})
    $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Psych0VMod-'+(Get-Psych0Channel).name
    Remove-Item -LiteralPath $key -Recurse -ErrorAction SilentlyContinue
    $shortcut=Join-Path ([Environment]::GetFolderPath('Desktop')) ('Psych0VMod '+(Get-Psych0Channel).name+'.lnk');Remove-Item -LiteralPath $shortcut -ErrorAction SilentlyContinue
    [void](Show-Psych0Message -Text (PText 'uninstall_done') -Caption (PText 'uninstall_title'))
}catch{[void](Show-Psych0Message -Text $_.Exception.Message -Caption (PText 'uninstall_title') -Icon 'Error')}
