﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
$script:offlineSave=$null;$script:offlinePath='';$script:offlinePending=@{}
function Stop-SaveEditor {$script:offlinePending=@{};$script:offlineSave=$null}
function Initialize-SaveEditor($Tabs){
 . (Join-Path $AppDir 'Psych0VMod-SaveDiscovery.ps1')
 if(!('Psych0Offline.Save' -as [type])){Add-Type -Path (Join-Path $AppDir 'Psych0VMod-OfflineSave.cs')}
 $script:offlineEnglish=($config.language -ne 'pl')
 $script:offlineFields=@('MoneyManager/total','MoneyManager/offshore','SkillTreeManager/points','SkillTreeManager/specializations/points','ExperienceManager/level','ExperienceManager/total')
 $script:offlineLabels=if($script:offlineEnglish){@((PText 'text_271'),(PText 'text_272'),(PText 'text_273'),(PText 'text_274'),(PText 'text_275'),(PText 'text_276'))}else{@((PText 'text_271'),(PText 'text_272'),(PText 'text_273'),(PText 'text_274'),(PText 'text_275'),(PText 'text_276'))}
 function script:OText($PL,$EN){PText $PL}
 $tab=New-Object Windows.Forms.TabPage;$tab.Name='saveEditor';$tab.Text=OText 'Edytor zapisu' 'Save editor';[void]$Tabs.TabPages.Add($tab)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=7;$layout.Padding=New-Object Windows.Forms.Padding(8);$tab.Controls.Add($layout)
 for($row=0;$row -lt 7;$row++){if($row -eq 3){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))}else{$height=@(50,35,40,0,45,80,60)[$row];[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}}
 $info=New-Object Windows.Forms.Label;$info.Dock='Fill';$info.Text=OText 'Edytor pliku — zamknij PAYDAY 2. Program wyszukuje zapisy. Wybierz plik z listy. Zmiany trafiają do pliku dopiero po Zapisz. Poziom i XP są powiązane. Zmiana poziomu ustawia XP na jego początek; zmiana XP wylicza poziom. Skill wymaga poprawki moda.' 'File editor — close PAYDAY 2. The program finds saves. Select a file from the list. Changes reach the file only after Save. Level and XP are linked. Level sets its starting XP; XP calculates level.';$layout.Controls.Add($info,0,0)
 $script:offlinePathBox=New-Object Windows.Forms.TextBox;$script:offlinePathBox.Dock='Fill';$script:offlinePathBox.ReadOnly=$true;$layout.Controls.Add($script:offlinePathBox,0,1)
 $openPanel=New-Object Windows.Forms.FlowLayoutPanel;$openPanel.Dock='Fill';$layout.Controls.Add($openPanel,0,2)
 $open=New-Object Windows.Forms.Button;$open.Width=210;$open.Text=OText 'Wybierz plik zapisu' 'Select save file';$openPanel.Controls.Add($open)
 $find=New-Object Windows.Forms.Button;$find.Width=140;$find.Text=OText 'Znajdź zapisy' 'Find saves';$openPanel.Controls.Add($find)
 $script:offlineCandidates=New-Object Windows.Forms.ComboBox;$script:offlineCandidates.DropDownStyle='DropDownList';$script:offlineCandidates.Width=450;$script:offlineCandidates.DisplayMember='Display';$openPanel.Controls.Add($script:offlineCandidates)
 $script:offlineGrid=New-Object Windows.Forms.ListView;$script:offlineGrid.Dock='Fill';$script:offlineGrid.View='Details';$script:offlineGrid.FullRowSelect=$true;$script:offlineGrid.Font=New-Object Drawing.Font('Segoe UI',11)
 [void]$script:offlineGrid.Columns.Add((OText 'Pole' 'Field'),280);[void]$script:offlineGrid.Columns.Add((OText 'W pliku' 'In file'),200);[void]$script:offlineGrid.Columns.Add((OText 'Oczekująca zmiana' 'Pending change'),200);$layout.Controls.Add($script:offlineGrid,0,3)
 $editPanel=New-Object Windows.Forms.FlowLayoutPanel;$editPanel.Dock='Fill';$layout.Controls.Add($editPanel,0,4)
 $script:offlineChoice=New-Object Windows.Forms.ComboBox;$script:offlineChoice.DropDownStyle='DropDownList';$script:offlineChoice.Width=250;for($i=0;$i -lt 6;$i++){[void]$script:offlineChoice.Items.Add($script:offlineLabels[$i])};$script:offlineChoice.SelectedIndex=0;$editPanel.Controls.Add($script:offlineChoice)
 $script:offlineValue=New-Object Windows.Forms.TextBox;$script:offlineValue.Width=200;$editPanel.Controls.Add($script:offlineValue)
 $stage=New-Object Windows.Forms.Button;$stage.Width=190;$stage.Text=OText 'Przygotuj zmianę' 'Stage change';$editPanel.Controls.Add($stage)
 $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$layout.Controls.Add($buttons,0,5)
 $save=New-Object Windows.Forms.Button;$save.Width=200;$save.Text=OText 'Zapisz do pliku + kopia' 'Save file + backup';$buttons.Controls.Add($save)
 $discard=New-Object Windows.Forms.Button;$discard.Width=180;$discard.Text=OText 'Odrzuć zmiany' 'Discard changes';$buttons.Controls.Add($discard)
 $restore=New-Object Windows.Forms.Button;$restore.Width=190;$restore.Text=OText 'Historia / przywróć' 'History / restore';$buttons.Controls.Add($restore)
 $script:offlineStatus=New-Object Windows.Forms.Label;$script:offlineStatus.Dock='Fill';$layout.Controls.Add($script:offlineStatus,0,6)
 function script:Assert-OfflineGameClosed {
  if(Get-Process -Name 'payday2_win32_release','payday2_win64_release','payday2_win32_release_vr','PAYDAY2' -ErrorAction SilentlyContinue){throw (OText 'Zamknij PAYDAY 2 przed pracą z zapisem.' 'Close PAYDAY 2 before working with the save.')}
 }
 function script:Refresh-OfflineGrid {
  $script:offlineGrid.Items.Clear()
  if(!$script:offlineSave){return}
  for($i=0;$i -lt $script:offlineFields.Count;$i++){
   $path=$script:offlineFields[$i];$value=$script:offlineSave.Get($path)
   $number=0.0;if([double]::TryParse($value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number)){$value=$number.ToString('N0',[Globalization.CultureInfo]::GetCultureInfo($(if($script:offlineEnglish){'en-US'}else{'pl-PL'})))}
   $item=New-Object Windows.Forms.ListViewItem($script:offlineLabels[$i]);[void]$item.SubItems.Add($value);$pending=if($script:offlinePending.ContainsKey($path)){$script:offlinePending[$path]}else{''};[void]$item.SubItems.Add([string]$pending);[void]$script:offlineGrid.Items.Add($item)
  }
 }
 function script:Commit-OfflineFile([byte[]]$Bytes){
  Assert-OfflineGameClosed
  if(!$script:offlineSave){throw (OText 'Najpierw wybierz zapis.' 'Select a save first.')}
  $path=$script:offlinePath;$expected=$script:offlineSave.OriginalHash
  if([Psych0Offline.Save]::Hash([IO.File]::ReadAllBytes($path)) -ne $expected){throw (OText 'Plik zmienił się od odczytu. Wybierz go ponownie.' 'The file changed since opening. Open it again.')}
  $verified=New-Object Psych0Offline.Save(,$Bytes)
  if($verified.Owner -ne $script:offlineSave.Owner){throw (PText 'text_403')}
  $suffix=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N');$temp=$path+'.psych0-'+$suffix+'.tmp';$backup=$path+'.psych0-backup-'+$suffix+'.bak'
  try{
   [IO.File]::WriteAllBytes($temp,$Bytes)
   $check=New-Object Psych0Offline.Save(,[IO.File]::ReadAllBytes($temp))
   Assert-OfflineGameClosed
   if([Psych0Offline.Save]::Hash([IO.File]::ReadAllBytes($path)) -ne $expected){throw (PText 'text_404')}
   [IO.File]::Replace($temp,$path,$backup)
   $script:offlineSave=New-Object Psych0Offline.Save(,[IO.File]::ReadAllBytes($path));$script:offlinePending=@{};Refresh-OfflineGrid
   $script:offlineStatus.Text=(OText 'Zapisano. Kopia całego pliku: ' 'Saved. Full file backup: ')+$backup
  }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}}
 }
 $open.Add_Click({
  try{
   Assert-OfflineGameClosed
   if($script:offlinePending.Count){if((Show-Psych0Message -Text ((OText 'Odrzucić oczekujące zmiany?' 'Discard pending changes?')) -Caption ('Psych0VMod') -Buttons ('YesNo')) -ne 'Yes'){return}}
   $pick=New-Object Windows.Forms.OpenFileDialog
   try{$pick.Filter=(PText 'text_439');$pick.Title=OText 'Wybierz zapis ze Steam lub folderu Local' 'Select the Steam or Local save';if($pick.ShowDialog() -ne 'OK'){return};$chosen=$pick.FileName}finally{$pick.Dispose()}
   Open-OfflineChosenFile $chosen
  }catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}
 })
 $stage.Add_Click({try{Assert-OfflineGameClosed;if(!$script:offlineSave){throw (OText 'Najpierw wybierz zapis.' 'Select a save first.')};$p=$script:offlineFields[$script:offlineChoice.SelectedIndex];$v=$script:offlineValue.Text.Trim();$preview=[Psych0Offline.Save]::new($script:offlineSave.Build($p,$v));$script:offlinePending[$p]=$v;if($p -like 'ExperienceManager/*'){foreach($linked in @('ExperienceManager/level','ExperienceManager/total')){$script:offlinePending[$linked]=$preview.Get($linked)}};Refresh-OfflineGrid;$script:offlineStatus.Text=OText 'Zmiana przygotowana. Kliknij Zapisz lub Odrzuć.' 'Change staged. Click Save or Discard.'}catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}})
 $discard.Add_Click({$script:offlinePending=@{};Refresh-OfflineGrid;Set-OfflineEditValue;$script:offlineStatus.Text=OText 'Odrzucono zmiany. Plik bez zmian.' 'Changes discarded. File unchanged.'})
 $save.Add_Click({try{
  Assert-OfflineGameClosed;if(!$script:offlinePending.Count){return}
  if((Show-Psych0Message -Text ((OText 'Zapisać do wskazanego pliku? Kopia oryginału powstanie obok niego. Steam Cloud może później nadpisać wybrany zapis.' 'Save to the selected file? A backup will be created alongside it. Steam Cloud may later overwrite this save.')) -Caption ('Psych0VMod') -Buttons ('YesNo')) -ne 'Yes'){return}
  $working=$script:offlineSave;$bytes=$working.Unchanged();foreach($p in $script:offlineFields){if($script:offlinePending.ContainsKey($p)){$bytes=$working.Build($p,$script:offlinePending[$p]);$working=New-Object Psych0Offline.Save(,$bytes)}}
  Commit-OfflineFile $bytes
 }catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}})
 $restore.Add_Click({try{
  Assert-OfflineGameClosed;if(!$script:offlineSave){throw (OText 'Wybierz docelowy zapis.' 'Select the target save.')}
  $choice=Select-OfflineBackup
  if(!$choice){return}
  $bytes=[IO.File]::ReadAllBytes($choice.Path)
  if([Psych0Offline.Save]::Hash($bytes) -ne $choice.Hash){throw (OText 'Kopia zmieniła się od podglądu. Otwórz historię ponownie.' 'Backup changed since preview. Open history again.')}
  if((Show-Psych0Message -Text (((OText 'Przywrócić wybraną kopię całego zapisu? Cofnie to także ekwipunek i postęp misji. Obecny stan otrzyma kopię, a oczekujące zmiany zostaną odrzucone.' 'Restore the selected full save? Inventory and mission progress will also revert. Current state will be backed up and pending changes discarded.')+"`r`n"+$choice.Path)) -Caption ('Psych0VMod') -Buttons ('YesNo')) -eq 'Yes'){Commit-OfflineFile $bytes;Set-OfflineEditValue}
 }catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}})

 function script:Select-OfflineBackup {
  $copies=@(Get-Psych0SaveBackups $script:offlinePath)
  if(!$copies.Count){throw (OText 'Brak kopii tego zapisu.' 'No backups for this save.')}
  $dialog=New-Object Windows.Forms.Form;$dialog.Text=OText '10 ostatnich kopii — wybierz stan do przywrócenia' 'Last 10 backups — select a state to restore';$dialog.Size=New-Object Drawing.Size(850,520);$dialog.StartPosition='CenterParent';$dialog.MinimumSize=$dialog.Size
  $icon=Join-Path $AppDir 'Psych0VMod.ico';if(Test-Path $icon){$dialog.Icon=New-Object Drawing.Icon($icon)}
  $panel=New-Object Windows.Forms.TableLayoutPanel;$panel.Dock='Fill';$panel.RowCount=5;$panel.ColumnCount=1;$panel.Padding=New-Object Windows.Forms.Padding(10);$dialog.Controls.Add($panel)
  foreach($height in @(35,65,0,60,45)){if($height){[void]$panel.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}else{[void]$panel.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))}}
  $pick=New-Object Windows.Forms.ComboBox;$pick.Dock='Fill';$pick.DropDownStyle='DropDownList';$pick.DisplayMember='Display';$panel.Controls.Add($pick,0,0)
  foreach($file in $copies){[void]$pick.Items.Add([pscustomobject]@{Path=$file.FullName;Display=($file.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')+' | '+$file.Name)})}
  $pathLabel=New-Object Windows.Forms.TextBox;$pathLabel.Multiline=$true;$pathLabel.ReadOnly=$true;$pathLabel.Dock='Fill';$panel.Controls.Add($pathLabel,0,1)
  $grid=New-Object Windows.Forms.ListView;$grid.Dock='Fill';$grid.View='Details';$grid.FullRowSelect=$true;$grid.Font=New-Object Drawing.Font('Segoe UI',11)
  [void]$grid.Columns.Add((OText 'Pole' 'Field'),245);[void]$grid.Columns.Add((OText 'Obecny zapis' 'Current save'),185);[void]$grid.Columns.Add((OText 'Wybrana kopia' 'Selected backup'),185);[void]$grid.Columns.Add((OText 'Różnica' 'Difference'),160);$panel.Controls.Add($grid,0,2)
  $note=New-Object Windows.Forms.Label;$note.Dock='Fill';$panel.Controls.Add($note,0,3)
  $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$panel.Controls.Add($buttons,0,4)
  $apply=New-Object Windows.Forms.Button;$apply.Width=220;$apply.Text=OText 'Przywróć wybraną kopię' 'Restore selected backup';$apply.Enabled=$false;$buttons.Controls.Add($apply)
  $cancel=New-Object Windows.Forms.Button;$cancel.Width=150;$cancel.Text=OText 'Anuluj' 'Cancel';$cancel.DialogResult='Cancel';$buttons.Controls.Add($cancel);$dialog.CancelButton=$cancel
  $pick.Add_SelectedIndexChanged({
   $apply.Enabled=$false;$dialog.Tag=$null;$grid.Items.Clear()
   try{
    $path=$pick.SelectedItem.Path;$pathLabel.Text=$path
    $bytes=[IO.File]::ReadAllBytes($path);$preview=Get-Psych0BackupPreview $script:offlineSave $bytes
    $culture=[Globalization.CultureInfo]::GetCultureInfo($(if($script:offlineEnglish){'en-US'}else{'pl-PL'}))
    for($i=0;$i -lt $preview.Rows.Count;$i++){$row=$preview.Rows[$i];$item=New-Object Windows.Forms.ListViewItem($script:offlineLabels[$i]);foreach($value in @($row.Current,$row.Backup,$row.Difference)){[void]$item.SubItems.Add($value.ToString('N0',$culture))};if($row.Difference -ne 0){$item.ForeColor=[Drawing.Color]::DarkRed};[void]$grid.Items.Add($item)}
    $dialog.Tag=[pscustomobject]@{Path=$path;Hash=$preview.Save.OriginalHash}
    if($preview.Identical){$note.Text=OText 'Ta kopia jest identyczna z obecnym plikiem. Wybierz inną.' 'This backup is identical to the current file. Choose another.'}
    else{$note.Text=OText 'Przywracany jest cały zapis, także ekwipunek i postęp misji. W tabeli pokazano sześć pól; inne dane mogą się różnić. Obecny stan otrzyma kopię.' 'Restores the entire save, including inventory and mission progress. Table shows six fields; other data may differ. Current state will be backed up.';$apply.Enabled=$true}
   }catch{$note.Text=PText $_.Exception.GetBaseException().Message}
  })
  $apply.Add_Click({if($dialog.Tag){$dialog.DialogResult='OK';$dialog.Close()}})
  try{$pick.SelectedIndex=0;if($dialog.ShowDialog() -eq 'OK'){return $dialog.Tag}}finally{$dialog.Dispose()}
  return $null
 }

 function script:Open-OfflineChosenFile([string]$chosen){
  Assert-OfflineGameClosed
  if($script:offlinePending.Count){if((Show-Psych0Message -Text ((OText 'Odrzucić oczekujące zmiany?' 'Discard pending changes?')) -Caption ('Psych0VMod') -Buttons ('YesNo')) -ne 'Yes'){return}}
   $loaded=New-Object Psych0Offline.Save(,[IO.File]::ReadAllBytes($chosen))
   foreach($p in $script:offlineFields){[void]$loaded.Get($p)}
   $script:offlineSave=$loaded;$script:offlinePath=$chosen;$script:offlinePathBox.Text=$chosen;$script:offlinePending=@{};Refresh-OfflineGrid
   $script:offlineStatus.Text=(OText 'Odczytano plik. Maksimum wolnych punktów perków: ' 'File loaded. Maximum unused perk points: ')+$loaded.PerkMaximum();Set-OfflineEditValue
 }
 function script:Set-OfflineEditValue {
  if(!$script:offlineSave){return}
  $p=$script:offlineFields[$script:offlineChoice.SelectedIndex]
  if($script:offlinePending.ContainsKey($p)){$value=$script:offlinePending[$p]}else{$value=$script:offlineSave.Get($p)}
  $number=[decimal]::Parse($value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture)
  $script:offlineValue.Text=$number.ToString('0',[Globalization.CultureInfo]::InvariantCulture)
 }
 $script:offlineChoice.Add_SelectedIndexChanged({try{Set-OfflineEditValue}catch{}})
 $script:offlineGrid.Add_SelectedIndexChanged({if($script:offlineGrid.SelectedIndices.Count){$i=$script:offlineGrid.SelectedIndices[0];if($i -lt 6){$script:offlineChoice.SelectedIndex=$i;Set-OfflineEditValue}}})
 function script:Find-OfflineSaves {
  $script:offlineCandidates.Items.Clear()
  $candidates=@(Get-Psych0SaveCandidates)
  foreach($candidate in $candidates){[void]$script:offlineCandidates.Items.Add($candidate)}
  $script:offlineCandidates.SelectedIndex=-1
  if(!$candidates.Count){$script:offlineStatus.Text=OText 'Nie znaleziono zapisu. Użyj Wybierz plik zapisu.' 'No saves found. Use Select save file.'}
  elseif($candidates.Count -eq 1){$script:offlineCandidates.SelectedIndex=0}
  else{$script:offlineStatus.Text=(OText 'Znaleziono kilka zapisów — wybierz z listy Steam lub Local. Najnowszy jest pierwszy; żaden nie został wybrany automatycznie.' 'Multiple saves found — choose Steam or Local from the list. Newest is first; none was selected automatically.')}
 }
 $find.Add_Click({try{Find-OfflineSaves}catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}})
 $script:offlineCandidates.Add_SelectedIndexChanged({
  if($script:offlineCandidates.SelectedIndex -lt 0){return}
  try{Open-OfflineChosenFile $script:offlineCandidates.SelectedItem.Path}catch{[void](Show-Psych0Message -Text ((PText $_.Exception.GetBaseException().Message)) -Caption ('Psych0VMod'))}
 })
 try{Find-OfflineSaves}catch{$script:offlineStatus.Text=PText $_.Exception.GetBaseException().Message}
}
