﻿if(!(Get-Command PText -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Psych0VMod-Localization.ps1')}
# Recognition decisions are separate from microphone capture and game execution.
function Get-Psych0VoiceMatch($Results) {
    $matches=@()
    foreach($result in @($Results)){
        if(!$result -or ([double]::IsNaN([double]$result.confidence) -or [double]::IsInfinity([double]$result.confidence))){continue}
        if([double]$result.confidence -lt [double]$config.minimum_confidence -or [double]$result.confidence -gt 1){continue}
        $text=Normalize-Phrase ([string]$result.text)
        foreach($macro in @($script:macros|Where-Object {$_.language -eq $result.language -and $_.phrase -eq $text})){
            $matches+=[pscustomobject]@{macro=$macro;result=$result}
        }
    }
    if(@($matches|ForEach-Object {$_.macro.action}|Select-Object -Unique).Count -gt 1){return [pscustomobject]@{ambiguous=$true;macro=$null;result=$null}}
    $best=$matches|Sort-Object {$_.result.confidence} -Descending|Select-Object -First 1
    $reported=if($best){$best.result}else{@($Results)|Where-Object {$_}|Sort-Object confidence -Descending|Select-Object -First 1}
    return [pscustomobject]@{ambiguous=$false;macro=$best.macro;result=$reported}
}
function Invoke-MultilingualVosk([string]$Path) {
    $results=@();$missing=@()
    foreach($lang in @($script:macros|ForEach-Object {$_.language}|Select-Object -Unique)){
        if(!(Test-VoskReady $lang)){$missing+=$lang;continue}
        try{
            $result=Invoke-LocalSpeech $Path $lang
            if($result){$results+=$result;$script:voiceReport+="Vosk [$lang]: '$($result.text)', $([Math]::Round($result.confidence*100))%"}
            else{$script:voiceReport+=PText 'voice_empty' @($lang)}
        }catch{$missing+=$lang;Write-AppLog 'WARN' "VOICE_LOCAL_UNAVAILABLE language=$lang"}
    }
    if($missing.Count){$script:voiceReport+=(PText 'text_344' @($($missing -join ', ')))}
    $match=Get-Psych0VoiceMatch $results
    $match|Add-Member -NotePropertyName unavailable -NotePropertyValue $missing
    return $match
}
function New-Psych0CloudRequest([string]$Path) {
    $cultures=@{pl='pl-PL';en='en-US';de='de-DE';ru='ru-RU'}
    $languages=@($script:macros|ForEach-Object {[string]$_.language}|Select-Object -Unique)
    $primary=if([string]$config.speech_language -in $languages){[string]$config.speech_language}else{$languages[0]}
    if(!$cultures.ContainsKey($primary)){throw (PText 'text_279')}
    $alternatives=@($languages|Where-Object {$_ -ne $primary}|ForEach-Object {$cultures[$_]})
    if($alternatives.Count -gt 3 -or @($alternatives|Where-Object {!$_}).Count){throw (PText 'text_280')}
    $recognition=@{encoding='LINEAR16';sampleRateHertz=16000;audioChannelCount=1;languageCode=$cultures[$primary];maxAlternatives=1;enableWordConfidence=$true;speechContexts=@(@{phrases=@($script:macros|ForEach-Object {[string]$_.phrase}|Select-Object -Unique);boost=20})}
    if($alternatives.Count){$recognition.alternativeLanguageCodes=$alternatives}
    return @{config=$recognition;audio=@{content=[Convert]::ToBase64String([IO.File]::ReadAllBytes($Path))}}
}
function Convert-Psych0CloudResponse($Response,[string]$DefaultCulture) {
    $texts=@();$scores=@();$languages=@()
    foreach($segment in @($Response.results)){
        if(!$segment){continue}
        $alternative=@($segment.alternatives)|Select-Object -First 1
        if(!$alternative -or !$alternative.transcript){continue}
        $texts+=[string]$alternative.transcript
        $culture=if($segment.languageCode){[string]$segment.languageCode}else{$DefaultCulture}
        $languages+=$culture.Split('-')[0].ToLowerInvariant()
        $words=@($alternative.words)
        if($words.Count -and $words[0]){
            foreach($word in $words){$scores+=if($word.PSObject.Properties['confidence']){[double]$word.confidence}else{0.0}}
        }else{$scores+=if($alternative.PSObject.Properties['confidence']){[double]$alternative.confidence}else{0.0}}
    }
    if(!$texts.Count){return $null}
    $unique=@($languages|Select-Object -Unique)
    if($unique.Count -ne 1){return [pscustomobject]@{text='';confidence=0;language='';ambiguous=$true;engine='Google'}}
    return [pscustomobject]@{text=(Normalize-Phrase ($texts -join ' '));confidence=[double](($scores|Measure-Object -Minimum).Minimum);language=$unique[0];ambiguous=$false;engine='Google'}
}
function Invoke-GoogleSpeech([string]$Path) {
    $key=Unprotect-Secret ([string]$config.google_api_key_encrypted)
    if(!$key){throw (PText 'text_281')}
    $request=New-Psych0CloudRequest $Path
    $body=$request|ConvertTo-Json -Depth 8 -Compress
    try{
        $response=Invoke-RestMethod -UseBasicParsing -Method Post -ContentType 'application/json; charset=utf-8' -Uri ('https://speech.googleapis.com/v1/speech:recognize?key='+[Uri]::EscapeDataString($key)) -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 20
    }catch{
        # Do not include the request URI/key in persisted errors.
        throw (PText 'text_282')
    }
    return (Convert-Psych0CloudResponse $response ([string]$request.config.languageCode))
}
function Resolve-Psych0VoiceCommand([string]$Path,[bool]$TestOnly=$false) {
    $mode=[string]$config.voice_mode
    if($mode -notin @('offline','online','hybrid')){throw (PText 'text_440')}
    $hasCloud=($mode -ne 'offline' -and [bool](Unprotect-Secret ([string]$config.google_api_key_encrypted)))
    if($mode -eq 'online' -and !$hasCloud){throw (PText 'text_283')}
    # One input gate for every route: silence cannot reach cloud or the game.
    Initialize-VoiceProfiles
    try{[void][Psych0VoiceProfile]::Extract($Path)}catch{
        $script:voiceReport+=(PText 'text_284')+(PText $_.Exception.GetBaseException().Message)
        return [pscustomobject]@{macro=$null;source='';detail='';reason='input';result=$null}
    }
    $last=$null;$unavailable=@();$profileDisabled=$false
    if($mode -ne 'online'){
        $local=Invoke-MultilingualVosk $Path;$last=$local.result;$unavailable=@($local.unavailable)
        if($local.ambiguous){return [pscustomobject]@{macro=$null;source='';detail='';reason='ambiguous';result=$null}}
        if($local.macro){return [pscustomobject]@{macro=$local.macro;source='Vosk';detail=('Vosk '+[Math]::Round($local.result.confidence*100)+'%');reason='matched';result=$local.result}}
        $candidate=$null
        try{$candidate=Find-VoiceProfile $Path}catch{$script:voiceReport+=(PText 'text_310');Write-AppLog 'WARN' 'VOICE_PROFILE_UNAVAILABLE'}
        if($candidate){
            if($TestOnly -or $config.profile_actions_enabled){return [pscustomobject]@{macro=$candidate.macro;source='Profile';detail=((PText 'text_285')+[Math]::Round($candidate.distance,3)+(PText ', limit ')+[Math]::Round($candidate.limit,3));reason='matched';result=$null}}
            $profileDisabled=$true;$script:voiceReport+=(PText 'text_286')
        }
    }
    if($hasCloud){
        $cloud=Invoke-GoogleSpeech $Path;$last=$cloud
        if($cloud -and $cloud.ambiguous){return [pscustomobject]@{macro=$null;source='Google';detail='';reason='ambiguous';result=$cloud}}
        $match=Get-Psych0VoiceMatch @($cloud)
        if($match.ambiguous){return [pscustomobject]@{macro=$null;source='Google';detail='';reason='ambiguous';result=$cloud}}
        if($match.macro){return [pscustomobject]@{macro=$match.macro;source='Google';detail=('Google '+[Math]::Round($cloud.confidence*100)+'%');reason='matched';result=$cloud}}
    }elseif($mode -eq 'hybrid'){$script:voiceReport+=(PText 'text_287')}
    $reason=if($profileDisabled){'profile-disabled'}elseif($unavailable.Count){'models'}else{'unrecognized'}
    return [pscustomobject]@{macro=$null;source='';detail='';reason=$reason;result=$last}
}
function Set-Psych0VoiceMacro([string]$Phrase,[string]$Language,[string]$Action,[string]$SelectedId='') {
    $normalized=Normalize-Phrase $Phrase
    if(!$normalized -or $Language -notin @('pl','en','de','ru')){throw (PText 'text_288')}
    $existing=if($SelectedId){@($script:macros|Where-Object {$_.id -eq $SelectedId})|Select-Object -First 1}else{@($script:macros|Where-Object {$_.phrase -eq $normalized -and $_.language -eq $Language})|Select-Object -First 1}
    $id=if($existing){[string]$existing.id}else{[guid]::NewGuid().ToString('N')}
    return @($script:macros|Where-Object {$_.id -ne $id -and !($_.phrase -eq $normalized -and $_.language -eq $Language)})+[pscustomobject]@{id=$id;phrase=$normalized;action=$Action;language=$Language}
}
