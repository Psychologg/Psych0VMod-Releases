﻿function Get-Psych0Channel {
    $path=Join-Path $PSScriptRoot 'channel.json'
    if(!(Test-Path -LiteralPath $path)){return [pscustomobject]@{name='developer';manifest_id='1siJGFDrQpbwuaUtwDPt6qkvlfDCDLmT3';data_folder='Psych0VMod';app_folder='Psych0VMod-Developer'}}
    $c=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    if($c.name -notin @('public','developer') -or $c.manifest_id -notmatch '^[a-zA-Z0-9_-]+$' -or $c.data_folder -notin @('Psych0VMod','Psych0VMod-Public') -or $c.app_folder -notin @('Psych0VMod-Developer','Psych0VMod-Public')){throw 'Invalid release channel configuration'}
    if(($c.name -eq 'public' -and $c.data_folder -ne 'Psych0VMod-Public') -or ($c.name -eq 'developer' -and $c.data_folder -ne 'Psych0VMod')){throw 'Invalid channel data directory'}
    if($c.manifest_url){
        $expected=@(('https://psych0vmod-downloads.alight-flute-0599.chatgpt.site/'+$c.name+'/manifest.json'),('https://raw.githubusercontent.com/Psychologg/Psych0VMod-Releases/main/channels/'+$c.name+'.json'))
        if($c.name -eq 'developer'){$expected+=('https://api.github.com/repos/Psychologg/Psych0VMod-Source/contents/channels/developer.json?ref=main')}
        if([string]$c.manifest_url -cnotin $expected){throw 'Invalid release manifest address'}
    }
    return $c
}
function Get-Psych0DataDirectory { return (Join-Path $env:APPDATA (Get-Psych0Channel).data_folder) }
function Assert-Psych0ManifestChannel($Manifest) {
    $c=Get-Psych0Channel
    if($Manifest.channel -ne $c.name -or $Manifest.ready -ne $true){throw (PText 'channel_mismatch')}
}
function Assert-Psych0ReleaseChannel($Release) {
    if(!$Release.channel -and (Get-Psych0Channel).name -eq 'developer'){return} # Legacy developer migration only.
    if($Release.channel -ne (Get-Psych0Channel).name){throw (PText 'channel_mismatch')}
}

function Get-Psych0ManifestUrl {
    $c=Get-Psych0Channel
    if($c.manifest_url){return [string]$c.manifest_url}
    return ('https://drive.google.com/uc?export=download&id='+$c.manifest_id)
}
function Get-Psych0ComponentUrls($Component) {
    $urls=@()
    if($Component.private_release_tag){
        if((Get-Psych0Channel).name -ne 'developer' -or $Component.private_release_tag -cnotmatch '^developer-v[0-9A-Za-z._-]+$' -or $Component.file -cnotmatch '^[A-Za-z0-9._-]+$' -or (Get-Psych0ManifestUrl) -cne 'https://api.github.com/repos/Psychologg/Psych0VMod-Source/contents/channels/developer.json?ref=main'){throw (PText 'text_266')}
        $release=Invoke-RestMethod -UseBasicParsing -Uri ('https://api.github.com/repos/Psychologg/Psych0VMod-Source/releases/tags/'+$Component.private_release_tag) -Headers (Get-Psych0GithubHeaders) -TimeoutSec 60
        $assets=@($release.assets|Where-Object {$_.name -ceq $Component.file})
        if($release.draft -or $assets.Count -ne 1 -or $assets[0].url -cnotmatch '^https://api\.github\.com/repos/Psychologg/Psych0VMod-Source/releases/assets/[0-9]+$'){throw (PText 'text_266')}
        return [string]$assets[0].url
    }
    if($Component.download_urls){$urls=@($Component.download_urls)}elseif($Component.url){$urls=@([string]$Component.url)}
    if($urls.Count){
        $origin=[Uri](Get-Psych0ManifestUrl)
        foreach($value in $urls){
            $uri=$null
            if(![Uri]::TryCreate([string]$value,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.Port -ne 443 -or $uri.UserInfo -or $uri.Fragment){throw (PText 'text_266')}
            if($origin.Host -cin @('raw.githubusercontent.com','api.github.com')){
                if($uri.Host -cne 'github.com' -or $uri.AbsolutePath -cnotmatch '^/Psychologg/Psych0VMod-Releases/releases/download/[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$' -or $uri.Query){throw (PText 'text_266')}
            }elseif($uri.Host -cne $origin.Host){throw (PText 'text_266')}
        }
        if($urls.Count -gt 32){throw (PText 'text_266')}
        return $urls
    }
    if([string]$Component.drive_file_id -notmatch '^[a-zA-Z0-9_-]+$'){throw (PText 'text_266')}
    return ('https://drive.usercontent.google.com/download?export=download&confirm=t&id='+$Component.drive_file_id)
}
function Save-Psych0ComponentArchive($Component,[string]$Destination) {
    $downloadAddresses=@(Get-Psych0ComponentUrls $Component)
    $part=$Destination+'.part';$stream=$null;$success=$false
    try{
        $stream=[IO.File]::Open($Destination,[IO.FileMode]::Create,[IO.FileAccess]::Write)
        foreach($downloadAddress in $downloadAddresses){
            if(([Uri]$downloadAddress).Host -ceq 'api.github.com'){
                if([string]$downloadAddress -cnotmatch '^https://api\.github\.com/repos/Psychologg/Psych0VMod-Source/releases/assets/[0-9]+$'){throw (PText 'text_266')}
                Invoke-WebRequest -UseBasicParsing -Uri ([string]$downloadAddress) -Headers (Get-Psych0GithubHeaders -Binary) -OutFile $part -TimeoutSec 600
            }else{Invoke-WebRequest -UseBasicParsing -Uri ([string]$downloadAddress) -OutFile $part -TimeoutSec 600}
            $inputStream=[IO.File]::OpenRead($part)
            try{$inputStream.CopyTo($stream)}finally{$inputStream.Dispose()}
            Remove-Item -LiteralPath $part -Force
        }
        $stream.Dispose();$stream=$null
        if([string]$Component.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash -ne $Component.sha256){throw (PText 'text_268')}
        $success=$true
    }finally{
        if($stream){$stream.Dispose()}
        if(Test-Path -LiteralPath $part){Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue}
        if(!$success -and (Test-Path -LiteralPath $Destination)){Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue}
    }
}

function Get-Psych0GithubCredentialPath {return (Join-Path (Get-Psych0DataDirectory) 'github-access.dpapi')}
function Save-Psych0GithubCredential([string]$Token) {
    Add-Type -AssemblyName System.Security
    $path=Get-Psych0GithubCredentialPath
    [void][IO.Directory]::CreateDirectory((Split-Path $path))
    $bytes=[Text.Encoding]::UTF8.GetBytes($Token)
    try{[IO.File]::WriteAllBytes($path,[Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))}finally{[Array]::Clear($bytes,0,$bytes.Length)}
    $script:Psych0GithubToken=$Token
}
function Clear-Psych0GithubCredential {
    $script:Psych0GithubToken=$null
    $path=Get-Psych0GithubCredentialPath
    if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}
}
function Get-Psych0GithubToken {
    if($script:Psych0GithubToken){return $script:Psych0GithubToken}
    $path=Get-Psych0GithubCredentialPath
    if(Test-Path -LiteralPath $path){
        Add-Type -AssemblyName System.Security
        try{
            $bytes=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
            try{$script:Psych0GithubToken=[Text.Encoding]::UTF8.GetString($bytes)}finally{[Array]::Clear($bytes,0,$bytes.Length)}
            return $script:Psych0GithubToken
        }catch{Clear-Psych0GithubCredential}
    }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $dialog=New-Object Windows.Forms.Form;$dialog.Text=PText 'github_auth_title';$dialog.Size=New-Object Drawing.Size(680,390);$dialog.StartPosition='CenterScreen';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
    $help=New-Object Windows.Forms.Label;$help.Text=PText 'github_auth_help';$help.Location=New-Object Drawing.Point(20,15);$help.Size=New-Object Drawing.Size(620,185);$dialog.Controls.Add($help)
    $open=New-Object Windows.Forms.Button;$open.Text=PText 'github_auth_open';$open.Location=New-Object Drawing.Point(20,205);$open.Size=New-Object Drawing.Size(620,32);$dialog.Controls.Add($open)
    $open.Add_Click({Start-Process 'https://github.com/settings/personal-access-tokens/new'})
    $input=New-Object Windows.Forms.TextBox;$input.UseSystemPasswordChar=$true;$input.Location=New-Object Drawing.Point(20,250);$input.Width=620;$dialog.Controls.Add($input)
    $save=New-Object Windows.Forms.Button;$save.Text=PText 'github_auth_save';$save.Location=New-Object Drawing.Point(330,295);$save.Width=150;$dialog.Controls.Add($save)
    $cancel=New-Object Windows.Forms.Button;$cancel.Text=PText 'github_auth_cancel';$cancel.Location=New-Object Drawing.Point(490,295);$cancel.Width=150;$cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel;$dialog.AcceptButton=$save
    $save.Add_Click({
        $token=$input.Text.Trim()
        if($token -notmatch '^[A-Za-z0-9_]{20,255}$'){[void][Windows.Forms.MessageBox]::Show((PText 'github_auth_invalid'),(PText 'github_auth_title'));return}
        try{
            [void](Invoke-RestMethod -UseBasicParsing -Uri 'https://api.github.com/repos/Psychologg/Psych0VMod-Source' -Headers @{Authorization=('Bearer '+$token);Accept='application/vnd.github+json'} -TimeoutSec 30)
            Save-Psych0GithubCredential $token
            $input.Clear();$dialog.DialogResult='OK';$dialog.Close()
        }catch{[void][Windows.Forms.MessageBox]::Show((PText 'github_auth_invalid'),(PText 'github_auth_title'))}
    })
    try{if($dialog.ShowDialog() -ne 'OK'){throw (PText 'github_auth_cancelled')}}finally{$input.Clear();$dialog.Dispose()}
    return $script:Psych0GithubToken
}
function Get-Psych0GithubHeaders([switch]$Binary) {
    return @{Authorization=('Bearer '+(Get-Psych0GithubToken));Accept=$(if($Binary){'application/octet-stream'}else{'application/vnd.github+json'})}
}
function Get-Psych0CloudManifest {
    $url=Get-Psych0ManifestUrl
    if($url -ceq 'https://api.github.com/repos/Psychologg/Psych0VMod-Source/contents/channels/developer.json?ref=main'){
        $response=Invoke-RestMethod -UseBasicParsing -Uri $url -Headers (Get-Psych0GithubHeaders) -TimeoutSec 60
        if($response.encoding -ne 'base64' -or !$response.content){throw (PText 'text_266')}
        return ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($response.content))|ConvertFrom-Json)
    }
    return (Invoke-RestMethod -UseBasicParsing -Uri $url -TimeoutSec 60)
}
