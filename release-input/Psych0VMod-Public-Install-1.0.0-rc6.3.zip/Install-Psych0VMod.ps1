﻿param([string]$GamePath='', [ValidateSet('pl','en','de','ru')][string]$Language='pl')
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$bootstrap=Join-Path $PSScriptRoot 'Psych0VMod'
. (Join-Path $bootstrap 'Psych0VMod-Localization.ps1')
$config=[pscustomobject]@{language=$Language}
. (Join-Path $bootstrap 'Psych0VMod-InstallCore.ps1')
Add-Type -AssemblyName System.Windows.Forms
$c=Get-Psych0Channel
$appTarget=Join-Path $env:LOCALAPPDATA $c.app_folder
$work=Join-Path ([IO.Path]::GetTempPath()) ('Psych0VMod-install-'+[guid]::NewGuid().ToString('N'))
try{
    # Reuse an existing channel installation, including a migrated developer install outside the default folder.
    $record=Join-Path (Get-Psych0DataDirectory) 'install.json'
    if(Test-Path $record){$old=Get-Content $record -Raw -Encoding UTF8|ConvertFrom-Json;if($old.channel -eq $c.name){$appTarget=[string]$old.app;if(!$GamePath){$GamePath=[string]$old.game}}}
    if(!$GamePath){$settings=Join-Path (Get-Psych0DataDirectory) 'config.json';if(Test-Path $settings){$GamePath=[string](Get-Content $settings -Raw -Encoding UTF8|ConvertFrom-Json).payday2_path}}
    if(!(Test-Psych0GameFolder $GamePath)){$picker=New-Object Windows.Forms.FolderBrowserDialog;$picker.Description=PText 'install_game';try{if($picker.ShowDialog() -ne 'OK'){return};$GamePath=$picker.SelectedPath}finally{$picker.Dispose()}}
    if(!(Test-Psych0GameFolder $GamePath)){throw (PText 'text_433')}
    if((Show-Psych0Message -Text (PText 'install_confirm' @($c.name)) -Caption (PText 'install_title') -Buttons 'YesNo' -DefaultButton 'Button2') -ne 'Yes'){return}
    $receipt=Invoke-Psych0Maintenance {
        Assert-Psych0OwnedDirectory $appTarget 'app';Assert-Psych0OwnedDirectory (Join-Path $GamePath 'mods/Psych0Mod') 'mod'
        $manifest=Get-Psych0CloudManifest
        Assert-Psych0ManifestChannel $manifest
        $plan=New-Psych0RepairPlan $manifest $appTarget (Join-Path $GamePath 'mods/Psych0Mod') $work
        Complete-Psych0RepairSource $plan
        Install-Psych0Suite $plan.app $plan.mod $appTarget $GamePath
    }
    $settings=Join-Path (Get-Psych0DataDirectory) 'config.json'
    if(!(Test-Path $settings)){@{payday2_path=$GamePath;language=$Language}|ConvertTo-Json|Set-Content $settings -Encoding UTF8}
    $shell=New-Object -ComObject WScript.Shell
    $shortcut=$shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) ('Psych0VMod '+$c.name+'.lnk')))
    $shortcut.TargetPath=Join-Path $env:WINDIR 'System32/wscript.exe';$shortcut.Arguments='"'+(Join-Path $appTarget 'Start-Psych0VMod.vbs')+'"';$shortcut.WorkingDirectory=[IO.Path]::GetTempPath();$shortcut.IconLocation=Join-Path $appTarget 'Psych0VMod.ico';$shortcut.Save()
    $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Psych0VMod-'+$c.name
    [void](New-Item -Path $key -Force)
    $values=@{DisplayName=('Psych0VMod '+$c.name);DisplayVersion=[string]$manifest.version;Publisher='Psych0VMod';InstallLocation=$appTarget;DisplayIcon=(Join-Path $appTarget 'Psych0VMod.ico');UninstallString=('powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "'+(Join-Path $appTarget 'Uninstall-Psych0VMod.ps1')+'" -AppTarget "'+$appTarget+'"')}
    foreach($name in $values.Keys){[void](New-ItemProperty -Path $key -Name $name -Value $values[$name] -PropertyType String -Force)}
    [void](Show-Psych0Message -Text (PText 'install_done') -Caption (PText 'install_title'))
}catch{[void](Show-Psych0Message -Text $_.Exception.Message -Caption (PText 'install_title') -Icon 'Error')}
finally{if(Test-Path $work){Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue}}
